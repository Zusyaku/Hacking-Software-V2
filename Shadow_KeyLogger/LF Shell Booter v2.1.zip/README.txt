Thank you for downloading my multi-threaded shell booter.

To use this booter you must have a .txt with a list of shells in it.
Have 1 shell per line, ex:
http://shell.com/shell1.php
http://shell.com/shell2.php
http://shell.com/shell3.php

How to use:
Simply drag your shell list to the program.
Insert the designated IP, Port, and time.
Click send and your attack will be sent to all shells.


Credits:
LiteFire from HF
http://www.hackforums.net/member.php?action=profile&uid=288280