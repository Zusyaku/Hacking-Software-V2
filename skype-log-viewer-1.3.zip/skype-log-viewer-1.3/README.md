# skype-log-viewer
Download and View Skype History Without Skype 

This program allows you to view all of your skype chat logs and then easily export them as text files.

It correctly organizes them by conversation, and makes sure that group conversations do not get jumbled with one on one chats.

Features
  * Download Skype Logs
  * Broken Database Support
  * Change Export Format
  * Organized by conversation in skype
  
![Skype Log Icon](/Images/SkypeLogLGG.png?raw=true "Skype Log Icon")
![Skype Log ScreenShot](/Images/ScreenShot1.jpg?raw=true "Skype Log ScreenShot")


**Code license**
  * [GNU GPL v2](http://www.gnu.org/licenses/gpl-2.0.html)
  
**Content License**
  * [Creative Commons 3.0 BY-SA](http://creativecommons.org/licenses/by-sa/3.0/)
  
**Code Of Conduct**
  * Treat everyone with respect.
