<?php
error_reporting(0);

//HEADER
header('Content-Type: application/json');

//GET COUNTRY
//$mana = $_GET['mana'];

// LIB
require_once 'src/autoload.php';
$w3ll_fake = Faker\Factory::create(en_US);

//JSON OBJ
$w3ll_obj->company =  $w3ll_fake->company;
$w3ll_obj->name = $w3ll_fake->firstName." ".$w3ll_fake->lastName;
$w3ll_obj->phone =  $w3ll_fake->e164PhoneNumber;
$w3ll_obj->email =  $w3ll_fake->companyEmail;
$w3ll_obj->uuid = $w3ll_fake->uuid;
$w3ll_obj->site = $w3ll_fake->domainName;
$w3ll_obj->fname = $w3ll_fake->firstName;
$w3ll_obj->lname = $w3ll_fake->lastName;
$w3ll_obj->postcode = $w3ll_fake->postcode;
$w3ll_obj->country = $w3ll_fake->country;
$w3ll_obj->state = $w3ll_fake->state;
$w3ll_obj->city = $w3ll_fake->city;
$w3ll_obj->addrs = $w3ll_fake->address;
$w3ll_obj->street = $w3ll_fake->streetName;
$w3ll_obj->cc = $w3ll_fake->creditCardNumber;
$w3ll_obj->expr = $w3ll_fake->creditCardExpirationDateString;
$w3ll_obj->ctype = $w3ll_fake->creditCardType;
$w3ll_obj->uname = $w3ll_fake->userName;
$w3ll_obj->staddrs = $w3ll_fake->streetAddress;
$w3ll_obj->iban = $w3ll_fake->iban;
$w3ll_obj->freedomain = $w3ll_fake->freeEmailDomain;
$w3ll_obj->isbn10 = $w3ll_fake->isbn10;
$w3ll_obj->sha1 = $w3ll_fake->sha1;
$w3ll_obj->md5 = $w3ll_fake->md5;
$w3ll_obj->sha256 = $w3ll_fake->sha256;
$w3ll_obj->ipv4 = $w3ll_fake->ipv4;
$w3ll_obj->ua = $w3ll_fake->userAgent;
$w3ll_obj->url = $w3ll_fake->url;
//$w3ll_obj->emoji = $w3ll_fake->emoji;
$w3ll_json = json_encode($w3ll_obj);

//JOSN OUTPUT
echo $w3ll_json;
