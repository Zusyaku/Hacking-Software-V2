<?php

error_reporting(0);
session_start();

if (!isset($_SESSION['redi_watch'])) {
header("HTTP/1.0 404 Not Found");
exit("<h1>Not Found</h1>
The requested URL " . $_SERVER["REQUEST_URI"] . " was not found on this server.
<hr>");
}

include('../config.php');

$CONFIG_KILLBOT = [
    'active'        => true, // If 'true' will set blocker protection active, and 'false' will deactive protection
    'apikey'        => $kill_bot_api, // Your API Key from https://killbot.org/developer
    'bot_redirect'  => 'suspend' // Bot will be redirect to this URL or you can change with 403, 404, suspend or cloudflare.
];