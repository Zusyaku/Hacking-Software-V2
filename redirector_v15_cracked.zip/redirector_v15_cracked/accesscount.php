<?php

error_reporting(0);
session_start();

if (!isset($_SESSION['redi_watch'])) {
header("HTTP/1.0 404 Not Found");
exit("<h1>Not Found</h1>
The requested URL " . $_SERVER["REQUEST_URI"] . " was not found on this server.
<hr>");
}


$remoteip = 
  isset($_SERVER["HTTP_CF_CONNECTING_IP"])?
     $_SERVER["HTTP_CF_CONNECTING_IP"]:
     $_SERVER["REMOTE_ADDR"]
  ;
  
$clean_ip = filter_var($remoteip, FILTER_SANITIZE_NUMBER_INT);
  
if (filter_var($remoteip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
    if (file_exists('deny/'.$clean_ip.'.txt')){
         $lines = count(file('deny/'.$clean_ip.'.txt'));
         if ($lines >= $visitcount){
         	if ($failed_url == true){
	    require($errorpage);
	    exit();
	}else{
	header('Location: ' . $multiple_url);
    exit();
	}
             
         }
    }
    file_put_contents('deny/'.$clean_ip.'.txt', $remoteip."\n", FILE_APPEND);
}else{
    	if ($failed_url == true){
	    require($errorpage);
	    exit();
	}else{
	header('Location: ' . $multiple_url);
    exit();
	}
}

?>