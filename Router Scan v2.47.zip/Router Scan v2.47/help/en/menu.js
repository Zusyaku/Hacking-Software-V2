Tree = [
	[1, 1, imgLogo, "Router Scan", [
		[0, imgPage, "About", "main.html"],
		[0, imgPage, "Changelog", "changelog.html"],
		[1, 1, imgFolder, "Information", [
			[0, imgPage, "F.A.Q.", "faq.html"],
			[0, imgPage, "Supported router models", "supported.html"],
			[0, imgPage, "Exploit list", "exploits.html"],
		]],
	]],
];
