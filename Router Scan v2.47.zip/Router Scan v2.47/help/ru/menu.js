Tree = [
	[1, 1, imgLogo, "Router Scan", [
		[0, imgPage, "О проекте", "main.html"],
		[0, imgPage, "История изменений", "changelog.html"],
		[1, 1, imgFolder, "Информация", [
			[0, imgPage, "Часто задаваемые вопросы", "faq.html"],
			[0, imgPage, "Поддерживаемые модели роутеров", "supported.html"],
			[0, imgPage, "Список эксплойтов", "exploits.html"],
		]],
	]],
];
