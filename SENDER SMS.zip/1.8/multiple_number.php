<?php
/*

www.bulk-sms.us © 2020

contact us : bulksms.us@gmail.com

*/

require_once './vendor/autoload.php';

// ----------------------------------------- Twilio ----------------------------------------- //

if (isset($_POST['provider']) && $_POST['provider'] == "twilio") {
		
    if (isset($_POST['numbers'])) {
        $numbers = $_POST['numbers'];
        $message = $_POST['message'];
        $sender = $_POST['sender'];
        foreach (explode("+", $numbers) as $phone) {

            //twillio *config*
            $sid = "ACa68bd47303986afa966b7f2b103ab5c4"; // Your Account SID from www.twilio.com/console
            $token = "96feb9c2155322ebf55520c8db0727e4"; // Your Auth Token from www.twilio.com/console

            $client = new Twilio\Rest\Client($sid, $token); 
            $message = $client->messages->create(
                    '+' . $phone, array(
                'from' => $sender, // From a valid Twilio Number : put ur Number in Sender ID input
                'body' => $message
                    )
            );
            if ($message->sid) {
                $data = array(
                    "response" => "success",
                    "current" => '+' . $phone
                );

                echo json_encode($data);
            }
        }
    }
	
	
// ----------------------------------------- Nexmo ----------------------------------------- //	

} else if (isset($_POST['provider']) && $_POST['provider'] == "nexmo") {
	

    if (isset($_POST['numbers'])) {
        $numbers = $_POST['numbers'];
        $msg = $_POST['message'];
        $sender = $_POST['sender'];
        foreach (explode("+", $numbers) as $phone) {

	    	// Nexmo *config*
            $basic = new \Nexmo\Client\Credentials\Basic('e6d5ad21', 'hbWhDagwuPAGG1Ix'); //Api key , Api secret
            $client = new \Nexmo\Client($basic);

            $message = $client->message()->send([
                'to' => $phone,
                'from' => $sender, // att ok
                'text' => $msg
            ]);

            $data_array = array($message['to'], $message['status'], 'nexmo');
            echo json_encode($data_array);
        }
    }
	
	
// ----------------------------------------- TextLocal ----------------------------------------- //

} else if (isset($_POST['provider']) && $_POST['provider'] == "textlocal") {

    if (isset($_POST['numbers'])) {
        $numbers = $_POST['numbers'];
        $message = $_POST['message'];
        $sender = $_POST['sender'];
        foreach (explode("+", $numbers) as $phone) {
			
            // TextLocal *config*
            $username = "";
            $hash = "";

            // Config variables. Consult http://api.textlocal.in/docs for more info.
            $test = "0";

            // Data for text message. This is the text message data.
            $sender = "TXTLCL"; // This is who the message appears to be from.

            $numbers = preg_replace('/[^0-9]/', '', $phone); 
            $message = "This is a test message from the PHP API script.";
            $message = urlencode($message);
            $data = "username=" . $username . "&hash=" . $hash . "&message=" . $message . "&sender=" . $sender . "&numbers=" . $numbers . "&test=" . $test;
            $ch = curl_init('http://api.textlocal.in/send/?');
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $result = curl_exec($ch); // This is the result from the API

            if ($result) {
                $data = array(
                    "response" => "success",
                    "current" => '+' . $phone
                );

                echo json_encode($data);
            }

            curl_close($ch);
        }
    }
}
