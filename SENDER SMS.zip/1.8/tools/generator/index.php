<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <link href="https://i.imgur.com/hh4v20F.png" rel="icon" type="image/x-icon"/>
  <title>Phone Number Generator | Bulk-SMS.us</title>
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/css/bootstrap.css'>
<link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.0.13/css/all.css'><link rel="stylesheet" href="assets/style2.css">

</head>
<body>
<!-- partial:index.partial.html -->
<div class="page-wrapper chiller-theme toggled">
  <a id="show-sidebar" class="btn btn-sm btn-dark" href="#">
    <i class="fas fa-bars"></i>
  </a>
  <nav id="sidebar" class="sidebar-wrapper">
    <div class="sidebar-content">
      <div class="sidebar-brand">
        <a href="#">Admin panel</a>
        <div id="close-sidebar">
          <i class="fas fa-times"></i>
        </div>
      </div>
      <div class="sidebar-header">
        <div class="user-pic">
          <img class="img-responsive img-rounded" src="https://i.imgur.com/Vpx6L4r.jpg"
            alt="User picture">
        </div>
        <div class="user-info">
          <span class="user-name">Jhon
            <strong>Smith</strong>
          </span>
          <span class="user-role">Administrator</span>
          <span class="user-status">
            <i class="fa fa-circle"></i>
            <span>Online</span>
          </span>
        </div>
      </div>
    
      <div class="sidebar-menu">
        <ul>
          
          <li class="s">
            <a href="../././../index.php">
              <i class=""></i>
			  
               <strong>&#149;  <font color="#09E5B3"face="Candara">Dashboard </font></strong>
              
            </a>
<style>
hr.new2 {border-top: 1px dashed #5cb85c; width:100%;}
</style>
<hr class='new2'>
            <div class="sidebar-submenu">
             
            </div>
          </li>
          
          
          <li class="s">
            <a href="#">
              <i class=""></i>
               <strong><font size="4px" color="#EEEA17">&#9675;	</font><font color="#09E5B3">Phone Number Generator</font></strong>
            </a>
<style>
hr.new2 {border-top: 1px dashed #5cb85c; width:100%;}
</style>
<hr class='new2'>
            <div class="sidebar-submenu">
              
            </div>
          </li>

          <li>
            <a href=".././info-valid">
              <i class=""></i>
             <strong>&#149;  <font color="#09E5B3"face="Candara">Phone Number INFO</font></strong>
            </a>
<style>
hr.new2 {border-top: 1px dashed #5cb85c; width:100%;}
</style>
<hr class='new2'>
          </li>
		  
		  
		    <li>
             <a href=".././extractor" target="_blank">
              <i class=""></i>
             <strong>&#149;  <font color="#09E5B3" face="Candara">Phone Number Extractor</font></strong>     
            </a>
<style>
hr.new2 {border-top: 1px dashed #5cb85c; width:100%;}
</style>
<hr class='new2'>
          </li>
		  
		  <li>
            <a href=".././addplus">
              <i class=""></i>
            <strong>&#149;  <font color="#09E5B3" face="Candara">Add +</font></strong>
            </a>
<style>
hr.new2 {border-top: 1px dashed #5cb85c; width:100%;}
</style>
<hr class='new2'>
          </li>
		    <li>
            <a href=".././api">
              <i class=""></i>
            <strong>&#149;  <font color="#09E5B3" face="Candara">Nexmo Api Balance</font></strong>
            </a>

          </li>
		  
        </ul>
      </div>
      <!-- sidebar-menu  -->
    </div>
    <!-- sidebar-content  -->
    <div class="sidebar-footer">
     
      <a href="http://t.me/xe0on" target="_blank" title="XEON" >
        <b><font color="#E3E910" face="verdana">XEON GENRATOR</font></b> <font color="#E3E910" face="verdana"> &#169;	</font>
      </a>
    </div>
  </nav>
  <!-- sidebar-wrapper  -->
  <main class="page-content">
    <div class="container-fluid">
  
<!DOCTYPE html>
<html>
<head>
  <title>Phone Number Generator</title>
  <link href="" rel="icon" type="image/x-icon"/>
  <meta name="viewport" content="width=940, initial-scale=1.0, maximum-scale=1.0">
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
  <script src="http://code.jquery.com/jquery-2.1.3.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
  <style>
  body{
  background-color: #ccc;}
  </style>
</head>
<body>
<center>
<br/>
<b><font size="7px" color="#1919DF" face="verdana" >X E O N</font></b>   
<br/><br/><br/>
<style>
.intro 
{
  background-color: #FFA07A;
  width:400px;
  height:330px;
}
</style>
<div class="intro">
<div style="padding-left:30px;"><b><font size="5px" color="#6A0F8E" face="Arial Black">Phone Number Generator</font></b></div>
<br/>
<form action="" method="post">
<div style="padding-right:213px;"><label>* Country Code</label></div>
<input type="text" name="code" placeholder="+44 | +01 | +61 | +07 ..." value="" required="" style="width:300px;"/>
<br/><br/>
<div style="padding-right:110px;"><label>* Numbers after Country Code</label></div>
<input type="text" name="num" placeholder="9 - 10 - 11 ..." value="" required="" style="width:300px;"/>
<br/><br/>
<div style="padding-right:40px;"><label>* How many phone numbers to generate?</label></div>
<input type="text" name="total" placeholder="1 - 1000000000000000" value="" required="" style="width:300px;"/>
<style>
hr.new44 {border-top: 1px dashed #1919DF; width:73%;}
</style>
<hr class='new44'>
<input type="submit" name="send" value="Generate Phone Numbers" style="width:300px;">
</div>
</form>
</center>
</body>
</html>
<?php
if(!function_exists('getkey'))
{
	function getkey($length = 20)  
	{
		 $alpha = '1478520369'; 
		 $key = '' ;
		 
		 for($i=0; $i<$length; $i++){
			 $ran = rand(0, strlen($alpha)-1);
			 $key .= substr($alpha, $ran, 1);
		 }   
		 return $key;
	}
}
if(isset($_POST['code'])) {

	$num = $_POST['num'];

	$code = $_POST['code'];

	$total = $_POST['total'];

	$ar = array();

	for ($i=0; $i < $total; $i++) { 
		do {

			$number = getkey($num);

		}while (in_array($number, $ar));

		$ar[] = $code.$number;
	}
?>
<center>
<style>
.intro2 {
  background-color: #BD0BB7;
  width:400px;
  height:129px;
  padding-top:4px;
  
}
</style>

<div class="intro2" >

<textarea name="phone list" placeholder="phone list"  style="margin-right:3px; height:120px;width:300px;"><?php echo implode("\n", $ar); ?></textarea>
</div>
<br/>
<a href="http://t.me/xe0on" target="_blank"><b><font color="#1919DF" face="verdana" size="2px" >FUCKER  &#169; 2020</b></a>
</center>
<br/>
<?php } ?>
</main>
</div>
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/esm/popper.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/js/bootstrap.js'></script><script  src="assets/script2.js"></script>

</body>
</html>