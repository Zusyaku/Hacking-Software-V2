

	$('input, textarea').live('focus', function() {
		if($(this).val()== $(this).attr('alt')) {
			$(this).val('');
		}
	}).live('blur', function() {
		if($(this).val()== '') {
			$(this).val($(this).attr('alt'));
		}
	});
});