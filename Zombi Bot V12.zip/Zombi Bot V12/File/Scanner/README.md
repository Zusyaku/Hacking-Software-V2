# SVScanner - Scanner Vulnerability And MaSsive Exploit.

[![Version](https://img.shields.io/badge/SVScanner-1.1-brightgreen.svg?maxAge=259200)]()
[![Stage](https://img.shields.io/badge/Release-Stable-brightgreen.svg)]()
[![Build](https://img.shields.io/badge/Supported_OS-Linux-orange.svg)]()
[![Build](https://img.shields.io/badge/Supported_OS-Windows-blue.svg)]()

Is a tool for scanning and massive exploits. Our tools target several open source cms.

## Getting Started with Linux
1. ```git clone https://github.com/radenvodka/SVScanner.git```
2. ```cd SVScanner```
3. ```php svscanner.php```

## Getting Started with Windows 
1. ```Download Xampp (PHP7)```
2. ```Download SVScanner : https://github.com/radenvodka/SVScanner/releases```
3. ```and open with cmd php svscanner.php```

## Systems we recommend :
1. ```PHP 7 (version and up)```
2. ```Install Modules PHP : php-cli & php-curl for linux```

## Credits

- Thanks to allah
- Edo Maland (Powerstager) https://github.com/Screetsec
- Jack Wilder admin in http://www.linuxsec.org

## Want to contribute

send the target live and what exploits are used.
then send to maunikah1337@gmail.com

## Disclaimer
Note: modifications, changes, or changes to this code can be accepted, however, every public release that uses this code must be approved by writing this tool (Eka S)
