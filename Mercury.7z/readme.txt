Malware name: Mercury
Malware type: Trojan
Made in: C++ and nasm for mbr
Works best in: Windows XP