<h1 align="center">Roasting SMS Bomber</h1>
<h4 align="center"> A very simple SMS Bomber</h4>

<h4 align="center">
You will need to install the krypton component system into VS, but if not, the files are already created for you to use the SMS Bomber. If you decide to edit the program and build the solution it will pop out the exe and a dll file. If you want it to only have the exe file, you will need an external program called ILMerge which will allow you to bind the exe and dll files together. The krypton pack is here https://github.com/ComponentFactory/Krypton and the ILMerge Program is here https://wvd-vegt.bitbucket.io/ilmergegui.html
  <hr>
<img src="https://raw.githubusercontent.com/roast247/SMSbomber/main/SMS.png">
<hr>
Disclaimer: I am not resposible for any illegal actions with the use of my programs
  
  If you would like to contact me, email me at roast247@protonmail.com
</h4>
