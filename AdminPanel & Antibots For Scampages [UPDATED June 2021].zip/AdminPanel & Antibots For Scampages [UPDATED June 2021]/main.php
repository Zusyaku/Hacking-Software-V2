// Your Main Page must start from here..

Place Your CSS Files in: assets/css
Place Your Image Files in: assets/img
Place Your JS Files in: assets/js