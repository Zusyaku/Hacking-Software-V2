<?php
error_reporting(0);
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require('config.php');
require 'modules/src/Exception.php';
require 'modules/src/PHPMailer.php';
require 'modules/src/SMTP.php';

class FourKey extends Config
{	
    function __construct()
    {  
        $this->modules = new FourKeyModules;
        if(phpversion() < "7.0.0"){
           die("PHP ".phpversion()." TIDAK SUPPORT SILAHKAN UPDATE KE PHP 7\r\n");
        }
		//echo "\33[1;32m==============================================\r\n\033[0m";
		echo "\r\n";
		echo "		\033[0;36m███╗    ███╗\033[1;33m███╗    ███╗\r\n";
		echo "		\033[0;36m███║    ███║\033[1;33m███║   ███╔╝\r\n";
		echo "		\033[0;36m███║    ███║\033[1;33m███║  ███╔╝\r\n";
		echo "		\033[0;36m███║    ███║\033[1;33m███║ ███╔╝\r\n";
		echo "		\033[0;36m███████████║\033[1;33m███████╔╝ \r\n";
		echo "		\033[0;36m╚═══════███║\033[1;33m███╔═███╗ \r\n";
		echo "		\033[0;36m        ███║\033[1;33m███║  ███╗\r\n";
		echo "		\033[0;36m        ███║\033[1;33m███║   ███╗\r\n";		
		echo "		\033[0;36m        ███║\033[1;33m███║    ███╗\r\n";
		echo "		\033[0;36m        ╚══╝\033[1;33m╚══╝    ╚══╝\r\n";
		echo "\r\n";
		echo "       Kita perlu revolusi. Pengetahuan Adalah Kekuatan.\r\n";
		//echo "\r\n";
		//echo "\33[1;32m===============================================\r\n\033[0m";
        echo "		  \033[1;33mDRACOS SENDER PREMIUM ".$this->modules->versi()."\r\n\033[0m";
        //echo "\33[1;32m===============================================\r\n\033[0m";
		echo "\r\n";
		
        $du                     = $this->modules->stuck("[+] [ Send Duplicate Mail (0 = Yes , 1 = No) ] : ");
     /*   $debug                  = $this->modules->stuck("[ Enable Debug (0 = Yes , 1 = No)] : ");*/
        $this->listEmail        = $this->modules->load($LoadEmail , $du);
        $this->smtp_config      = null;
     /*   $this->debug            = str_replace("1", "no", str_replace("0", "yes", $debug));*/
        $this->run();
    }
    function send(){
        $mail = new PHPMailer(true);
        try {
 
            $mail->setLanguage('en', 'modules/language/');
           $mail->SMTPDebug    = 0;  
          /*  if($this->debug == 'yes'){
                $mail->SMTPDebug    = 3;                              
            }else{
                $mail->SMTPDebug    = 0;                              
            }*/
 
            $mail->isSMTP();                                            
            $mail->Host         = $this->smtp_config['smtp_host'];      
            $mail->SMTPAuth     = true;
            $mail->SMTPOptions = array(
		'ssl' => array(
        'verify_peer' => false,
        'verify_peer_name' => false,
        'allow_self_signed' => true
    )
);         
            $mail->Username     = $this->smtp_config['smtp_user'];                
            $mail->Password     = $this->smtp_config['smtp_pass'];                            
            $mail->SMTPSecure   = $this->smtp_config['smtp_secure'];                                
            $mail->Port         = $this->smtp_config['smtp_port'];
			$mail->Encoding 	= 'base64'; // 8bit base64 multipart/alternative quoted-printable
            $mail->CharSet  	= 'UTF-8';			
			$mail->Priority 	= $this->smtp_config['smtp_priority'];
			$mail->headerLine("format", "flowed");
			/*  Smtp connect    */
            //$mail->addCustomHeader('X-Ebay-Mailtracker', '11400.000.0.0.df812eaca5dd4ebb8aa71380465a8e74');
 
            $mail->From         = $this->alias( $this->smtp_config['recipients']['from_email'] , $this->email);
            $mail->FromName     = $this->alias( $this->smtp_config['recipients']['from_name']  , $this->email);
 
            foreach ($this->smtp_config[content][attachments] as $key => $attfile) {
                if($attfile != ""){
                    $flocation = 'attachments/'.$attfile;
                    if(file_exists($flocation) ){
                        $mail->addAttachment('attachments/'.$attfile);
                    }
                }
            }
 
			  
			$mail->Encoding = 'base64'; // 8bit base64 multipart/alternative quoted-printable
            $mail->CharSet  = 'UTF-8';
            $mail->headerLine("format", "flowed");
			$mail->addCustomHeader('X-Mailer', 'Gleez CMS 0.10.5');
            $mail->addCustomHeader('List-Unsubscribe', '<mailto:' . md5($to) . '?body=unsubscribe>');
            $mail->addCustomHeader('x-store-info', 'sbevkl2QZR7OXo7WID5ZcVBK1Phj2jX');
            $mail->addCustomHeader('X-Brightmail-Tracker', '94a96329-ea03-4d8a-c064-08d57447496a');
            $mail->addCustomHeader('X-Ebay-Mailtracker', '11400.000.0.0.47c24ec5-012f-4a87-959a-08d575a41eaba5dd4ebb8aa71380465a8e74');
            $mail->addCustomHeader('X-No-Track', '11400.000.0.0.47c24ec5-012f-4a87-959a');
            $mail->addCustomHeader('X-IncomingTopHeaderMarker','OriginalChecksum:7A4B39E7D056847912D5CA9A44EE97E012CAB89718D96F551AD061D4723C55DB;UpperCasedChecksum:7D1C2902BA6A1D8B04696E190BF0ABC5D6EBBED94E3E13F3C20BC4C79B791BDC;SizeAsReceived:9118;Count:39');
            $mail->addCustomHeader('X-MSAPipeline','MessageDispatcherEOP');
            $mail->addCustomHeader('X-BO1-SAF2-RCPT-Passed','Yes');
            $mail->addCustomHeader('X-Antivirus-Scanner','ClamAV - No Detected Virus, though you should still use a Local Antivirus on your computer.');
            $mail->addCustomHeader('X-Scanned-By','Tzolkin-Spam-Scanner');
            $mail->addCustomHeader('X-Spam-Status: No','score=3.0 required=5.0 tests=BAYES_50,HTML_MESSAGE, UNPARSEABLE_RELAY autolearn=no version=3.3.1');
            $mail->addCustomHeader('X-Mailer','Microsoft Office Outlook 10.0');
            $mail->addCustomHeader('Content-class','urn:content-classes:calendarmessage');
            $mail->addCustomHeader('Importance','High');
            $mail->addCustomHeader('X-Sender','<{""}>');
		/*
			$mail->addCustomHeader('X-EmailType-Id',  $mail->From);
            $mail->addCustomHeader('X-Sent-To', $this->email);
            $mail->addCustomHeader('X-Attach-Flag', 'N');
            $mail->addCustomHeader('X-Reference', "RE: [ Fraud Activities ] Receipt form team support. Verify Your Account Now [  Alert Information ] [IP CONFIRMATION]");
            $mail->addCustomHeader('X-TXN_ID', 'custom-value');
			$mail->addCustomHeader('X-DKIM_SIGN_REQUIRED','YES');
			$mail->addCustomHeader('x-live-global-disposition','G');
			$mail->addCustomHeader('X-live-VSS-INFO','G');
            $mail->addCustomHeader('X-live-VSS-CODE','CLEAN');
            $mail->addCustomHeader('X-live-SCOLL-AUTHENTICATION','mtaiw-mad01.mx.live.com ; domain : email.apple.com DKIM : pass');
            $mail->addCustomHeader('x-live-sid','3039ac1addc75a145f8149a9');*/

            /* Yahoo */
            /* $mail->addCustomHeader('X-Mailer','MailChimp Mailer - **CID1f1e04897ba877cf3313**');
            $mail->addCustomHeader('X-Campaign','mailchimpa813b06f1ff5b066769f481f6.1f1e04897b');
            $mail->addCustomHeader('X-campaignid','mailchimpa813b06f1ff5b066769f481f6.1f1e04897b');
            $mail->addCustomHeader('X-Report-Abuse','lease report abuse for this campaign here: http://www.mailchimp.com/abuse/abuse.phtml?u=a813b06f1ff5b066769f481f6&id=1f1e04897b&e=a877cf3313');
            $mail->addCustomHeader('X-MC-User','a813b06f1ff5b066769f481f6');
            $mail->addCustomHeader('Feedback-ID','50044413:50044413.661941:us12:mc');
            $mail->addCustomHeader('List-ID','a813b06f1ff5b066769f481f6mc list <a813b06f1ff5b066769f481f6.230069.list-id.mcsv.net>');
           */
            /*HEADER ADD END*/
 
            $mail->AddAddress($this->email);
           
            $mail->isHTML(true);
           
            $content = $this->modules->arrayrandom(  $this->smtp_config['content']['format'] );
			
            if(!file_exists('letter/'.$content['value'])){
                die("[+] ============>> Letter Tidak ada <<============\r\n");
            }
           
            $bodyLetter         = $this->alias( file_get_contents('letter/'.$content['value']) , $this->email);
            $mail->Subject      = $this->alias( $content['key'] , $this->email );
            $mail->Body         = $this->alias( $bodyLetter , $this->email  );
           
            $mail->send();
            $this->modules->save('success.txt',$this->email);
            return 'Message has been sent';
        } catch (Exception $e) {
            $this->modules->save('failed.txt',$this->email);
            return $mail->ErrorInfo."\r\n";
        }    
    }
    function run(){
        $hit = 1;
        $num = 1;
        $this->fourkey_config     = $this->setting();
        $this->smtp_array         = $this->smtp();
 
 
        foreach ($this->listEmail['list'] as $key => $email) {
           
            $this->smtp_config  = $this->modules->arrayrandom(  $this->smtp_array )['value'];
            $this->email        = $email;
			
			if($num == $this->fourkey_config['number']){
                echo "[+]  DRACOS >> Delay (".$this->fourkey_config['delay'].") Sec << PREMIUM \r\n";
                sleep($this->fourkey_config['delay']);
                $num = 3;
            }
			
            if(count($this->smtp_array) == 0){
                die("[+] ============>> SMTP Tidak ada <<============\r\n");
            }
           
            echo "[+] [".$hit."/".$this->listEmail['total']."] [From : ".$this->smtp_config['smtp_user']."] ".$email." => ";
           
            $send   = $this->send();
            echo str_replace('Message has been sent', 'Delivered' , $send);
           
            if( $send != 'Message has been sent' ){
                unset($this->smtp_array[$this->smtp_config['key']]);
            }
           
 
            
			            echo "\r\n";
            $num++;
            $hit++;
			//$remove = Removeline('file/maillist/email.txt', $this->email);
        }
    }
}
$FourKey = new FourKey;