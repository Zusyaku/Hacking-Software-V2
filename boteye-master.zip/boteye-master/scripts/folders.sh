mkdir -p $HOME/Boteye
mkdir -p $HOME/Boteye/calibration/
mkdir -p $HOME/Boteye/calibration/images
mkdir -p $HOME/Boteye/data/
mkdir -p $HOME/Boteye/pipeline/
mkdir -p $HOME/Boteye/semantic/