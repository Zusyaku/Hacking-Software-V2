${MASTER_DIR}/build/pc_apps/xp_sensor_logger/\
./xp_sensor_logger \
--record_path=$HOME/Boteye/calibration/images/ \
--sensor_type=XP3 \
--calib_mode