Necro Virus Maker v4.0 {BETA}



1ST OF ALL YOU HAVE TO DEACTIVATE YOUR ANTIVIRUS!!!!!

then

You can change the settings to make the virus as you want and send it to your friends.
With the new tools you can customize the file after its creation.
For example you can bind whatever you want with the virus you've created
and you can replace the old virus's icon with another using the icon changer.

I don't take any responsibility for any damage!

Coded by Sab0taz in VB6
14-09-2009

Contact: sabo-taz@hotmail.com
Web: http:\\overdose.gr

This is the BETA Version of N.V.M. v4...
I had many bugz and problems.. 
I decided to make a BETA Version and im asking u for feedback...
