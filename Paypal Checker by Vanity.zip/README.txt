

1) Need to have Proxy

2) Start Checker

3) put proxy's & Enjoy