#########################################################################################

 AccessDiver is a security tester for Web pages. It has got a set of tools which
will verify the robustness of you accounts and directories. You will know if your
customers, your users and you can use safely your web site.

#########################################################################################

This program requires :

	- A PC Compatible computer.
      	- Any Win32 System : Windows95/98/ME/NT/2000/2003/XP
     	- A connexion to Internet or to a local Network using the TCP/IP protocol.
	- 6 MB of space on your machine
       	- 64MB of RAM minimum. Works better with 96MB.
	- Internet Explorer 4.0 and higher installed

#########################################################################################

 This freeware is a multi-featured product. You will find features like :

       	- HTML Pattern finder.
	- Task control / automation. (JOBs)
 	- Away reporter : Receive email stats from the tool when you are present.
        - Contacts manager : manage to send histories to your cooperative.
	- Ping-Pong analyzer : a powerfull system to test multiple urls at once.
        - Proxy Hunter : if you don't have enough proxies to use, try to find some.
        - PING tester
        - DNS resolver
        - WHOIS shower : If you are curious of who's the owner of a domain and  if a domain is free.
        - HTTP Debugger : enhance your skill with it or get more info on your analysis
        - Word Generator (+Anagrams)
        - A completely rebuilt Directory Exploiter
        - A completely rebuilt used URL History
        - SOCKS Proxies are now handled
        - SOCKS Analyzer
        - Web site leecher : enhance your dictionnary by extracting words from dedicated servers
	- Proxy leecher : to find even more proxies for your future analysis
	- etc...


#########################################################################################

If you find this product good enough to be used, it'll be fine if you can tell your friends 
about it or making a simple donation. Thank you very much

To donate you can visit this page:

http://www.accessdiver.com/donation.htm


#########################################################################################

Legal notes :

AccessDiver is intended to be used by administrators or privileged users on their own 
accounts and directories. These persons will legally test the robustness of their own 
security accesses.

Do NOT use this program to gain entrance into other person's computers, servers or 
information. THIS IS NOT LEGAL AND COULD CAUSE YOU PROBLEMS!!!

If there's a lack of security on your web site, you will have to change your protection 
scheme.

This program is distributed as is and without any warranties of being free from errors. 
The author nor any associated with him, undertake no liability for ANY damage caused by 
this software.


#########################################################################################

Web site : http://www.accessdiver.com/

Email    : mrgeo@usermail.com
	 

(c) 1998-2007 - AccessDiver is an exclusive property of M. Jean Fages

#########################################################################################
