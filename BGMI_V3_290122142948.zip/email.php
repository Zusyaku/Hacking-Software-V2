<?php
$emailku = 'youeremail@gmail.com'; // TYPE UR EMAIL!
?>