<?php
  header('Location: https://pubgmobile.com/', true, 301);
  exit();
?>