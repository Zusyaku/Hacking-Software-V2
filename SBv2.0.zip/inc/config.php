<?php
goto Sqi4i; Sqi4i: $config = array(); goto vnOVQ; vnOVQ: $keis = "\x62\x69\147\163\145\x63\x63"; goto AI_mZ; AI_mZ: $config["\153\145\171"] = $keis;
