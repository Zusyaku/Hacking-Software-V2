<?php
if (isset($_GET['file'])) {
$file = $_GET['file'];
if (file_exists($file) && is_readable($file) && preg_match('/\.txt$/',$file)) {
	header('Content-Type: application/txt');
	header("Content-Disposition: attachment; filename=\"$file\"");
	readfile($file);
	}
}
?>