-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 29, 2021 at 11:44 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `xx`
--

-- --------------------------------------------------------

--
-- Table structure for table `domains`
--

CREATE TABLE `domains` (
  `USA` varchar(20) NOT NULL,
  `Russia` varchar(20) NOT NULL,
  `UK` varchar(20) NOT NULL,
  `Iran` varchar(20) NOT NULL,
  `India` varchar(20) NOT NULL,
  `Canada` varchar(20) NOT NULL,
  `Australia` varchar(20) NOT NULL,
  `Brazil` varchar(20) NOT NULL,
  `Vietnam` varchar(20) NOT NULL,
  `Germany` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `domains`
--

INSERT INTO `domains` (`USA`, `Russia`, `UK`, `Iran`, `India`, `Canada`, `Australia`, `Brazil`, `Vietnam`, `Germany`) VALUES
('.us', '.ru', '.uk', '.ir', '.in', '.ca', '.au', '.br', '.vn', '.de');

-- --------------------------------------------------------

--
-- Table structure for table `formats`
--

CREATE TABLE `formats` (
  `formats` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `formats`
--

INSERT INTO `formats` (`formats`) VALUES
('(\"My WordPress Blog\")'),
('(\"Comentarios en Hello world!\")'),
('(\"Comment on Hello world!\")'),
('(\"author/admin\")'),
('(\"uncategorized/hello-world\")'),
('(\"category/sin-categoria\")'),
('(\"uncategorized\")'),
('(\"non-classé\")'),
('(\"Proudly powered by WordPress\")'),
('(\"Welcome to WordPress. This is your first post.\")'),
('(\"Just another WordPress site\")'),
('(\"Mr WordPress on Hello world!\")'),
('(\"/wp/hello-world/\")');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
