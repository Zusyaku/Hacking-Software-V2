package spartons.com.prosmssenderapp.roomPersistence


/**
 * Ahsen Saeed}
 * ahsansaeed067@gmail.com}
 * 10/29/19}
 */

enum class BulkSmsStatus {
    IN_PROGRESS,
    COMPLETE,
    CANCELLED
}