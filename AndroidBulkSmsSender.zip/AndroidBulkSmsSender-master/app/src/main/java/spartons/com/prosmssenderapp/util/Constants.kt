package spartons.com.prosmssenderapp.util


/**
 * Ahsen Saeed}
 * ahsansaeed067@gmail.com}
 * 10/31/19}
 */

object Constants {

    const val CARRIER_NAME_SPLITTER = ":"
}