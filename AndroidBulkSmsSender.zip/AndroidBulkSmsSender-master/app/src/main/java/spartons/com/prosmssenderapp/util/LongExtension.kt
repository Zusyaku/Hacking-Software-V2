package spartons.com.prosmssenderapp.util

import java.util.*


/**
 * Ahsen Saeed}
 * ahsansaeed067@gmail.com}
 * 10/29/19}
 */

fun Long.toDate() = Date(this)