package spartons.com.prosmssenderapp.enums


/**
 * Ahsen Saeed}
 * ahsansaeed067@gmail.com}
 * 6/25/19}
 */

enum class TypeFaceEnum(val value: String) {

    WELCOME_MESSAGE_TYPEFACE("fonts/Kingthings_Foundation.ttf"),
    PRIMARY_BUTTON_TYPEFACE("fonts/BreeSerif_Regular.otf")
}