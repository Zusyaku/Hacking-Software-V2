#!/usr/bin/python3

import requests
from selenium.webdriver.common.keys import Keys
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from bs4 import BeautifulSoup as soup
from urllib.request import urlopen as req
from selenium import webdriver
from colorama import Fore, Cursor
import time, sys, os, threading, re

path = os.getcwd()

url = "https://wassname.github.io/keywordshitter2/"


keyword="""Wish
Wish.com
Shopping Made Fun
Online Shopping
Accessories
Baby Kids
Fashion
Gadgets
Hobbies
Home Decor
Phone Upgrades
Makeup
Beauty
Shoes
Wallets
Bags
Watches
Amazon
Amazon.com
Books
OnlineShopping
BookStore
Magazine
Subscription
Music
CDs
DVDs
Videos
Electronics
VideoGames
Computers
CellPhones
Toys
Games
Apparel
Jewelry
OfficeProducts
Sports
Outdoors
SportingGoods
BabyProducts
Health
PersonalCare
Home
Garden
Bed&Bath
Furniture
Tools
Hardware
Vacuums
OutdoorLiving
AutomotiveParts
PetSupplies
Broadband
DSL
online shopping
price comparison
compare prices
product reviews
store ratings
merchant reviews
store reviews
Walmart
Walmart.com
Gifts
TVs
HD TVs
Smart TVs
Baby Products
Video Games
Laptops
Cell Phones
Clothing
Sports &amp; Outdoors
Sporting Goods
Office Products
Vitamins
Personal Care
Beauty Products
Bed
Bath
Outdoor Living
Automotive Parts
Pet Food
Pet Supplies
iphone
qvc
qvc.com
www.qvc.com
qvc shopping
PC Gaming
Xbox 360 Games
Wii Games
Playstation 3 Games
PS3 Games
Console Gaming
Gaming Systems
PlayStation Systems
Gaming Accessories
Xbox Systems
best buy international
best buy countries
shop online
best buy
gaming computers
gaming pc
digital storm
storm
PlayStation 3
PS4 Games
PlaySation4
Konsolen
Xbox Games
Xbox One
Xbox
Obox One Games
Wii Mini
Onlineshop
Shop
Instant
Gaming
cd
Key
pc
steam
steambox
origin
battle.net
gamer PC
gaming PC
high end gamer PC
high end gaming PC
gamer PC kaufen
gaming PC kaufen
gamer PC ratenkauf
gaming PC ratenkauf
welchen gamer pc kaufen
welchen gaming pc kaufen
gamer pc günstig
gaming pc günstig
gamer pc finanzierung
gaming pc finanzierung
gamer pc auf raten kaufen
gaming pc auf raten kaufen
gamer pc 0 finanzierung
gaming pc 0 finanzierung
der beste gamer pc
der beste gaming pc
high tech pc
hitech gaming pc
hitech gamer pc
high tech gamer
high tech gaming
pc-systeme
gaming
amd
elite
extreme
cubes
intel
notebooks
special
editions
News
Web
Internet
headlines
newsletter
technology
Computer
web
information
windows
microsoft
netscape
browser
daily
headline
business
top
newslink
newslinks
stories
software
press release
Pressemitteilungen
Schlagzeilen
Nachrichten
deutsch
neu
aktuell
online
www
today
todays
up-to-date news
fast news
intranet news
world
international
german
financial
ipo
epic
games
fortnite
epicgames
download
launcher
login
store
activate
2fa
GameStop
Videospiele
Fan-Artikel
Merchandise
Loot
Pop-Culture
Pop Kultur
PS4
PlayStation
Nintendo Switch
3DS
PS3
Xbox 360
Wii
Wii U
PS Vita
PC
Gebrauchte Games
Eintauschaktion
EB Games
Microsoft Stream
Videostreaming
youtube
music
playlist
album
artist
radio
track
tracks
chart
charts
online
free
music search
music streaming free"""

f = open(path + '/results/keywords.txt', 'r')
line = f.readlines()
keywords = line
options = Options()
service = Service(path + '/lib/chromedriver')
options.headless = True
PATH = path + "/lib/chromedriver"
driver = webdriver.Chrome(options=options, service=service)
driver.get(url)
time.sleep(1)
timer = int(input(Fore.RED + ">> SELECT TIME (1 = A BIT KEYWORDS): "))
print(Fore.YELLOW + "Pasting keywords...")
field = driver.find_element_by_id('input')
field.send_keys(Keys.CONTROL+ "a")
field.send_keys(Keys.DELETE)
field.send_keys(keywords)
xx = driver.find_element_by_xpath("/html/body/div[1]/div[4]/div/div/div[1]/div[1]/div/a[2]")
xx.click()
ak = driver.find_element_by_xpath("/html/body/ul/li[6]/a")
ak.click()
xx.click()
button = driver.find_element_by_id('startjob')
button.click()
print(Fore.GREEN + "Started, please wait some time for good results.")
time.sleep(int(timer))
button.click()
result = driver.find_element_by_xpath("/html/body/div[1]/div[4]/div/div/div[3]/div")
#print(Fore.BLUE + result.text)
f = open(path+"/results/grabbed_keywords.txt","w")
f.write(str(result.text))

