#!/usr/bin/python3

import requests
from selenium.webdriver.common.keys import Keys
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from bs4 import BeautifulSoup as soup
from urllib.request import urlopen as req
from selenium import webdriver
from colorama import Fore, Cursor
import time, sys, os, threading

path = os.getcwd()

url = "http://textmechanic.com/text-tools/combination-permutation-tools/line-combination-generator/"

formations = """inurl:
intext:"
allintext:"
allintitle:"
source:"
filetype:"
insubject:"
allinanchor:"
allinurl:"
cache:"
inanchor:"
info:"
intitle:"
link:"""

pageformats = """. ?
.ashx?
.asinx?
.asp?
.aspx?
.blog?
.blog?
.bml?
.cat?
.cfm?
.cgi?
.contact-us?
.events?
.exe?
.esp?
.file?
.File?
.flv?
.htm?
.html?
.jsf?
.jsp?
.jspa?
.pdf?
.php?
.php3?
.php4?
.phpx?
.phtml?
.products?
.psml?
.raw?
.site?
.swf?
.tss?
.vpn?
"""

pagetypes = """abstractid=
accountid=
acctid=
accvideoid=
acid=
actionid=
ActionID=
ActionTypeID=
activepageid=
ActivityID=
actorid=
ActorID=
addressID=
AdID=
AdListingID=
adsid=
advid=
affiliateid=
affiliateID=
afid=
agentid=
agentID=
AGID=
aID=
AID=
albumid=
albumID=
AlbumID=
alertid=
ALID=
altgrpid=
altid=
anagrpid=
announcementid=
apparaatID=
appid=
AppID=
appids=
ApplicationID=
ApplicationIDMaster=
appsessionid=
archiveid=
areaid=
ARid=
armorid=
artcatid=
articleid=
articleID=
ArticleID=
ARTICLEID=
articlesid=
ArticleUid=
artid=
artID=
ArtID=
ARTID=
ARTIDX=
artikulid=
artistid=
ArtistID=
ArtistsID=
artsid=
asid=
AskSiteID=
assetGUID=
assetid=
associationid=
attachid=
attachID=
AttachID=
attachmentid=
auctionID=
audiofileid=
auid=
authid=
authorid=
authorID=
AuthorID=
authproviders=
AutoID=
avdaccessid=
AvdID=
avibaseid=
azkid=
backgroundid=
bandid=
bandID=
BandID=
bandsID=
bandwidth=
bankid=
BANKID=
bannerid=
barid=
basePageID=
BaslikID=
bctid=
bctovarid=
BigGameID=
BikeID=
bikeIDMaster=
bikeModelID=
bikid=
bioid=
BizLinkCATID=
BIZUNLID=
blockid=
BLOCKID=
blogentryid=
"""

f = open(path + '/results/keywords.txt')
line = f.readlines()
keywords = line
options = Options()
service = Service(path + '/lib/chromedriver')
options.headless = False
PATH = path + "/lib/chromedriver"
driver = webdriver.Chrome(options=options, service=service)
driver.get(url)
time.sleep(1)

button = driver.find_element_by_xpath("/html/body/div[1]/div/div/div/div/div[1]/table/tbody/tr/td[7]/div/input[2]")
button.click()
button2 = driver.find_element_by_xpath("/html/body/div[1]/div/div/div/div/div[1]/table/tbody/tr/td[9]/div/input[2]")
button2.click()
button3 = driver.find_element_by_xpath("/html/body/div[1]/div/div/div/div/div[1]/table/tbody/tr/td[11]/div/input[2]")
button3.click()

obj1 = driver.find_element_by_id('input0')
obj2 = driver.find_element_by_id('input1')
obj3 = driver.find_element_by_id('input2')
#obj6 = driver.find_element_by_id('input5')

obj1.send_keys(formations)
obj2.send_keys(keywords)
obj3.send_keys(pageformats)
#obj6.send_keys()

button4 = driver.find_element_by_xpath('/html/body/div[1]/div/div/div/div/div[2]/input[1]')
button4.click()

time.sleep(2)



x = driver.find_element_by_id('output')
x.click()
print(x)
open("results/grabbed.txt", "w").write(str(x.text))

save = driver.find_element_by_xpath('/html/body/div[1]/div/div/div/div/div[3]/input[1]')
save.click()