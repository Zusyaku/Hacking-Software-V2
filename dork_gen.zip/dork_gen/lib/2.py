#!/usr/bin/python3
f = open('results/made_keywords.txt','r')
for line in f:
	x = open('results/keywords2.txt','a')
	if len(line) > 3:
		x.write(line)
