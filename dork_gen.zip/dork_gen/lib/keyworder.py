#!/usr/bin/python3
import requests
from selenium.webdriver.common.keys import Keys
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from bs4 import BeautifulSoup as soup
from urllib.request import urlopen as req
from selenium import webdriver
from colorama import Fore, Cursor
import time, sys, os, threading

pat = os.getcwd()

keyword = input(Fore.RED + "[>] " + Fore.BLUE + "Enter a basic keyword:" + Fore.GREEN + " ")
options = Options()
service = Service(pat + '/lib/chromedriver')
options.headless = True
PATH = pat + "/lib/chromedriver"
driver = webdriver.Chrome(options=options, service=service)

key = 'inurl: "' + keyword + '" + intitle: "' + keyword + '" + intext: "' + keyword + '"'
print("\nUsing Syntax : " + key + "\n")

url = "https://cse.google.com/cse?cx=013991603413798772546:ku75d_g_s6a#gsc.tab=0&gsc.q=" + key

urls = ['https://cse.google.com/cse?cx=013991603413798772546:ku75d_g_s6a#gsc.tab=0&gsc.q=',
'https://www.google.com/search?q=',
'https://duckduckgo.com/?q=',
'https://www.bing.com/search?q=',
'https://search.yahoo.com/search?p=',
'https://de.ask.com/web?q=',
'https://search.aol.com/aol/search;?q=',
'https://yandex.com/search/?text=',
'https://www.ecosia.org/search?q=',
'http://www.arama.com/search.php?what=',
'http://rechercher.aliceadsl.fr/google.pl?qs=',
'https://www.arcor.de/arcor/search?q=',
'https://www.austronaut.at/suchergebnis/?q=',
'http://search.babylon.com/?q=',
'http://www.suchmaschine.com/products.php?s=',
'https://digg.com/search?q=',
'https://www.everyclick.com/results?q=',
'https://social.excite.it/search/main/?searchText=',
'https://social.excite.es/search/main/?searchText=',
'https://social.excite.nl/search/main/?searchText=',
'http://www.exalead.fr/search/web/results/?q=',
'https://fireball.com/search?q=',
'https://search.hotbot.com/web?q=',
'https://search.lycos.com/web/?q=',
'https://go.mail.ru/search?q=',
'https://search.meta.ua/search.asp?q=',
'https://metager.de/meta/meta.ger3?eingabe=',
'https://search.monstercrawler.com/serp?q=',
'https://www.search.com/web?q=',
'https://www.search.ch/?q=',
'https://search.seznam.cz/?q=',
'https://suche.t-online.de/fast-cgi/tsc?q=',
'https://www.zoohoo.cz/search/?q=']

#driver.get(url)
#x = driver.find_element_by_tag_name("div")
#f = open("results/unsorted.txt", "a")
#f.write(x.text)

for t in urls:
	try:
		print(Fore.GREEN + "[i] " + Fore.YELLOW + "Trying " + Fore.BLUE + t + key)
		driver.get(t+key)
		x = driver.find_element_by_tag_name("div")
		f = open(pat + "/results/unsorted.txt", "a")
		f.write(x.text)
	except Exception:
		pass
