echo -e '\e[36;1m ____  ___ _____ _____ ___ _____ 
|    \|   | __  |  |  |_  | __  |
|  |  | | |    -|    -|_  |    -|
|____/|___|__|__|__|__|___|__|__|'
echo -e "\e[31;1m"
python <<< "import sys, os, time
gg = '\tFuCk YoU GooGlE.....\n\n'
for i in gg:
    sys.stdout.write(i)
    sys.stdout.flush()
    time.sleep(0.04)"
