#!/bin/bash


# colors

# Reset

rs='\033[m'

# Regular Colors

r='\033[1;31m'
g='\033[1;32m'
y='\033[1;33m'
b='\033[1;34m'
p='\033[1;35m'
c='\033[1;36m'
w='\033[1;37m'

# Background

or='\033[41m'
og='\033[42m'
oy='\033[43m'
ob='\033[44m'
op='\033[45m'
oc='\033[46m'
ow='\033[47m'

# Bold

bd='\033[1m'

# Blink

l='\033[5m'

# Other Variables

file=""
path=$(pwd)
on=1
off=0
keywords="${path}/sources/keywords.txt"
pagetypes="${path}/sources/pagetypes.txt"
pageformats="${path}/sources/pageformats.txt"
search_options="${path}/sources/search_options.txt"
extensions="${path}/sources/extensions.txt"
hqkeywords="${path}/sources/hq_keywords.txt"


#kw - keyword
#pt - page type
#pf - page format
#sf - search function
#de - domain extension

dorktypes(){
	'
	(KW).(PF)?(PT)=
	(KW).(PF)?(PT)= site:(DE)
	(SF)".(DE)" + "(KW)"
	(SF)(KW).(PF)?(PT)=
	(SF)(KW).(PF)?(PT)= site:(DE)
	(SF)(PT)=(KW).(PF)? site:(DE)
	(SF)"(KW)" + "(DE)".(PF)?(PT)=
	.(PF)?(PT)="(KW)"
	(PT)="KW)" + ".(DE)"
	.(PF)? (SF).(DE)
	(SF).(DE).(PF)?
	'
}


banner(){
	clear
	ban=$(cat lib/settings.conf | grep banner | cut -d'=' -f2)
	if [[ ${ban} == 0 ]]; then
		python <<< "import random, os , sys
banner=[1,2,3,4,5]
x = random.choice(banner)
os.system('bash lib/banner{}.sh'.format(x))"
	elif [[ ${ban} == 1 ]]; then
		bash lib/banner1.sh
	elif [[ ${ban} == 2 ]]; then
		bash lib/banner2.sh
	elif [[ ${ban} == 3 ]]; then
		bash lib/banner3.sh
	elif [[ ${ban} == 4 ]]; then
		bash lib/banner4.sh
	elif [[ ${ban} == 5 ]]; then
		bash lib/banner5.sh
	fi

    echo -e "\e[33;1m"
	python <<< "import sys, os, time

ms0g = '\tWELCOME TO THE DORK TOOLKIT BY VIPERZCREW\n\n'
for i in ms0g:
    sys.stdout.write(i)
    sys.stdout.flush()
    time.sleep(0.05)"
	file_checker
}

file_checker(){
	fi=$(cat lib/settings.conf | grep file_checker | cut -d'=' -f2)
	if [[ ${fi} == ${off} ]]; then
		package_checker	
	elif [[ ${fi} == ${on} ]]; then
		figlet -f slant -c "File Checker"
		echo -e "\n\n"; sleep 0.5
		if [ -d ${path}/lib ]; then
			sleep 0.5
			echo -e "${b}[${g}✓${b}] ${y}Found ${p}lib ${y}folder on ${r}$path/lib"
		else
			sleep 0.5
			echo -e "${b}[${g}✘${b}] ${y}Ups... Creating ${p}lib ${y}folder on ${r}$path/lib"
			mkdir ${path}/lib
		fi

		if [ -d ${path}/results ]; then
			sleep 0.5
			echo -e "${b}[${g}✓${b}] ${y}Found ${p}results ${y}folder on ${r}$path/results"
		else
			sleep 0.5
			echo -e "${b}[${g}✘${b}] ${y}Ups... Creating ${p}results ${y}folder on ${r}$path/results"
			mkdir ${path}/results
		fi

		if [ -d ${path}/sources ]; then
			sleep 0.5
			echo -e "${b}[${g}✓${b}] ${y}Found ${p}sources ${y}folder on ${r}$path/sources"
		else
			sleep 0.5
			echo -e "${b}[${g}✘${b}] ${y}Ups... Creating ${p}sources ${y}folder on ${r}$path/sources"
			mkdir ${path}/sources
		fi

		if [ -f sources/keywords.txt ]; then
			echo -e "${b}[${g}✓${b}] ${y}Found ${p}keywords ${y}file on ${r}$path/sources/keywords.txt"
		else
			echo -e "${b}[${g}✘${b}] ${y}Ups... Creating ${p}keywords ${y}file on ${r}$path/sources/keywords.txt"
			touch ${path}/sources/keywords.txt
		fi

		if [ -f sources/extensions.txt ]; then
			sleep 0.5
			echo -e "${b}[${g}✓${b}] ${y}Found ${p}extensions ${y}file on ${r}$path/sources/extensions.txt"
		else
			sleep 0.5
			echo -e "${b}[${g}✘${b}] ${y}Ups... Creating ${p}extensions ${y}file on ${r}$path/sources/extensions.txt"
			touch ${path}/sources/extensions.txt
		fi

		if [ -f sources/pageformats.txt ]; then
			sleep 0.5
			echo -e "${b}[${g}✓${b}] ${y}Found ${p}pageformats ${y}file on ${r}$path/sources/pageformats.txt"
		else
			sleep 0.5
			echo -e "${b}[${g}✘${b}] ${y}Ups... Creating ${p}pageformats ${y}file on ${r}$path/sources/pageformats.txt"
			touch ${path}/sources/pageformats.txt
		fi	

		if [ -f sources/pagetypes.txt ]; then
			sleep 0.5
			echo -e "${b}[${g}✓${b}] ${y}Found ${p}pagetypes ${y}file on ${r}$path/sources/pagetypes.txt"
		else
			sleep 0.5
			echo -e "${b}[${g}✘${b}] ${y}Ups... Creating ${p}pagetypes ${y}file on ${r}$path/sources/pagetypes.txt"
			touch ${path}/sources/pagetypes.txt
		fi

		if [ -f sources/search_options.txt ]; then
			sleep 0.5
			echo -e "${b}[${g}✓${b}] ${y}Found ${p}search_options ${y}file on ${r}$path/sources/search_options.txt"
		else
			sleep 0.5
			echo -e "${b}[${g}✘${b}] ${y}Ups... Creating ${p}search_options ${y}file on ${r}$path/sources/search_options.txt"
			touch ${path}/sources/search_options.txt
		fi

		if [ -f sources/hq_keywords.txt ]; then
			sleep 0.5
			echo -e "${b}[${g}✓${b}] ${y}Found ${p}hq_keywords ${y}file on ${r}$path/sources/hq_keywords.txt"
		else
			sleep 0.5
			echo -e "${b}[${g}✘${b}] ${y}Ups... Creating ${p}hq_keywords ${y}file on ${r}$path/sources/hq_keywords.txt"
			touch ${path}/sources/hq_keywords.txt
		fi
		clear
		package_checker
	fi
}

package_checker(){
		pck=$(cat lib/settings.conf | grep package_checker | cut -d'=' -f2)
		if [[ ${pck} == ${on} ]]; then
			figlet -f slant -c "Package Checker"
			if ! command -v wc &>/dev/null; then
				echo -e "${b}[${g}✘${b}] ${y}Ups... Command not found."
				sudo apt install wc -y
			else
				echo -e "${b}[${g}✓${b}] ${p}wc ${y}Found!" 
			fi
			if ! command -v shuf &>/dev/null; then
				echo -e "${b}[${g}✘${b}] ${y}Ups... Command not found."
				sudo apt install shuf -y
			else
				echo -e "${b}[${g}✓${b}] ${p}shuf ${y}Found!\n" 
				configuration
			fi
		elif [[ ${pck} == ${off} ]]; then
			configuration
		fi
}

configuration(){
	conf=$(cat lib/settings.conf | grep configuration | cut -d'=' -f2)
	
	if [[ ${conf} == ${off} ]]; then
		menu
	elif [[ ${conf} == ${on} ]]; then
		echo -ne "${b}[${g}*${b}] ${y}Choose path(${c}Current:${r}${path} ${y}\n\n>>> ${b}NOTE: ${r}leave blank if you don't know${y}):${g} "
		read output
		if [[ "${output}" == "" ]]; then
			path=${path}
			echo -ne "\n${b}[${g}i${b}] ${y}Choosed ${r}${path} ${y}as path."; sleep 0.5
		elif [[ "${output}" != ${path} ]]; then
			echo -e "\n${y}[${r}!${y}] ${b}Heyja- please check the directory."; sleep 0.5
			path=${path}
			echo -ne "\n${b}[${g}i${b}] ${y}Choosed ${r}${path} ${y}as path."; sleep 0.5
		else
			path="${output}"
		fi
		echo -e "\n\n${b}[${g}i${b}] ${y}Reading files "; sleep 1
		menu
	fi
}

generator(){
	clear
	if [ -f results/results/dorks.txt ]; then
		rm results/results/dorks.txt
	fi
	clear; figlet -f slant "Generator"
	echo -ne "${b}[${g}*${b}] ${y}How many dorks do you want generate${y}\n\n>>> ${b}NOTE: ${r}10 = ~120 Dorks${y}):${g} "
	read count
	e=0
	while [ $e -le ${count} ]
	do
		# Used Some Dork Types, You Can Add Manually Your Own.



		kw=$(shuf -n 1 ${keywords})
		pf=$(shuf -n 1 ${pageformats})
		pt=$(shuf -n 1 ${pagetypes})
		de=$(shuf -n 1 ${extensions})
		sf=$(shuf -n 1 ${search_options})
		hkw=$(shuf -n 1 ${hqkeywords})
		echo "${kw}.${pf}?${pt}=" >> results/dorks.txt
		echo "${kw}.${pf}?${pt}= site:${de}" >> results/dorks.txt
		echo "${sf}" ${de} + "${kw}" >> results/dorks.txt
		echo "${sf}${kw}.${pf}?${pt}=" >> results/dorks.txt
		echo "${sf}${kw}.${pf}?${pt}= site:${de}" >> results/dorks.txt
		echo "${sf}${pt}=${kw}.${pf}? site:${de}" >> results/dorks.txt
		echo ${sf}"${kw}" + "${de}".${pf}?${pt}= >> results/dorks.txt
		echo .${pf}?${pt}="${kw}" >> results/dorks.txt
		echo ${pt}="${kw}" + "${de}" >> results/dorks.txt
		echo ${pt}="${kw}".${pf}? site:${de} >> results/dorks.txt
		echo ".${pf}? ${sf}${de}" >> results/dorks.txt
		e=$(( $e + 1 ))
	done	
	mv results/dorks.txt results/tmp 
	sort -u results/tmp | uniq >> results/dorks.txt && rm -rf results/tmp
	x=$(wc -l results/dorks.txt | awk {'print $1'})
	echo -e "${b}[${g}i${b}] ${y}Mixxing dorks ${r}please wait! ${y}"; sleep 0.5
	sort -R results/dorks.txt >> results/sorted.txt; rm results/dorks.txt
	sort -R results/sorted.txt >> results/dorks.txt; rm results/sorted.txt
	sort -R results/dorks.txt >> results/sorted.txt; rm results/dorks.txt
	sort -R results/sorted.txt >> results/dorks.txt; rm results/sorted.txt
	echo -e "${b}[${g}✓${b}] ${y}Success. ${p}${x} ${y} Dorks has been generated"; sleep 0.2
	echo -ne "${b}[${g}i${b}] ${y}Press [ENTER] to go to menu."; sleep 0.2
	read end
	bash dork_gen.sh
}

adv_generator(){
	clear
	if [ -f results/adv_dorks.txt ]; then
		rm results/adv_dorks.txt
	fi
	figlet -f slant "AdvGenerator"
	echo -ne "\n\n${b}[${g}*${b}] ${y}How many dorks do you want generate${y}\n\n>>> ${b}NOTE: ${r}10 = ~140(advanced only)/~260 Dorks(basic)${y}):${g} "; sleep 1
	read count
	echo -ne "\n${b}[${g}*${b}] ${y}Do you want use basic dork types?[${g}Y${y}/${r}N${y}]${y}(${r}default:${w}y${y}):${w} "; sleep 0.5
	read old
	if [ -f ${path}/sources/hq_keywords.txt ]; then
		le=$(wc -l ${path}/sources/hq_keywords.txt | awk '{print $1}')
		if [[ "${le}" == 0 ]]; then
			echo -e "${y}[${r}!${y}] ${b}Please add some HQ Keywords!"; sleep 0.5
			echo -e "${y}[${g}i${y}] ${b}This can be done here : ${r}${path}/sources/hq_keywords.txt"; sleep 0.5
			bash dork_gen.sh
		fi
	else
		echo -e "${y}[${r}!${y}] ${b}No Keyword File Found - Creating One."; sleep 0.5
		touch ${path}/sources/hq_keywords.txt
		exit
	fi

	if [[ "${old}" == "Y" || "${old}" == "y" ]]; then
		e=0
		while [ $e -le ${count} ]
		do
			kw=$(shuf -n 1 ${keywords})
			pf=$(shuf -n 1 ${pageformats})
			pt=$(shuf -n 1 ${pagetypes})
			de=$(shuf -n 1 ${extensions})
			sf=$(shuf -n 1 ${search_options})
			hkw=$(shuf -n 1 ${hqkeywords})
			echo "${kw}.${pf}?${pt}=" >> results/adv_dorks.txt
			echo "${kw}.${pf}?${pt}= site:${de}" >> results/adv_dorks.txt
			echo "${sf}" ${de} + "${kw}" >> results/adv_dorks.txt
			echo "${sf}${kw}.${pf}?${pt}=" >> results/adv_dorks.txt
			echo "${sf}${kw}.${pf}?${pt}= site:${de}" >> results/adv_dorks.txt
			echo "${sf}${pt}=${kw}.${pf}? site:${de}" >> results/adv_dorks.txt
			echo ${sf}"${kw}" + "${de}".${pf}?${pt}= >> results/adv_dorks.txt
			echo .${pf}?${pt}="${kw}" >> results/adv_dorks.txt
			echo ${pt}="${kw}" + "${de}" >> results/adv_dorks.txt
			echo ${pt}="${kw}".${pf}? site:${de} >> results/adv_dorks.txt
			echo ".${pf}? ${sf}${de}" >> results/adv_dorks.txt
			echo "${kw} / .${pf}? + site=${de}" >> results/adv_dorks.txt
			echo "${kw} / .${pf}?${pt}= site:${de}" >> results/adv_dorks.txt
			echo "${kw}" ?${pt}= site:${de} >> results/adv_dorks.txt 
			echo "${kw} / ${pf}= + site:${de}" >> results/adv_dorks.txt
			echo "${kw}" + "${hkw}" / ?${pf}=${pt} + site:${de} >> results/adv_dorks.txt
			echo .${pf}? + "${de}" = ${kw} >> results/adv_dorks.txt
			echo .${pf}?"${hkw}" + "${de}" ${pt}= >> results/adv_dorks.txt
			echo ${sf}${pt}= "${hkw}" + "${de}" >> results/adv_dorks.txt
			echo ${pt}= ${sf}"${hkw}" >> results/adv_dorks.txt
			echo .${pf}?${sf}"${hkw}" ${pt}= >> results/adv_dorks.txt
			echo "${de}" "${hkw}".${pf}? >> results/adv_dorks.txt
			echo ${sf}${pt}= + "${hkw}".${pf}? >> results/adv_dorks.txt
			echo "${pt}= ${kw}.${pf}? ${sf}${de}" >> results/adv_dorks.txt

			# printing the dorks

#			echo "${kw}.${pf}?${pt}="
#			echo "${kw}.${pf}?${pt}= site:${de}"
#			echo "${sf}" ${de} + "${kw}"
#			echo "${sf}${kw}.${pf}?${pt}="
#			echo "${sf}${kw}.${pf}?${pt}= site:${de}"
#			echo "${sf}${pt}=${kw}.${pf}? site:${de}"
#			echo ${sf}"${kw}" + "${de}".${pf}?${pt}=
#			echo .${pf}?${pt}="${kw}" 
#			echo ${pt}="${kw}" + "${de}" 
#			echo ${pt}="${kw}".${pf}? site:${de}
#			echo ".${pf}? ${sf}${de}" 
#			echo "${kw} / .${pf}? + site=${de}" 
#			echo "${kw} / .${pf}?${pt}= site:${de}"
#			echo "${kw}" ?${pt}= site:${de}  
#			echo "${kw} / ${pf}= + site:${de}" 
#			echo "${kw}" + "${hkw}" / ?${pf}=${pt} + site:${de} 
#			echo .${pf}? + "${de}" = ${kw} 
#			echo .${pf}?"${hkw}" + "${de}" ${pt}=
#			echo ${sf}${pt}= "${hkw}" + "${de}" 
#			echo ${pt}= ${sf}"${hkw}" 
#			echo .${pf}?${sf}"${hkw}" ${pt}= 
#			echo "${de}" "${hkw}".${pf}? 
#			echo ${sf}${pt}= + "${hkw}".${pf}? 
#			echo "${pt}= ${kw}.${pf}? ${sf}${de}"

			e=$(( $e + 1 ))
		done	
		mv results/adv_dorks.txt results/tmp
		sort -u results/tmp | uniq >> results/adv_dorks.txt && rm -rf results/tmp
		echo -e "\n${b}[${g}i${b}] ${y}Mixxing dorks ${r}please wait :)${y}"; sleep 0.5
		sort -R results/adv_dorks.txt >> results/sorted.txt; rm results/adv_dorks.txt
		sort -R results/sorted.txt >> results/adv_dorks.txt; rm results/sorted.txt
		sort -R results/adv_dorks.txt >> results/sorted.txt; rm results/adv_dorks.txt
		sort -R results/sorted.txt >> results/adv_dorks.txt; rm results/sorted.txt
		sort -R results/adv_dorks.txt >> results/sorted.txt; rm results/adv_dorks.txt
		sort -R results/sorted.txt >> results/adv_dorks.txt; rm results/sorted.txt
		sort -R results/adv_dorks.txt >> results/sorted.txt; rm results/adv_dorks.txt
		sort -R results/sorted.txt >> results/adv_dorks.txt; rm results/sorted.txt
		sort -R results/adv_dorks.txt >> results/sorted.txt; rm results/adv_dorks.txt		
		sort -R results/sorted.txt >> results/adv_dorks.txt; rm results/sorted.txt
		x=$(wc -l results/adv_dorks.txt | awk {'print $1'})
		echo -e "\n${b}[${g}✓${b}] ${y}Success. ${p}${x} ${y}Dorks has been generated"; sleep 0.2
		echo -ne "\n${b}[${g}i${b}] ${y}Press [ENTER] to go to menu."; sleep 0.2
		read end
		bash dork_gen.sh
	else
		e=0
		while [ $e -le ${count} ]
		do
			kw=$(shuf -n 1 ${keywords})
			pf=$(shuf -n 1 ${pageformats})
			pt=$(shuf -n 1 ${pagetypes})
			de=$(shuf -n 1 ${extensions})
			sf=$(shuf -n 1 ${search_options})
			hkw=$(shuf -n 1 ${hqkeywords})
			echo "${kw} / .${pf}? + site=${de}" >> results/adv_dorks.txt
			echo "${kw} / .${pf}?${pt}= site:${de}" >> results/adv_dorks.txt
			echo "${kw}" ?${pt}= site:${de} >> results/adv_dorks.txt 
			echo "${kw} / ${pf}= + site:${de}" >> results/adv_dorks.txt
			echo "${kw}" + "${hkw}" / ?${pf}=${pt} + site:${de} >> results/adv_dorks.txt
			echo .${pf}? + "${de}" = ${kw} >> results/adv_dorks.txt
			echo .${pf}?"${hkw}" + "${de}" ${pt}= >> results/adv_dorks.txt
			echo ${sf}${pt}= "${hkw}" + "${de}" >> results/adv_dorks.txt
			echo ${pt}= ${sf}"${hkw}" >> results/adv_dorks.txt
			echo .${pf}?${sf}"${hkw}" ${pt}= >> results/adv_dorks.txt
			echo "${de}" "${hkw}".${pf}? >> results/adv_dorks.txt
			echo ${sf}${pt}= + "${hkw}".${pf}? >> results/adv_dorks.txt
			echo "${pt}= ${kw}.${pf}? ${sf}${de}" >> results/adv_dorks.txt
			e=$(( $e + 1 ))
		done
		mv results/adv_dorks.txt results/tmp
		sort -u results/tmp | uniq >> results/adv_dorks.txt && rm -rf results/tmp
		echo -e "\n${b}[${g}i${b}] ${y}Mixxing dorks ${r}please wait :)${y}"; sleep 0.5
		sort -R results/adv_dorks.txt >> results/sorted.txt; rm results/adv_dorks.txt
		sort -R results/sorted.txt >> results/adv_dorks.txt; rm results/sorted.txt
		sort -R results/adv_dorks.txt >> results/sorted.txt; rm results/adv_dorks.txt
		sort -R results/sorted.txt >> results/adv_dorks.txt; rm results/sorted.txt
		sort -R results/adv_dorks.txt >> results/sorted.txt; rm results/adv_dorks.txt
		sort -R results/sorted.txt >> results/adv_dorks.txt; rm results/sorted.txt
		sort -R results/adv_dorks.txt >> results/sorted.txt; rm results/adv_dorks.txt
		sort -R results/sorted.txt >> results/adv_dorks.txt; rm results/sorted.txt
		sort -R results/adv_dorks.txt >> results/sorted.txt; rm results/adv_dorks.txt
		sort -R results/sorted.txt >> results/adv_dorks.txt; rm results/sorted.txt
		x=$(wc -l results/adv_dorks.txt | awk {'print $1'})
		echo -e "\n${b}[${g}✓${b}] ${y}Success. ${p}${x} ${y}Dorks has been generated"; sleep 0.2
		echo -ne "\n${b}[${g}i${b}] ${y}Press [ENTER] to go to menu."; sleep 0.2
		read end
		bash dork_gen.sh
	fi
}

cust_dorks(){

	mix_soft() {
		figlet -f slant "Soft Mixxer"
		echo -e "\n\n"
		ls results/*.txt
		echo -ne "\n${b}[${g}*${b}] ${y}Enter dorks file>${r} "
		read file
		echo -e "\n${b}[${g}*${b}] ${y}Mixxing dorks on softway, keeping original."
		cat results/${file} | awk '{print $1,"+",$4,$3,$2}' | tr -s ' ' ' ' | tr -s '[:upper:]' '[:lower:]' | sed 's/^. +//g' | sed 's/^ ././g' > results/soft_mixed_dorks.txt
		echo -e "\n${b}[${g}✓${b}] ${y}Dorks has been generated & saved as ${g}soft_mixed.txt"; sleep 0.2
		echo -ne "\n${b}[${g}i${b}] ${y}Press [ENTER] to go to menu."; sleep 0.2
		read end
		bash dork_gen.sh
	}
	
	mix_hard(){
		figlet -f slant "Hard Mixxer"
		echo -e "\n\n"
		ls results/*.txt
		echo -ne "\n${b}[${g}*${b}] ${y}Enter dorks file>${r} "
		read file
		echo -e "\n${b}[${g}*${b}] ${y}Mixxing dorks on hardway, this could take some time ${b}:)"
		cat results/${file} | awk '{print $2,$3,$1,$4}' | tr -s ' ' ' ' | sed 's/^[+/]//g' | sed 's/^ //g' > results/hard_mixed.txt
		echo -e "\n${b}[${g}✓${b}] ${y}Dorks has been generated & saved as ${g}hard_mixed.txt"; sleep 0.2
		echo -ne "\n${b}[${g}i${b}] ${y}Press [ENTER] to go to menu."; sleep 0.2
		read end
		bash dork_gen.sh
	}
	
	clear_drk(){
		figlet -f slant "Clear Dorks"
		echo -e "\n\n"
		ls results/*.txt
		echo -ne "\n${b}[${g}*${b}] ${y}Enter dorks file>${r} "
		read file
		echo -e "\n${b}[${g}*${b}] ${y}Clearing your dorks file as much as possbile${b} :D"
		cat results/${file} | tr -s '[:upper:]' '[:lower:]' | tr -s ' ' ' ' | tr -s '\n' '\n' |  tr -s "/ ." " " | sed 's/^[ ]//' | sed 's/site: /site:./' | awk '!NF || !seen[$0]++' > results/cleared.txt
		echo -e "\n${b}[${g}✓${b}] ${y}Dorks has been generated & saved as ${g}cleared.txt"; sleep 0.2
		echo -ne "\n${b}[${g}i${b}] ${y}Press [ENTER] to go to menu."; sleep 0.2
		read end
		bash dork_gen.sh
	}

	clear
	figlet -f slant "Customize Dorks"
	echo -ne "\n\n${b}[${g}*${b}] ${y}Listing some customizing options....${b}\n\n"; sleep 1
	clear
	figlet -f slant "Customize Dorks"
	echo -e "\n\n
${p}[${w}1${p}] ${y}Mixxing dorks ${p}[${r}SOFT${p}]
${p}[${w}2${p}] ${y}Mixxing dorks ${p}[${r}HARD${p}]
${p}[${w}3${p}] ${y}Clearing dorks
${p}[${w}99${p}] ${y}Back To Menu
	"
	xx=0
	while [ $xx = 0 ]
	do
		echo -ne "${b}[${r}>${b}] ${y}Choose:${c} "
		read option
		case "$option" in
			1) mix_soft; xx=1;;
			2) mix_hard; xx=1;;
			3) clear_drk; xx=1;;
			99) bash dork_gen.sh; xx=1;;
			*) echo -e "${r}[!] ${b}WRONG INPUT ${y}(${p}>${g}\_/${p}<${y})"; xx=0;;
		esac
	done
}

edit_src(){
	clear; figlet -f slant "Sources"
	echo -e "\n\n\n"
	echo -ne "${b}[${r}!${b}] ${r}WARNING : ${y}You want to edit the sources, wrong edit will break this tool.\nDo you want to continue ?[${g}Y${b}/${r}N${y}] "; read exe
	if [[ "${exe}" == "y" || "${exe}"  == "Y" ]]; then
		clear
		echo -e "${g}What do you want to edit?
${b}[${g}1${b}] ${r}Extensions
${b}[${g}2${b}] ${r}Search Options
${b}[${g}3${b}] ${r}Keywords
${b}[${g}4${b}] ${r}HQ Keywords
${b}[${g}5${b}] ${r}Pagetypes
${b}[${g}6${b}] ${r}Pageformats
\n${b}[${g}99${b}] ${r}Exit\n\n
		"
		xxx=0
		while [ $xxx = 0 ] 
		do 
			echo -ne "${y}>>>${b} "
			read ot
			case "${ot}" in
				1) nano ${path}/sources/extensions.txt; xxx=0;;
				2) nano ${path}/sources/search_options.txt; xxx=0;;
				3) nano ${path}/sources/keywords.txt; xxx=0;;
				4) nano ${path}/sources/hq_keywords.txt; xxx=0;;
				5) nano ${path}/sources/pagetypes.txt; xxx=0;;
				6) nano ${path}/sources/pageformats.txt; xxx=0;;
				99) menu; xxx=1;;
				*) echo -e "${r}[!] Dude Read Again!"; xxx=0;;
			esac
		done
	else
		clear; echo -e "${r}b${g}y${b}e${c}!"; sleep 1
		menu
	fi
}

cleaner(){
	clear; figlet -f slant "Cleaner"
	echo -ne "\n${b}[${g}i${b}] ${y}Press enter to clear results"; read p; clear
	sleep 2; echo -e "${b}[${y}*${b}] ${y}Removing ${r}*ALL* ${y}Results"; clear
	rm -rf results/*.txt
	echo -ne "\n${b}[${g}i${b}] ${y}Done, press [ENTER] to go to menu."; read p; clear; bash dork_gen.sh
}


keyword_grabber(){
	if [ -f results/grabbed_keywords.txt ]; then
		rm -rf results/grabbed_keywords.txt
	fi
	if [ -f results/unsorted.txt ]; then
		rm -rf results/unsorted.txt
	fi
	clear; figlet -f slant "Keyword Grabber"
	echo -ne "\n${b}[${g}i${b}] ${y}Press enter to continue"; read p; clear
	
	# The Following is commented because it's only grabbing keywords - i will edit it soon

	python3 lib/keyworder.py
	cat results/unsorted.txt | sed '/http/d' | sed '/:/d' | sed '/.com/d' | tr -s ' ' '\n' | grep '[[:alnum:]]' | tr -d '"[]$%&/\,;:().?' | sed "s/'//g" > results/made_keywords.txt
	python3 lib/2.py
	rm -rf made_keywords.txt
	cat results/keywords2.txt | tr -s '[:upper:]' '[:lower:]' | tr -d '[:digit:]' > results/keywords.txt # tr -d '`´°^áížšéý�č�Čůřé' 
	awk '!(count[$0]++)' results/keywords.txt > results/keywords2.txt; rm -rf results/keywords.txt
	mv results/keywords2.txt results/keywords.txt
	#python3 lib/mixer.py
	python3 lib/requester.py
	rea=$(wc -l results/grabbed_keywords.txt | awk '{print $1}')
	if [[ ${rea} == 1 ]]; then
		echo -ne "${b}[${r}!${b}] ${r}Sorry, 1 or less keywords generated, please try it later!\n${b}PRESS ENTER>>> "
		rea=""
		bash dork_gen.sh
		rm results/unsorted.txt results/made_keywords.txt results/keywords.txt 2>/dev/null
	else
		echo -ne "\n${b}[${g}i${b}] ${y}Done, saved ${r}${rea} ${y}keywords in ${r}results/grabbed_keywords.txt ${y}\nIf you want to get from this HQ keywords checkout number ${w}11\n${b}PRESS ENTER>>> "; read p; clear
		rea=""
		rm results/unsorted.txt results/made_keywords.txt results/keywords.txt 2>/dev/null
		bash dork_gen.sh
	fi
	
}

url2dorks(){
	clear; figlet -f slant "Url 2 Dorks"
	echo -e "\n\n\n"; sleep 0.5
	echo -e "\n${b}[${g}i${b}] ${y}Make sure you have imported your urls on results folder."; sleep 0.5
	echo -ne "\n${b}[${g}i${b}] ${y}Press enter to continue"; read p; echo -e "${r}"
	sleep .5
	ls ${path}/results/*.txt
	echo -ne "\n${b}[${g}i${b}] ${y}Please select the url file> "; read urlfile
	echo -e "\n${b}[${g}i${b}] ${y}Cleaning, wait..."; sleep 0.4
	cd results
	cat ${urlfile} | grep "?" | grep "php" | cut -d"/" -f4-10 | cut -d"?" -f2 | grep -v "%20" >> uncleared_dorks.txt
	cat uncleared_dorks.txt | tr -s ';' '/' > 1.txt; rm -rf uncleared_dorks.txt
	#cat ${urlfile} | grep "?" | grep "php" | cut -d"/" -f4-10 | cut -d"?" -f2 | grep -v "%20" | sed 's/^ //g' | tr -s '\n' '\n' | sed 's/^+ //g'
	cat 1.txt | tr -d '.' > 2.txt; rm -rf 1.txt
	cat 2.txt | tr -s '&' '?' > 3.txt; rm -rf 2.txt
	cat 3.txt | grep -v "/" | tr -s '\n' '\n' | sed 's/^//g' | sed 's/^+ //g' | sed 's/^ //g' > 4.txt; rm -rf 3.txt
	mv 4.txt urldorks.txt
	echo -ne "\n${b}[${g}i${b}] ${g}Yep, done.\n${y}Press enter to go back to menu"; read p
	cd ..; bash dork_gen.sh
}

url2pt(){
	clear; figlet -f slant "UrlToPT"
	echo -e "\n\n\n"; sleep 0.5
	echo -e "\n${b}[${g}i${b}] ${y}Make sure you have imported your urls on results folder."; sleep 0.5
	echo -ne "\n${b}[${g}i${b}] ${y}Press enter to continue"; read p; echo -e "${r}"
	sleep .5
	ls ${path}/results/*.txt
	echo -ne "\n${b}[${g}i${b}] ${y}Please select the url file> "; read urlfile
	echo -e "\n${b}[${g}i${b}] ${y}Extracting, wait..."; sleep 0.4
	cd results
	cat ${urlfile} | grep '=' | grep -Po '(?<=/).*(?=$)' | tr -s '\n' '\n' | grep "?" | cut -d"/" -f3-10 | sed -e 's/.*?\(.*\)=.*/\1/' | sort | cut -d"=" -f1 | tr -d "\-$&%~,._/" | grep -v '^=' | sed 's/$/=/g' | sort | uniq > pagetypes.txt
	cat ${urlfile} | grep "?" | cut -d"." -f5-100 | grep -P '(?<=.).*(?=$)' | tr -s '\n' '\n' | grep "?" | cut -d"?" -f1 | cut -d"/" -f1 | cut -d"." -f1 | awk -F, 'length($1) <= 7 {print $1}' | tr -d '_:&[:digit:]' | sort | uniq | sed 's/^/./g' | sed 's/$/?/g' > pageformats.txt
	echo -ne "\n${b}[${g}i${b}] ${g}Done with extracting.\nSaved as: {b}${path}/pagetypes.txt ${g}and ${b}${path}/pageformats.txt\n${y}Press enter to go back to menu"; read p
	cd ..; bash dork_gen.sh
}

url2key(){
	clear; figlet -f slant "Url2Key"
	echo -e "\n\n\n"; sleep 0.5
	echo -e "\n${b}[${g}i${b}] ${y}Make sure you have imported your urls on results folder."; sleep 0.5
	echo -ne "\n${b}[${g}i${b}] ${y}Press enter to continue"; read p; echo -e "${r}"
	sleep .5
	ls ${path}/results/*.txt
	echo -ne "\n${b}[${g}i${b}] ${y}Please select the url file> "; read urlfile
	echo -e "\n${b}[${g}i${b}] ${y}Extracting, wait..."; sleep 0.4
	cd results
	cat ${urlfile} | cut -d"/" -f4-6 | grep "-" | tr -s '-' ' ' | cut -d"/" -f1 | tr -s "%" " " | tr -s "?" " " | tr -s "&" " " | tr -s "." " " | sort | uniq | awk -F, 'length($1) <= 20 {print $1}' | sed 's/^ //g' | tr -s '=' ' ' > keys.txt
	echo -ne "\n${b}[${g}i${b}] ${g}Done with extracting.\nSaved as: {b}${path}/keys.txt \n${y}Press enter to go back to menu"; read p
	cd ..; bash dork_gen.sh
}

list2keys(){
	clear; figlet -f slant "Wordlist2Keys"
	echo -e "\n\n\n"; sleep 0.5
	echo -e "\n${b}[${g}i${b}] ${y}Make sure you have imported your wordlist on results folder."; sleep 0.5
	echo -ne "\n${b}[${g}i${b}] ${y}Press enter to continue"; read p; echo -e "${r}"
	sleep .5
	ls ${path}/results/*.txt
	echo -ne "\n${b}[${g}i${b}] ${y}Please select the wordlist file> "; read wordfile
	cd results
	cat ${wordfile} | tr -d '[:digit:]' | grep -o "[[:alpha:]]" | tr -s "[:upper:]" "[:lower:]" | tr -d '.,!?/()' | tr -s ' '  '\n' > keywords_wordfile.txt
	echo -ne "\n${b}[${g}i${b}] ${g}Done with extracting.\nSaved as: {b}${path}/keywords_wordfile.txt \n${y}Press enter to go back to menu"; read p
	cd ..; bash dork_gen.sh
}

settings(){
	
	# on = 1
	# off = 0
	
	enable(){
		clear
		echo -ne "\n${b}[${g}i${b}] ${y}Following is available to enable:"; sleep 0.2
		echo -e "\n
${b}[${r}>${b}] ${g}configuration
${b}[${r}>${b}] ${g}file_checker
${b}[${r}>${b}] ${g}package_checker		
${b}[${r}>${b}] ${g}back	

		"
		echo -ne "\n${b}[${w}*${b}] ${y}Choose: "
		read en
		if [[ ${en} == "configuration" ]]; then
			sed -i 's/configuration=0/configuration=1/g' lib/settings.conf
			enable
		elif [[ ${en} == "file_checker" ]]; then
			sed -i 's/file_checker=0/file_checker=1/g' lib/settings.conf
			enable
		elif [[ ${en} == "package_checker" ]]; then
			sed -i 's/package_checker=0/package_checker=1/g' lib/settings.conf
			enable
		elif [[ ${en} == "back" ]]; then
			settings
		else
			if [[ ${conf} == ${on} ]]; then
				echo -e "${p}[${r}!${p}] ${r}THIS IS ALREADY ENABLED!"
				enable
			elif [[ ${fi} == ${on} ]]; then
				echo -e "${p}[${r}!${p}] ${r}THIS IS ALREADY ENABLED!"
				enable
			elif [[ ${pck} == ${on} ]]; then
				echo -e "${p}[${r}!${p}] ${r}THIS IS ALREADY ENABLED!"
				enable
			fi
		fi
}

	disable(){
		clear
		echo -ne "\n${b}[${g}i${b}] ${y}Following is available to disable:"; sleep 0.2
		echo -e "\n
${b}[${r}>${b}] ${g}configuration
${b}[${r}>${b}] ${g}file_checker
${b}[${r}>${b}] ${g}package_checker		
${b}[${r}>${b}] ${g}back		
		"
		echo -ne "\n${b}[${w}*${b}] ${y}Choose: "
		read en
		if [[ "${en}" == "configuration" ]]; then
			sed -i 's/configuration=1/configuration=0/g' lib/settings.conf
			disable
		elif [[ "${en}" == "file_checker" ]]; then
			sed -i 's/file_checker=1/file_checker=0/g' lib/settings.conf
			disable
		elif [[ "${en}" == "package_checker" ]]; then
			sed -i 's/package_checker=1/package_checker=0/g' lib/settings.conf
			disable
		elif [[ "${en}" == "back" ]]; then
			settings
		else
			if [[ ${conf} == ${off} ]]; then
				echo -e "${p}[${r}!${p}] ${r}THIS IS ALREADY DISABLED!"
				enable
			elif [[ ${fi} == ${off} ]]; then
				echo -e "${p}[${r}!${p}] ${r}THIS IS ALREADY DISABLED!"
				enable
			elif [[ ${pck} == ${off} ]]; then
				echo -e "${p}[${r}!${p}] ${r}THIS IS ALREADY DISABLED!"
				enable
			fi
		fi
}

	change(){
		clear
		echo -ne "\n${b}[${g}i${b}] ${y}You can change banner to this:"; sleep 0.2
		echo -e "\n
${b}[${r}>${b}] ${g}1
${b}[${r}>${b}] ${g}2
${b}[${r}>${b}] ${g}3		
${b}[${r}>${b}] ${g}4
${b}[${r}>${b}] ${g}5
${b}[${r}>${b}] ${g}0
${b}[${r}>${b}] ${g}back

${w} BANNER TEMPLATES ARE AVAILABLE ON THE PDF
		"
		echo -ne "\n${b}[${w}*${b}] ${y}Choose: "
		read en

		if [[ ${en} == 1 ]]; then
			sed -i '${/banner/d;}' lib/settings.conf
			echo "banner=1" >> lib/settings.conf
			settings
		elif [[ ${en} == 2 ]]; then
			sed -i '${/banner/d;}' lib/settings.conf
			echo "banner=2" >> lib/settings.conf
			settings
		elif [[ ${en} == 3 ]]; then
			sed -i '${/banner/d;}' lib/settings.conf
			echo "banner=3" >> lib/settings.conf
			settings
		elif [[ ${en} == 4 ]]; then
			sed -i '${/banner/d;}' lib/settings.conf
			echo "banner=4" >> lib/settings.conf
			settings
		elif [[ ${en} == 5 ]]; then
			sed -i '${/banner/d;}' lib/settings.conf
			echo "banner=5" >> lib/settings.conf
			settings
		elif [[ ${en} == 0 ]]; then
			sed -i '${/banner/d;}' lib/settings.conf
			echo "banner=0" >> lib/settings.conf
			settings
		elif [[ ${en} == "back" ]]; then
			settings
		fi		
	
	}

	helper(){
		echo -e "
${w}enable ${c} - ${r}Enable settings
${w}disable ${c}- ${r}Disable settings
${w}change ${c} - ${r}Change tool logo
${w}reset ${c}  - ${r}Reset settings to original
${w}help ${c}   - ${r}Print this
${w}clear ${c}  - ${r}Clear screen 
${w}menu ${c}   - ${r}Go back to menu
		"
	}

	resetter(){
		clear
		echo -ne "\n${b}[${g}i${b}] ${y}Resetting original settings, please wait"; sleep 0.2
		echo "" > lib/settings.conf
		echo "
configuration=1                                                                       
file_checker=1                                                                      
package_checker=1                                                                     
banner=0
		" >> lib/settings.conf
		echo -ne "\n${b}[${g}i${b}] ${y}Done, press ${r}[ENTER] ${y}to go back to settings menu."; sleep 0.2
		read settings
		settings
	}

	clear
	figlet -f slant "Settings"
	echo -e "\n\n${b}[${g}*${b}] ${y}Please read the tutorial if you want to change the settings!\n\n"; sleep 0.5
	
	conf=$(cat lib/settings.conf | grep configuration | cut -d'=' -f2)
	fi=$(cat lib/settings.conf | grep file_checker | cut -d'=' -f2)
	ban=$(cat lib/settings.conf | grep banner | cut -d'=' -f2)
	pck=$(cat lib/settings.conf | grep package_checker | cut -d'=' -f2)
	
	if [[ ${conf} == ${on} ]]; then
		echo -e "${b}[${r}>${b}] ${y}Print Configuration   > ${g}ON"; sleep 0.2
	elif [[ ${conf} == ${off} ]]; then
		echo -e "${b}[${r}>${b}] ${y}Print Configuration   > ${r}OFF"; sleep 0.2
	fi

	if [[ ${pck} == ${on} ]]; then
		echo -e "${b}[${r}>${b}] ${y}Print Package Checker > ${g}ON"; sleep 0.2
	elif [[ ${pck} == ${off} ]]; then
		echo -e "${b}[${r}>${b}] ${y}Print Package Checker > ${r}OFF"; sleep 0.2
	fi
	
	if [[ ${fi} == ${on} ]]; then
		echo -e "${b}[${r}>${b}] ${y}Print File Checker    > ${g}ON"; sleep 0.2
	elif [[ ${fi} == ${off} ]]; then
		echo -e "${b}[${r}>${b}] ${y}Print File Checker    > ${r}OFF"; sleep 0.2
	fi

	if [[ ${ban} == 0 ]]; then
		echo -e "${b}[${r}>${b}] ${y}Banner \t\t  > ${g}RANDOM"; sleep 0.2
	elif [[ ${ban} == 1 ]]; then
		echo -e "${b}[${r}>${b}] ${y}Banner \t\t  > ${g}NUMBER#1"; sleep 0.2
	elif [[ ${ban} == 2 ]]; then
		echo -e "${b}[${r}>${b}] ${y}Banner \t\t  > ${g}NUMBER#2"; sleep 0.2
	elif [[ ${ban} == 3 ]]; then
		echo -e "${b}[${r}>${b}] ${y}Banner \t\t  > ${g}NUMBER#3"; sleep 0.2
	elif [[ ${ban} == 4 ]]; then
		echo -e "${b}[${r}>${b}] ${y}Banner \t\t  > ${g}NUMBER#4"; sleep 0.2
	elif [[ ${ban} == 5 ]]; then
		echo -e "${b}[${r}>${b}] ${y}Banner \t\t  > ${g}NUMBER#5"; sleep 0.2
	fi

	echo -e "\n${b}[${g}i${b}] ${y}Type 'help' to see a list of help\n"; sleep 0.1

	cc=0 
	while [ $cc = 0 ] 
	do
		echo -ne "${b}[${w}>${b}] ${y}~:${c} "
		read input
		case "${input}" in
			enable) enable; cc=1;;
			disable) disable; cc=1;;
			change) change; cc=1;;
			reset) resetter; cc=1;;
			help) helper; cc=0;;
			menu) bash dork_gen.sh; cc=1;;
			clear) clear; cc=0;;
			*) echo -e "${b}[${g}i${b}] ${y}Type 'help' to see a list of help\n"; sleep 0.1; cc=0 ;;
		esac
	done
}

tutorial(){
	clear; figlet -f slant "TUTORIAL"
	echo -e "${b}[${g}i${b}] ${y}At the moment we are not supporting terminal help.
Please read inside the PDF file inside ${b}tutorials/help.pdf ${y}if you don't know how to use this tool correctly.
I am still developing this tool, and i will try to add the keywords grabber asap.
	"
	echo -ne "\n${b}[${g}i${b}] ${y}Press enter to go back to menu"; read p
	cd ..; bash dork_gen.sh
}

menu(){
	
	clear
	echo -e "\t\t${p}[${r}+${p}]${b}=-=-=-=-=-=-=-=-=-=-=-=${p}[${r}+${p}]"; sleep .1; echo -ne "${g}"
	figlet "                 MENU"
	echo -e "\t\t${p}[${r}+${p}]${b}=-=-=-=-=-=-=-=-=-=-=-=${p}[${r}+${p}]\n\n"; sleep .1
	echo -ne "\t${p}[${w}1${p}] ${y}Generate Dorks"; sleep .1; echo -e "\t\t${p}[${w}2${p}] ${y}Advanced Dork Generation"
	echo -ne "\t${p}[${w}3${p}] ${y}Customize Dorks"; sleep .1; echo -e "\t\t${p}[${w}4${p}] ${y}Edit Sources"
	echo -ne "\t${p}[${w}5${p}] ${y}Remove All Results"; sleep .1; echo -e "\t\t${p}[${w}6${p}] ${y}Keyword Grabber ${b}[${r}BROKEN${b}]"
	echo -ne "\t${p}[${w}7${p}] ${y}Url To Dorks"; sleep .1; echo -e "\t\t${p}[${w}8${p}] ${y}Url To Pagetypes & Pageformats"
	echo -ne "\t${p}[${w}9${p}] ${y}Url To Keywords"; sleep .1; echo -e "\t\t${p}[${w}10${p}] ${y}Settings"
	echo -ne "\t${p}[${w}11${p}] ${y}Wordlist To Keywords"; sleep .1; echo -e "\t${p}[${w}12${p}] ${y}Tutorial Section"
	echo -ne "\t${p}[${w}13${p}] ${y}Settings"; sleep .1; echo -ne "\t\t\t${p}[${w}99${p}] ${y}Exit"; sleep .1
	echo -e "\n\n${b}[${r}!${b}] ${y}ALL RESULTS WILL BE SAVED IN ${g}${path}/results/ ${p}< = ${y}folder!\n\n"
	
	x=0
	while [ $x = 0 ]
	do
		echo -ne "${b}[${r}>${b}] ${y}Choose:${c} "
		read option
		case "$option" in
			1) generator; x=1;;
			2) adv_generator; x=1;;
			3) cust_dorks; x=1;;
			4) edit_src; x=1;;
			5) cleaner; x=1;;
			6) echo -e "${r}Sorry, this is currenctly not working"; x=0;;
			7) url2dorks; x=1;;
			8) url2pt; x=1;;
			9) url2key; x=1;;
			10) settings; x=1;;
			11) list2keys; x=1;;
			12) tutorial; x=1;;
			99) clear; echo -e "\n\n${y}[${r}!${y}] ${c}THANKS FOR USING :D"; exit; x=1;;
			*) echo -e "${r}[!] ${p}WRONG INPUT >:/"; x=0;;
		esac
	done
}

banner
d