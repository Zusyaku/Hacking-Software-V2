For more HQ stuffs join us on Telegram
Telegram official : https://t.me/tutorials_zone
========================================

War Crypter 1.6

 Functional:
 + FUD
 + Long Time Fud
 + Daily Refuds
 + Scantime + Runtime
 + Work on x32 / x64 System
 + Strong Startup
 + Custom Icon
 + Anti's
 + EOF
 + WipeFileMetaData
 + Tested and working on: Vista x32 / x64 |  Win7 x32 / x64 |  WinXp x32 / x64
 + Working With .Net Servers (NanoCore And e.t.c)
 + .Net 2.0 Dependencies
 + Updates