import requests, smtplib, base64, ctypes, random
from random import choice
import string
from email.utils import make_msgid
from multiprocessing.dummy import Pool
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
import time
from colorama import Fore
from colorama import Style
from colorama import init
import os, glob, sys, datetime
init(autoreset=True)
fr = Fore.RED
gr = Fore.BLUE
fc = Fore.CYAN
fw = Fore.WHITE
fy = Fore.YELLOW
fg = Fore.GREEN
sd = Style.DIM
sn = Style.NORMAL
sb = Style.BRIGHT
smtp_after = 0
info_after = 0
send = 1
failed = 0
change_smtp_after = open('sender-setting/config.txt', 'r').readlines()[5:6]
change_smtp = open('sender-setting/config.txt', 'r').readlines()[5:6]
change_info_after = open('sender-setting/config.txt', 'r').readlines()[6:7]
change_info = open('sender-setting/config.txt', 'r').readlines()[6:7]
x_priority = open('sender-setting/config.txt', 'r').readlines()[7:8]
random_name = open('sender-setting/config.txt', 'r').readlines()[9:10]
random_email = open('sender-setting/config.txt', 'r').readlines()[11:12]
random_subject = open('sender-setting/config.txt', 'r').readlines()[13:14]
random_letter = open('sender-setting/config.txt', 'r').readlines()[15:16]
time_sleep = open('sender-setting/config.txt', 'r').readlines()[17:18]
host1 = open('sender-setting/file-login-smtp.txt', 'r').readlines()[0:1]
port1 = open('sender-setting/file-login-smtp.txt', 'r').readlines()[1:2]
user1 = open('sender-setting/file-login-smtp.txt', 'r').readlines()[2:3]
paw1 = open('sender-setting/file-login-smtp.txt', 'r').readlines()[3:4]
for line in host1:
    currentline1 = line.split('[')[1].split(']')[0]

for line in port1:
    currentline2 = line.split('[')[1].split(']')[0]

for line in user1:
    currentline3 = line.split('[')[1].split(']')[0]

for line in paw1:
    currentline4 = line.split('[')[1].split(']')[0]

host2 = open('sender-setting/file-login-smtp.txt', 'r').readlines()[5:6]
port2 = open('sender-setting/file-login-smtp.txt', 'r').readlines()[6:7]
user2 = open('sender-setting/file-login-smtp.txt', 'r').readlines()[7:8]
paw2 = open('sender-setting/file-login-smtp.txt', 'r').readlines()[8:9]
for line in host2:
    currentline5 = line.split('[')[1].split(']')[0]

for line in port2:
    currentline6 = line.split('[')[1].split(']')[0]

for line in user2:
    currentline7 = line.split('[')[1].split(']')[0]

for line in paw2:
    currentline8 = line.split('[')[1].split(']')[0]

host3 = open('sender-setting/file-login-smtp.txt', 'r').readlines()[10:11]
port3 = open('sender-setting/file-login-smtp.txt', 'r').readlines()[11:12]
user3 = open('sender-setting/file-login-smtp.txt', 'r').readlines()[12:13]
paw3 = open('sender-setting/file-login-smtp.txt', 'r').readlines()[13:14]
for line in host3:
    currentline9 = line.split('[')[1].split(']')[0]

for line in port3:
    currentline10 = line.split('[')[1].split(']')[0]

for line in user3:
    currentline11 = line.split('[')[1].split(']')[0]

for line in paw3:
    currentline12 = line.split('[')[1].split(']')[0]

host4 = open('sender-setting/file-login-smtp.txt', 'r').readlines()[15:16]
port4 = open('sender-setting/file-login-smtp.txt', 'r').readlines()[16:17]
user4 = open('sender-setting/file-login-smtp.txt', 'r').readlines()[17:18]
paw4 = open('sender-setting/file-login-smtp.txt', 'r').readlines()[18:19]
for line in host4:
    currentline13 = line.split('[')[1].split(']')[0]

for line in port4:
    currentline14 = line.split('[')[1].split(']')[0]

for line in user4:
    currentline15 = line.split('[')[1].split(']')[0]

for line in paw4:
    currentline16 = line.split('[')[1].split(']')[0]

host5 = open('sender-setting/file-login-smtp.txt', 'r').readlines()[20:21]
port5 = open('sender-setting/file-login-smtp.txt', 'r').readlines()[21:22]
user5 = open('sender-setting/file-login-smtp.txt', 'r').readlines()[22:23]
paw5 = open('sender-setting/file-login-smtp.txt', 'r').readlines()[23:24]
for line in host5:
    currentline17 = line.split('[')[1].split(']')[0]

for line in port5:
    currentline18 = line.split('[')[1].split(']')[0]

for line in user5:
    currentline19 = line.split('[')[1].split(']')[0]

for line in paw5:
    currentline20 = line.split('[')[1].split(']')[0]

host6 = open('sender-setting/file-login-smtp.txt', 'r').readlines()[25:26]
port6 = open('sender-setting/file-login-smtp.txt', 'r').readlines()[26:27]
user6 = open('sender-setting/file-login-smtp.txt', 'r').readlines()[27:28]
paw6 = open('sender-setting/file-login-smtp.txt', 'r').readlines()[28:29]
for line in host6:
    currentline21 = line.split('[')[1].split(']')[0]

for line in port6:
    currentline22 = line.split('[')[1].split(']')[0]

for line in user6:
    currentline23 = line.split('[')[1].split(']')[0]

for line in paw6:
    currentline24 = line.split('[')[1].split(']')[0]

host7 = open('sender-setting/file-login-smtp.txt', 'r').readlines()[30:31]
port7 = open('sender-setting/file-login-smtp.txt', 'r').readlines()[31:32]
user7 = open('sender-setting/file-login-smtp.txt', 'r').readlines()[32:33]
paw7 = open('sender-setting/file-login-smtp.txt', 'r').readlines()[33:34]
for line in host7:
    currentline25 = line.split('[')[1].split(']')[0]

for line in port7:
    currentline26 = line.split('[')[1].split(']')[0]

for line in user7:
    currentline27 = line.split('[')[1].split(']')[0]

for line in paw7:
    currentline28 = line.split('[')[1].split(']')[0]

host = currentline1
port = currentline2
username = currentline3
password = currentline4
r_domain = [
 'com', 'co.us', 'net', 'org', 'xyz', 'ac', 'ad', 'au', 'gov', 'edu', 'int', 'us', 'ca', 'online',
 'to', 'co.za', 'world', 'vip', 'uk.com', 'team', 'se', 'pizza', 'one', 'org.nz', 'nu', 'guide', 'email', 'cc', 'io',
 'me']
for domain in r_domain:
    random_domain = choice(domain)

fromname_1 = open('sender-setting/sender-information.txt', 'r', encoding='utf8').readlines()[0:1]
fromemail_1 = open('sender-setting/sender-information.txt', 'r', encoding='utf8').readlines()[1:2]
sub_1 = open('sender-setting/sender-information.txt', 'r', encoding='utf8').readlines()[2:3]
for info in fromname_1:
    FromName1 = info.split('[')[1].split(']')[0]

for info in fromemail_1:
    FromEmail1 = info.split('[')[1].split(']')[0]

for info in sub_1:
    subj1 = info.split('[')[1].split(']')[0]

if change_smtp[0].split('[')[1].split(']')[0] == '1':
    change_s = 'No'
else:
    change_s = str(change_smtp[0].split('[')[1].split(']')[0])
    change_s_v = str(change_smtp[0].split('|')[1])
    smtp_after = 0

def clear():
    try:
        if os.name == 'nt':
            os.system('cls')
        else:
            os.system('clear')
    except:
        pass


def key_logo():
    clear = '\x1b[0m'
    colors = [36, 32, 34, 35, 31, 37]
    x = '\n\n\n                                       .--.\n                                      /.-. \'----------.\n                                      \'-\' .--"--""-"-\'\n                                       \'--\'\n                                                              \n\n\n'
    for N, line in enumerate(x.split('\n')):
        sys.stdout.write('\x1b[1;%dm%s%s\n' % (random.choice(colors), line, clear))
        time.sleep(0.05)


def cr():
    try:
        if os.name == 'nt':
            os.system('cls')
        else:
            os.system('clear')
    except:
        pass


def key():
    try:
        print('{}{}\n\t\t[+] Checking Licnse Key'.format(fw, sb))
        lwl = requests.get('https://pastebin.com/NuHPhDgV')
        so2al = open('KEY.txt', 'r').readlines()
        so = so2al[0]
        br = '<div class="de1">' + str(so) + '</div>'
        if br in str(lwl.content):
            print('\t{}{}[+] Welcome USER ...'.format(fw, sb))
        else:
            so2al1 = input('\n\t{}{}[-] Give Me Licnse Key : '.format(fw, sb))
            tani = requests.get('https://pastebin.com/NuHPhDgV')
            br = '<div class="de1">' + str(so2al1) + '</div>'
            if str(br) in str(tani.content):
                print('\t\t{}{}[+] Welcome USER ..'.format(fw, sb))
                z = open('KEY.txt', 'w').write(so2al1)
            else:
                print('\n{}{}\t[-] LICENSE KEY INCORRECT!'.format(fr, sb))
                print("'\n{}{}\t\t[-] PLEASE BACK TO CODER\n\n\t\t{}FICQ:@742809576{}".format(fr, sb, fw, sb))
                time.sleep(20)
                sys.exit()
    except:
        try:
            so2al1 = input('\n\t{}{}[-] Give Me Licnse Key : '.format(fw, sb))
            tani = requests.get('https://pastebin.com/NuHPhDgV')
            br = '<div class="de1">' + str(so2al1) + '</div>'
            if str(br) in str(tani.content):
                print('\t\t{}{}[+] Welcome USER ..'.format(fw, sb))
                z = open('KEY.txt', 'w').write(so2al1)
            else:
                print('\n{}{}\t[-] LICENSE KEY INCORRECT!'.format(fr, sb))
                print("'\n{}{}\t\t[-] PLEASE BACK TO CODER\n\n\t\t{}ICQ:@742809576{}".format(fr, sb, fw, sb))
                time.sleep(20)
                sys.exit()
        except:
            sys.exit()


def sender(emails):
    global failed
    global host
    global password
    global port
    global send
    global smtp_after
    global username
    ctypes.windll.kernel32.SetConsoleTitleW('Send: {}|Change Smtp: {} | Failed {}'.format(send, change_s, failed))
    FromName_1 = FromName1
    FromName_1 = FromName_1.replace('##random_string##', ''.join(random.sample(string.ascii_lowercase + string.digits, 7)))
    FromName_1 = FromName_1.replace('##time##', datetime.datetime.now().strftime('%H:%M:%S'))
    FromName_1 = FromName_1.replace('##date##', datetime.datetime.now().strftime('%Y-%m-%d'))
    FromName_1 = FromName_1.replace('##date&time##', datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    FromName_1 = FromName_1.replace('##random_number##', str(random.randint(0, 9999999)))
    message_bytes = FromName_1.encode('ascii')
    base64_bytes = base64.b64encode(message_bytes)
    base64_message = base64_bytes.decode('ascii')
    FromName_1 = base64_message
    FromEmail_1 = FromEmail1
    FromEmail_1 = FromEmail_1.replace('##random_string##', ''.join(random.sample(string.ascii_lowercase + string.digits, 7)))
    FromEmail_1 = FromEmail_1.replace('##random_domain##', random_domain)
    FromEmail_1 = FromEmail_1.replace('##random_number##', str(random.randint(0, 9999999)))
    email_ = FromEmail_1
    e = '<'
    r = '>'
    FromAdd_1 = '=?UTF-8?B?{}?='.format(FromName_1) + e + FromEmail_1 + r
    subj_1 = subj1.encode('utf-8').decode('utf-8')
    subj_1 = subj_1.replace('##random_string##', ''.join(random.sample(string.ascii_lowercase + string.digits, 7)))
    subj_1 = subj_1.replace('##time##', datetime.datetime.now().strftime('%H:%M:%S'))
    subj_1 = subj_1.replace('##date##', datetime.datetime.now().strftime('%Y-%m-%d'))
    subj_1 = subj_1.replace('##date&time##', datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    subj_1 = subj_1.replace('##random_number##', str(random.randint(0, 9999999)))
    message_bytes = subj_1.encode('ascii')
    base64_bytes = base64.b64encode(message_bytes)
    base64_message = base64_bytes.decode('ascii')
    subj_1 = base64_message
    FromAdd = FromAdd_1
    subject = subj_1
    if random_email[0].split('[')[1].split(']')[0].lower() == 'no':
        pass
    elif random_email[0].split('[')[1].split(']')[0].lower() == 'yes':
        with open('sender-setting/randomly/random_email.txt', 'r') as (f):
            r_email__ = f.readlines()
            for i in r_email__:
                r_email = i.replace('##random_string##', ''.join(random.sample(string.ascii_lowercase + string.digits, 7)))
                r_email = i.replace('##random_domain##', random_domain)
                r_email = i.replace('##random_number##', str(random.randint(0, 9999999)))
                r_email = choice(r_email)
                email_ = r_email
                FromAdress = '=?UTF-8?B?{}?='.format(FromName_1) + e + email_ + r
                FromAdd = FromAdress

    if random_name[0].split('[')[1].split(']')[0].lower() == 'no':
        pass
    else:
        if random_name[0].split('[')[1].split(']')[0].lower() == 'yes':
            with open('sender-setting/randomly/random_name.txt', 'r') as (f):
                r_name = f.readlines()
                r_name = choice(r_name)
                r_name = r_name.replace('##random_string##', ''.join(random.sample(string.ascii_lowercase + string.digits, 7)))
                r_name = r_name.replace('##time##', datetime.datetime.now().strftime('%H:%M:%S'))
                r_name = r_name.replace('##date##', datetime.datetime.now().strftime('%Y-%m-%d'))
                r_name = r_name.replace('##date&time##', datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
                r_name = r_name.replace('##random_number##', str(random.randint(0, 9999999)))
                message_bytes = r_name.encode('ascii')
                base64_bytes = base64.b64encode(message_bytes)
                base64_message = base64_bytes.decode('ascii')
                r_name = base64_message
                with_r_name = '=?UTF-8?B?{}?='.format(r_name) + e + email_ + r
                FromAdd = with_r_name
        if random_subject[0].split('[')[1].split(']')[0].lower() == 'no':
            pass
        if random_subject[0].split('[')[1].split(']')[0].lower() == 'yes':
            with open('sender-setting/randomly/random_subject.txt', 'r') as (f):
                r_subject = f.readlines()
                r_subject = choice(r_subject)
                r_subject = r_subject.replace('##random_string##', ''.join(random.sample(string.ascii_lowercase + string.digits, 7)))
                r_subject = r_subject.replace('##time##', datetime.datetime.now().strftime('%H:%M:%S'))
                r_subject = r_subject.replace('##date##', datetime.datetime.now().strftime('%Y-%m-%d'))
                r_subject = r_subject.replace('##date&time##', datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
                r_subject = r_subject.replace('##random_number##', str(random.randint(0, 9999999)))
                message_bytes = r_subject.encode('ascii')
                base64_bytes = base64.b64encode(message_bytes)
                base64_message = base64_bytes.decode('ascii')
                r_subject = base64_message
                subject = r_subject
        if change_smtp[0].split('[')[1].split(']')[0] == '1':
            pass
        if change_smtp[0].split('[')[1].split(']')[0] == '2':
            if int(change_smtp[0].split('|')[1]) is int(smtp_after):
                smtp_after = 0
                if username is currentline3:
                    time.sleep(5)
                    host = currentline5
                    port = currentline6
                    username = currentline7
                    password = currentline8
                else:
                    time.sleep(5)
                    host = currentline1
                    port = currentline2
                    username = currentline3
                    password = currentline4
                print('\n [ + ]  Change Smtp To {} : {}\n'.format(host, username))
        if change_smtp[0].split('[')[1].split(']')[0] == '3':
            if int(change_smtp[0].split('|')[1]) is int(smtp_after):
                smtp_after = 0
                if username is currentline3:
                    time.sleep(5)
                    host = currentline5
                    port = currentline6
                    username = currentline7
                    password = currentline8
                else:
                    if username is currentline7:
                        time.sleep(5)
                        host = currentline9
                        port = currentline10
                        username = currentline11
                        password = currentline12
                    else:
                        host = currentline1
                        port = currentline2
                        username = currentline3
                        password = currentline4
                print('\n [ + ]  Change Smtp To {} : {}\n'.format(host, username))
            if change_smtp[0].split('[')[1].split(']')[0] == '4':
                pass
        if int(change_smtp[0].split('|')[1]) is int(smtp_after):
            smtp_after = 0
            if username is currentline3:
                time.sleep(7)
                host = currentline5
                port = currentline6
                username = currentline7
                password = currentline8
            else:
                if username is currentline7:
                    time.sleep(7)
                    host = currentline9
                    port = currentline10
                    username = currentline11
                    password = currentline12
                else:
                    if username is currentline11:
                        time.sleep(7)
                        host = currentline13
                        port = currentline14
                        username = currentline15
                        password = currentline16
                    else:
                        time.sleep(7)
                        host = currentline1
                        port = currentline2
                        username = currentline3
                        password = currentline4
            print('\n [ + ]  Change Smtp To {} : {}\n'.format(host, username))
        if change_smtp[0].split('[')[1].split(']')[0] == '5':
            if int(change_smtp[0].split('|')[1]) is int(smtp_after):
                smtp_after = 0
                if username is currentline3:
                    time.sleep(2.5)
                    host = currentline5
                    port = currentline6
                    username = currentline7
                    password = currentline8
                else:
                    if username is currentline7:
                        time.sleep(2.5)
                        host = currentline9
                        port = currentline10
                        username = currentline11
                        password = currentline12
                    else:
                        if username is currentline11:
                            time.sleep(2.5)
                            host = currentline13
                            port = currentline14
                            username = currentline15
                            password = currentline16
                        else:
                            if username is currentline15:
                                time.sleep(2.5)
                                host = currentline17
                                port = currentline18
                                username = currentline19
                                password = currentline20
                            else:
                                time.sleep(2.5)
                                host = currentline1
                                port = currentline2
                                username = currentline3
                                password = currentline4
                print('\n [ + ]  Change Smtp To {} : {}\n'.format(host, username))
            if change_smtp[0].split('[')[1].split(']')[0] == '6':
                pass
        if int(change_smtp[0].split('|')[1]) is int(smtp_after):
            smtp_after = 0
            if username is currentline3:
                time.sleep(2.5)
                host = currentline5
                port = currentline6
                username = currentline7
                password = currentline8
            else:
                if username is currentline7:
                    time.sleep(2.5)
                    host = currentline9
                    port = currentline10
                    username = currentline11
                    password = currentline12
                else:
                    if username is currentline11:
                        time.sleep(2.5)
                        host = currentline13
                        port = currentline14
                        username = currentline15
                        password = currentline16
                    else:
                        if username is currentline15:
                            time.sleep(2.5)
                            host = currentline17
                            port = currentline18
                            username = currentline19
                            password = currentline20
                        else:
                            if username is currentline19:
                                time.sleep(2.5)
                                host = currentline21
                                port = currentline22
                                username = currentline23
                                password = currentline24
                            else:
                                time.sleep(2.5)
                                host = currentline1
                                port = currentline2
                                username = currentline3
                                password = currentline4
            print('\n [ + ]  Change Smtp To {} : {}\n'.format(host, username))
        if change_smtp[0].split('[')[1].split(']')[0] == '7':
            if int(change_smtp[0].split('|')[1]) is int(smtp_after):
                smtp_after = 0
                if username is currentline3:
                    time.sleep(2.5)
                    host = currentline5
                    port = currentline6
                    username = currentline7
                    password = currentline8
                else:
                    if username is currentline7:
                        time.sleep(2.5)
                        host = currentline9
                        port = currentline10
                        username = currentline11
                        password = currentline12
                    else:
                        if username is currentline11:
                            time.sleep(2.5)
                            host = currentline13
                            port = currentline14
                            username = currentline15
                            password = currentline16
                        else:
                            if username is currentline15:
                                time.sleep(2.5)
                                host = currentline17
                                port = currentline18
                                username = currentline19
                                password = currentline20
                            else:
                                if username is currentline19:
                                    time.sleep(2.5)
                                    host = currentline21
                                    port = currentline22
                                    username = currentline23
                                    password = currentline24
                                else:
                                    if username is currentline23:
                                        time.sleep(2.5)
                                        host = currentline25
                                        port = currentline26
                                        username = currentline27
                                        password = currentline28
                                    else:
                                        time.sleep(2.5)
                                        host = currentline1
                                        port = currentline2
                                        username = currentline3
                                        password = currentline4
                print('\n [ + ]  Change Smtp To {} : {}\n'.format(host, username))
            li = [
             'yahoo.com', 'aol.com', 'att.com',
             'cox.net', 'rr.com', 'aim.com', 'gmail.com',
             'inbox.com', 'mail.com', 'yandex.com', 'zoho.com',
             'outlook.com', 'protonmail.com', 'tutanota.com', 'icloud.com',
             '123mail.cl', '123mail.cl', 'amuromail.com', 'arcor.de', 'assamesemail.com',
             'bootmail.com', 'boxemail.com', 'boxemail.com', 'boxemail.com', 'e-mail.ru', 'edmail.com',
             'hushmail.com', 'rickymail.com', 'rickymail.com', 'comcast.net', 'earthlink.net', 'edge.net', 'ehmail.com']
            for d in li:
                do = choice(li)

            with open('sender-setting/letter.html', 'r', encoding='utf-8') as (f):
                letter1 = f.read()
                letter1 = letter1.replace('##email##', emails)
                letter1 = letter1.replace('##random_string##', ''.join(random.sample(string.ascii_lowercase + string.digits, 7)))
                letter1 = letter1.replace('##time##', datetime.datetime.now().strftime('%H:%M:%S'))
                letter1 = letter1.replace('##date##', datetime.datetime.now().strftime('%Y-%m-%d'))
                letter1 = letter1.replace('##date&time##', datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
            letter = letter1
    if random_letter[0].split('[')[1].split(']')[0].lower() == 'no':
        pass
    else:
        if random_letter[0].split('[')[1].split(']')[0].lower() == 'yes':
            all_letters = glob.glob('sender-setting/randomly/random_letters/*.html')
            _letter = choice(all_letters)
            with open(_letter, 'r', encoding='utf-8') as (f):
                r_letter = f.read()
                r_letter = r_letter.replace('##email##', emails)
                r_letter = r_letter.replace('##random_string##', ''.join(random.sample(string.ascii_lowercase + string.digits, 7)))
                r_letter = r_letter.replace('##time##', datetime.datetime.now().strftime('%H:%M:%S'))
                r_letter = r_letter.replace('##date##', datetime.datetime.now().strftime('%Y-%m-%d'))
                r_letter = r_letter.replace('##date&time##', datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
                letter = r_letter
        if str(x_priority[0].split('[')[1].split(']')[0].lower()) == 'low':
            imp = 'low'
        else:
            imp = 'high'
        if time_sleep[0].split('[')[1].split(']')[0] == '0':
            timer = time.sleep(0)
        else:
            timer = time.sleep(int(time_sleep[0].split('[')[1].split(']')[0]))
        try:
            mailserver = smtplib.SMTP(host, port)
            mailserver.ehlo()
            mailserver.starttls()
            mailserver.ehlo()
            mailserver.login(username, password)
        except Exception as error:
            print(error)
            print(' [-] Please fix your problem with smtp then use me')
            time.sleep(1000)

        while True:
            try:
                msg = MIMEMultipart()
                msg.attach(MIMEText(letter, 'html', 'utf-8'))
                msg['From'] = FromAdd
                msg['To'] = emails
                msg['Subject'] = '=?UTF-8?B?{}?='.format(subject)
                msg['Importance'] = imp
                msg['Message-ID'] = make_msgid(domain=do)
                msg['X-PHISHTEST'] = 'KnowBe4'
                msg['Content-type'] = 'text/html; charset=utf-8'
                msg['MIME-Version'] = '1.0'
                msg['Content-Transfer-Encoding'] = 'base64'
                mailserver.sendmail(FromAdd_1, emails, msg.as_string())
                mailserver.quit()
                print('{}[{}]{} {} {} Sent!'.format(fy, datetime.datetime.now().strftime('%H:%M:%S'), sb, str(send), emails))
                send += 1
                smtp_after += 1
                time.sleep(0)
                break
            except smtplib.SMTPException as ex:
                print('  \n\x1b[101m[-] {}'.format(str(ex)))
                failed += 1
                break

            break


def dv():
    print(x)


def banner():
    x = u"{}{}\n DEVIL SENDER FUCKED BY Psyco_M \n                                    I don't accept no liability for any illegal use\n\n".format(fr, sb)
    xx = u'{}{}\n     +++++++++++++++++++++++++++++++++++++\n     +       Devil Box Sender V.3        +\n     +         ICQ >> @742809576         +\n     +          |+ K I R A +|            +\n     +++++++++++++++++++++++++++++++++++++'.format(fw, sb)
    print(x)
    print(xx)


def run():
    global emails
    clear()
    key_logo()
    key()
    clear()
    load = '\n [+] Load config ....\x1b[101m\n'.format(fg, sb)
    for i in load:
        sys.stdout.write('\x1b[105m' + i)
        sys.stdout.flush()
        time.sleep(0.1)

    if change_smtp[0].split('[')[1].split(']')[0] == '1':
        print('{}{} \n\t[ x ] You Work With first smtp'.format(fg, sb))
        print('{}{}\n\t\t\t     [Host] {}\n                             [Port] {}\n                             [User] {}\n                             [Pass] {}'.format(fg, sb, host, port, username, 'Lol Hide Password'))
    else:
        print('{}{} \n\t[ x ] Use {} of smtps .....'.format(fg, sb, str(change_smtp[0].split('[')[1].split(']')[0])))
        print('{}{} \n\t[ x ] Change Smtps After [ {} ]'.format(fg, sb, str(change_smtp[0].split('|')[1])))
    print('{}{} \n\t[ x ] X-Priority =  [ {} ] '.format(fg, sb, str(x_priority[0].split('[')[1].split(']')[0])))
    print('\x1b[105m\n [+] Load sender information ....\x1b[101m\n'.format(fg, sb))
    if random_email[0].split('[')[1].split(']')[0].lower() == 'yes':
        email = 'is use randomly from random_email.txt file'
    else:
        if random_email[0].split('[')[1].split(']')[0].lower() == 'no':
            email = '{}'.format(FromEmail1)
        if random_name[0].split('[')[1].split(']')[0].lower() == 'yes':
            name = 'is use randomly from random_name.txt file'
        elif random_name[0].split('[')[1].split(']')[0].lower() == 'no':
            name = '{}'.format(FromName1)
    if random_subject[0].split('[')[1].split(']')[0].lower() == 'yes':
        subject = 'is use randomly from random_subject.txt file'
    else:
        if random_subject[0].split('[')[1].split(']')[0].lower() == 'no':
            subject = '{}'.format(subj1)
        print('{}{} \n\t\t[ ! ] NAME = {}'.format(fg, sb, name))
        print('{}{} \n\t\t[ ! ] SENDER EMAIL = {}'.format(fg, sb, email))
        print('{}{} \n\t\t[ ! ] SUBJECT = {}'.format(fg, sb, subject))
        if random_letter[0].split('[')[1].split(']')[0].lower() == 'yes':
            print('{}{} \n\t\t[ ! ] Random Letters Mode = YES'.format(fg, sb))
        elif random_letter[0].split('[')[1].split(']')[0].lower() == 'no':
            print('{}{} \n\t\t[ ! ] Random Letters Mode = NO'.format(fg, sb))
    print('{}{}\n\t\t[ ! ] Sleep Timer = {}'.format(fg, sb, str(time_sleep[0].split('[')[1].split(']')[0])))
    input(' {}{}\n\t\t\t[ + ] Press Enter Key To Continue ! '.format(fy, sd))
    clear()
    banner()
    emails = input('\n  [ + ] Your Email List ! : ')
    print('')
    with open(emails, 'r') as (f):
        emails = f.read().split('\n')
        print(' ==================[ Started Sending {} E-mail ]=================='.format(len(emails)))
        print('')
    ThreadPool = Pool(1)
    Threads = ThreadPool.map(sender, emails)


run()
# okay decompiling Devil.pyc
