== > Some options < ==

##random_string## = random string in email or name or subject or letter 

##email## = email reciver in letter in name or letter

##time## = for current time in subject or letter or name or subject

##date## = for today's date in subject or letter or name or subject

##date&time## = for current date and time together

##random_number## = for rand number in email amd subject and letter

##random_domain## = for random domains in email sender example (email@devilbox.##random_domain##)

