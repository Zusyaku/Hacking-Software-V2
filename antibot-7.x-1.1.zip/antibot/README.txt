Please see the project page for required information:
  https://drupal.org/project/antibot
